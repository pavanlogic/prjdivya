from django.db import models
from django.utils import timezone
from  datetime import datetime,date

class perdemoinfo(models.Model):
    my_gender = (
        ("Male", "Male"),
        ("Female", "Female"),
    )
    my_marritalstatus = (
        ("Married", "Married"),
        ("Unmarried", "Unmarried"),
        ("other", "other"),
    )

    my_edustatus = (
        ("Illiterate", "Illiterate"),
        ("Literate", "Literate"),
    )

    my_socecostatus = (
        ("Above Poverty Line", "Above Poverty Line"),
        ("Below Poverty Line", "Below Poverty Line"),
    )

    my_habitat = (
        ("Urban", "Urban"),
        ("Semi-Urban", "Semi-Urban"),
        ("Rural", "Rural"),
    )

    my_religion = (
        ("Hindu", "Hindu"),
        ("Muslim", "Muslim"),
        ("Sikh", "Sikh"),
        ("Christian", "Christian"),
        ("Others", "Others"),
    )

    my_prevhis = (
        ("Yes", "Yes"),
        ("No", "No"),
    )

    registrationdate = models.DateField(null=True)
    opdno = models.IntegerField(null=True)
    caseno = models.IntegerField(null=True)
    crno = models.IntegerField(null=True)
    ipdno = models.IntegerField(null=True)

    patientname = models.CharField(max_length=200,verbose_name="Patient Name")
    dob = models.DateField(verbose_name="D.O.B")
    ageyr = models.IntegerField(verbose_name="Age(Year)")
    agemn = models.IntegerField(verbose_name="Age(Month)")
    gender = models.CharField(max_length=50,choices=my_gender,verbose_name="Gender")
    address = models.CharField(max_length=200,verbose_name="Address")
    contactno = models.CharField(max_length=50,verbose_name="Contact No.")
    email = models.EmailField(max_length=100,verbose_name="Email")
    marritalstatus =  models.CharField(max_length=50, choices=my_marritalstatus,verbose_name="Marrital Status")
    edustatus = models.CharField(max_length=50,choices=my_edustatus,verbose_name="Educational Status")
    education = models.CharField(max_length=200,verbose_name="Education")
    qualification = models.CharField(max_length=200,verbose_name="Qualification")
    socecostatus = models.CharField(max_length=50,choices=my_socecostatus,verbose_name="Socio-Economic Status")
    habitat = models.CharField(max_length=50,choices=my_habitat,verbose_name="Habitat")
    religion = models.CharField(max_length=50,choices=my_religion,verbose_name="Religion")
    chiefcomplaint = models.CharField(max_length=200,verbose_name="Chief Complaint")
    durationofillness = models.CharField(max_length=200,verbose_name="Duration Of Illness")
    otherinfo = models.CharField(max_length=200,verbose_name="Any other information")
    prevhistory = models.CharField(max_length=50,choices=my_prevhis,verbose_name="History of Previous illness (if any)")
    prevhistoryspecify = models.CharField(max_length=1000,verbose_name="Any significant medical or surgical history If yes, then specify")

    class Meta:
        verbose_name = 'Personal & Demographic Info'
        verbose_name_plural = 'Personal & Demographic Infos'

class clinicalprofile(models.Model):
    my_diethabit = (
        ("Vegetarian", "Vegetarian"),
        ("Non-Vegetarian", "Non-Vegetarian"),
    )
    my_addictions = (
        ("Tea","Tea"),
        ("Coffee", "Coffee"),
        ("Tea","Tea"),
        ("Coffee","Coffee"),
        ("Alcohol", "Alcohol"),
        ("Tobacco", "Tobacco"),
        ("Smoking", "Smoking"),
        ("None", "None"),
    )
    my_sleep = (
        ("Normal", "Normal"),
        ("Disturbed", "Disturbed"),
    )
    my_bowelhabit = (
        ("Regular", "Regular"),
        ("Irregular", "Irregular"),
    )
    my_stoolconsist = (
        ("Normal", "Normal"),
        ("Loose", "Loose"),
        ("Constipated", "Constipated"),
    )
    my_urineoutput = (
        ("Normal", "Normal"),
        ("Frequent", "Frequent"),
        ("Urgency", "Urgency"),
        ("Strangury", "Strangury"),
        ("Nocturia", "Nocturia"),
    )
    my_physicalex = (
        ("Heavy Labour", "Heavy Labour"),
        ("Moderate Labour", "Moderate Labour"),
        ("Office Job", "Office Job"),
        ("Sedentary", "Sedentary"),
    )
    my_alltomaterial = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_emostress = (
        ("Average", "Average"),
        ("Moderate", "Moderate"),
        ("Too Much", "Too Much"),
    )
    my_gyncobshis = (
        ("Applicable", "Applicable"),
        ("Non-Applicable", "Non-Applicable"),
    )
    my_whitedisch = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_built = (
        ("Average", "Average"),
        ("Emaciated", "Emaciated"),
        ("Well built", "Well built"),
        ("Tall", "Tall"),
        ("Dwarf", "Dwarf"),
    )
    my_clubbing = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosis = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosispresent = (
        ("Central", "Central"),
        ("Peripheral", "Peripheral"),
    )
    my_pallor = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_lymphadenopathy = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_edema = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_character = (
        ("Pitting", "Pitting"),
        ("Non- pitting", "Non- pitting"),
    )
    my_veribralcol = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_joints = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_Superficialreflexesplantar = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_Superficialreflexesabdominal = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_deepreflexesbicepsjerk = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_deepreflexeskneejerk = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_deepreflexesanklejerk = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_signofmenirr = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_neckstiffness = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_gait = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_deformities = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_musclewasting  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_asymmetry  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_redness  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_inflammation  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_muscletwitch  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_swellinjoints  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )

    my_scaresjoints = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )

    my_palpwarmth = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palptenderness = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpswelling = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpeffusion = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpcrepitus = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpactivemov = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_palppassivemov = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_spine = (
        ("Thoracickyphosis", "Thoracic kyphosis"),
        ("Lumbarlorodosis", "Lumbar lorodosis"),
        ("Limitedrangeonmovements", "Limited range on movements"),
    )
    my_gait1 = (
        ("Limp", "Limp"),
        ("rendelenburg", "Rendelenburg"),
        ("Antalgic", "Antalgic"),
        ("Highstepping", "High stepping"),
        ("Crouch", "Crouch"),
    )

    my_bone = (
        ("Congenitaldeformity", "Congenital deformity"),
        ("Fracture", "Fracture"),
        ("Tumour", "Tumour"),
        ("Degenerativechanges", "Degenerative changes"),
    )

    my_neck = (
        ("Pain", "Pain"),
        ("Limitedmovements", "Limited movements"),
        ("Deformity", "Deformity"),
    )

    my_handsswelling = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_handsfingdef = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_handsfingnodes = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )

    registrationdate = models.DateField(null=True)
    opdno = models.IntegerField(null=True)
    caseno = models.IntegerField(null=True)
    crno = models.IntegerField(null=True)
    ipdno = models.IntegerField(null=True)

    dietaryhabit = models.CharField(max_length=50,choices=my_diethabit, blank=True,verbose_name="Dietary Habits")
    addiction = models.CharField(max_length=50,choices=my_addictions, blank=True,verbose_name="Addiction")
    addqty = models.CharField(max_length=200, blank=True,verbose_name="Specify quantity/day")
    addduration = models.CharField(max_length=200, blank=True,verbose_name="Duration of Addiction")
    sleep = models.CharField(max_length=50,choices=my_sleep, blank=True,verbose_name="Sleep")
    bowelhabitat = models.CharField(max_length=50,choices=my_bowelhabit, blank=True,verbose_name="Bowel Habits")
    stoolcons = models.CharField(max_length=50,choices=my_stoolconsist, blank=True,verbose_name="Stool Consistency")
    urineoutput = models.CharField(max_length=50,choices=my_urineoutput, blank=True,verbose_name="Urine Output")
    phyex = models.CharField(max_length=50,choices=my_physicalex, blank=True,verbose_name="Physical Exercise")
    alltomaterial = models.CharField(max_length=50,choices=my_alltomaterial, blank=True,verbose_name="Allergy to Some Material")
    natureofall = models.CharField(max_length=200,choices=my_emostress, blank=True,verbose_name="If yes, then nature of the allergen")
    symptoms = models.CharField(max_length=200, blank=True,verbose_name="Symptom(s) produced upon exposure")
    emotionalstress = models.CharField(max_length=50,choices=my_emostress, blank=True,verbose_name="Emotional Stresses")
    gyncobshis = models.CharField(max_length=50,choices=my_gyncobshis, blank=True,verbose_name="Gynecological/obstetric history")

    menarche = models.CharField(max_length=200, blank=True,verbose_name="a)Menarche(years)")
    menopause = models.CharField(max_length=200, blank=True,verbose_name="b)Menopause(years")
    lmp = models.DateField(null=True, blank=True,verbose_name="LMP")
    whitedisch = models.CharField(max_length=50,choices=my_whitedisch, blank=True,verbose_name="White discharge per vagina")

    familyhist = models.TextField(max_length=200, blank=True,verbose_name="Family History")
    surhis =  models.TextField(max_length=200, blank=True,verbose_name="Surgical History")
    prevhistoryspecify = models.TextField(max_length=200, blank=True,verbose_name="Previous History (specify)")

    builtavg = models.CharField(max_length=50,choices=my_built, blank=True,verbose_name="Built")
    nutrition = models.CharField(max_length=50, blank=True,verbose_name="Nutrition")

    height = models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="Height(cm)")
    weight= models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="Weight(kg)")
    bmi = models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="B.M.I.(kg/m2) ")

    waistcirm = models.DecimalField(max_digits=5,decimal_places=1, default=0,verbose_name="Waist Circumference (cm)")
    resprate = models.IntegerField(default=0,verbose_name="Respiratory Rate(/minute)")
    pulserate = models.IntegerField(default=0,verbose_name="Pulse Rate(/minute)")
    bp = models.CharField(max_length=100, null=True, blank=True,verbose_name="Blood Pressure(mmHg)")

    clubbing = models.CharField(max_length=100,choices=my_clubbing, blank=True,verbose_name="Clubbing")
    cyanosis = models.CharField(max_length=100,choices=my_cyanosis, blank=True,verbose_name="Cyanosis")
    cyanosispresent = models.CharField(max_length=100,choices=my_cyanosispresent, blank=True,verbose_name="If present")

    temp = models.DecimalField(max_digits=5,decimal_places=1,null=True, blank=True,verbose_name="Temperature(oF)")
    pallor = models.CharField(max_length=50,choices=my_pallor, blank=True,verbose_name="Pallor")
    lymphadenopathy = models.CharField(max_length=50,choices=my_lymphadenopathy, blank=True,verbose_name="Lymphadenopathy")
    edema = models.CharField(max_length=50,choices=my_edema, blank=True,verbose_name="Edema")
    character = models.CharField(max_length=50,choices=my_character, blank=True,verbose_name="Character")
    siteaffected =  models.CharField(max_length=200, blank=True,verbose_name="Site Affected")
    vertebralcol = models.CharField(max_length=50, choices=my_veribralcol, blank=True,verbose_name="Vertebral column")
    vertebralcolanyother = models.CharField(max_length=200, blank=True,verbose_name="Any other")
    joints = models.CharField(max_length=50,choices=my_joints, blank=True,verbose_name="Joints")
    jointsabnormal = models.CharField(max_length=200, blank=True,verbose_name="If abnormal, then specific joint and associated abnormality")

    #=========================EXAMINATION==========================
    respsystem = models.CharField(max_length=200, blank=True,verbose_name="Respiratory System")
    gastrointestsystem = models.CharField(max_length=200, blank=True,verbose_name="Gastro- Intestinal System")
    cardiovascsystem = models.CharField(max_length=200, blank=True,verbose_name="Cardio- vascular System")
    nervoussystem = models.CharField(max_length=200, blank=True,verbose_name="Nervous System")
    superficialreflexplanter = models.CharField(max_length=50, choices=my_Superficialreflexesplantar, blank=True,verbose_name="Superficial reflexes: Planter")
    superficialreflexabdominal = models.CharField(max_length=50, choices=my_Superficialreflexesabdominal, blank=True,verbose_name="Superficial reflexes: Abdominal")

    deepreflexbicepjerk = models.CharField(max_length=50, choices=my_deepreflexesbicepsjerk, blank=True,verbose_name="Deep reflexes :Biceps Jerk")
    deepreflexkneejerk = models.CharField(max_length=50, choices=my_deepreflexeskneejerk, blank=True,verbose_name="Deep reflexes :Knee Jerk ")
    deepreflexanklejerk = models.CharField(max_length=50, choices=my_deepreflexesanklejerk, blank=True,verbose_name="Deep reflexes :Ankle Jerk")

    signofmenirr = models.CharField(max_length=50, choices=my_signofmenirr, blank=True,verbose_name="Signs of Meningeal Irritation")
    neckstiff = models.CharField(max_length=50, choices=my_neckstiffness, blank=True,verbose_name="If present then, Neck stiffness")

    gait = models.CharField(max_length=50, choices=my_gait, blank=True,verbose_name="Gait(walking freely/with stick) ")
    deformities = models.CharField(max_length=50, choices=my_deformities, blank=True,verbose_name="Deformities(knock knees,bowlegs,pigeon toes")

    musclewaisting = models.CharField(max_length=50, choices=my_musclewasting, blank=True,verbose_name="Muscle wasting just above and around the joint ")
    asymmetry = models.CharField(max_length=50, choices=my_asymmetry, blank=True,verbose_name="Asymmetry")
    redness = models.CharField(max_length=50, choices=my_redness, blank=True,verbose_name="Redness")
    inflammation = models.CharField(max_length=50, choices=my_inflammation, blank=True,verbose_name="Inflammation")
    muscletwitch = models.CharField(max_length=50, choices=my_muscletwitch, blank=True,verbose_name="Muscle Twitch")
    swellingjoints = models.CharField(max_length=50, choices=my_swellinjoints, blank=True,verbose_name="Swellings in and around the joint")
    scaresjoints = models.CharField(max_length=50, choices=my_scaresjoints, blank=True,verbose_name="Scares in and around the joint")

    warmth = models.CharField(max_length=50, choices=my_palpwarmth, blank=True,verbose_name="Warmth")
    tenderness = models.CharField(max_length=50, choices=my_palptenderness, blank=True,verbose_name="Tenderness")
    swelling = models.CharField(max_length=50, choices=my_palpswelling, blank=True,verbose_name="Swelling")
    effusion = models.CharField(max_length=50, choices=my_palpeffusion, blank=True,verbose_name="Effusion")
    crepitus = models.CharField(max_length=50, choices=my_palpcrepitus, blank=True,verbose_name="Crepitus")
    activemovement = models.CharField(max_length=50, choices=my_palpactivemov, blank=True,verbose_name="Active movement")
    passivemovement = models.CharField(max_length=50, choices=my_palppassivemov , blank=True,verbose_name="Passive movement")

    spine = models.CharField(max_length=50, choices=my_spine, blank=True,verbose_name="Spine")
    gait1 = models.CharField(max_length=50, choices=my_gait1, blank=True,verbose_name="Gait")
    bone = models.CharField(max_length=50, choices=my_bone, blank=True,verbose_name="Bone")
    neck = models.CharField(max_length=50, choices=my_neck, blank=True,verbose_name="Neck")
    handswelljoints = models.CharField(max_length=50, choices=my_handsswelling, blank=True,verbose_name="Hands:swelling of MCP,PTP or DIP Joints")
    handfingdefo = models.CharField(max_length=50, choices=my_handsfingdef, blank=True,verbose_name="Hands:finger deformities")
    handfingmode = models.CharField(max_length=50, choices=my_handsfingnodes, blank=True,verbose_name="Hands:finger nodes")

    class Meta:
        verbose_name = 'Clinical Profile'

class incexccriteria(models.Model):
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)
# ==============INCLUSION CRITERIA================
    ic1 = models.BooleanField(default=False,verbose_name="1.Those who are not willing to participate in the study")
    ic2 = models.BooleanField(default=False,verbose_name="2.Patients with age group of 18-55 years.")
    ic3 = models.BooleanField(default=False,verbose_name="3.History of cervical instability, cord compression, central pain syndrome (e. g. Fibromyalgia), evidence of CNS involvement, known history of high- level spinal cord injury, traumatic injuries to upper limb and cervical spine, limitation of glenohumeral joint, elbow joint or wrist joint, evidence of malignancy.")
# ==============EXCLUSION CRITERIA================
    ec1=  models.BooleanField(default=False, verbose_name="1.Those who are not willing to participate in the study")
    ec2 = models.BooleanField(default=False, verbose_name="2.Pregnancy and Lactating mother.")
    ec3 = models.BooleanField(default=False, verbose_name="3.History of cervical instability, cord compression, central pain syndrome (e. g. Fibromyalgia), evidence of CNS involvement, known history of high- level spinal cord injury, traumatic injuries to upper limb and cervical spine, limitation of glenohumeral joint, elbow joint or wrist joint, evidence of malignancy.")
    ec4 = models.BooleanField(default=False, verbose_name="4.Any medical red flag. (i.e., spinal tumor, fracture, metabolic disease, RA, osteoporosis, spinal infection etc).")
    ec5 = models.BooleanField(default=False, verbose_name="5.Patients having co – morbidities like hypertension (systolic >160 and diastolic >100 mm of Hg) despite of antihypertensive agents and diabetic mellitus (According to WHO, fasting plasma glucose ≥ 7.0mmol/l (126mg/dl) or 2–h plasma glucose ≥ 11.1mmol/l (200mg/dl),active case of tuberculosis.")
    ec6 = models.BooleanField(default=False, verbose_name="6.Those who have completed participation in any other clinical trial drugs or their ingredients in one -month period.")
#==============SCREENING FORM QUESTIONS================
    sfq1=  models.BooleanField(default=False, verbose_name="1.Do you have any trauma or surgery to the neck and shoulder.?")
    sfq2 = models.BooleanField(default=False, verbose_name="2.Any shoulder deformity/ contracture / pathology.?")
    sfq3 = models.BooleanField(default=False, verbose_name="3.Have you ever been diagnosed with upper motor neuron disease.?")
    sfq4 = models.BooleanField(default=False, verbose_name="4.Have you been diagnosed with cervical myelopathy.?")
    sfq5 = models.BooleanField(default=False, verbose_name="5.Have you been diagnosed with vertebrobasilar insufficiency.?")
    sfq6 = models.BooleanField(default=False, verbose_name="6.Any signs or symptoms suggesting as a red flag.? (fever,night sweats, unexpected weight loss, excruciating pain, infection, tuberculosis)? ")
    sfq7 = models.BooleanField(default=False, verbose_name="7.Have you been diagnosed with any other systemic illness?")

    class Meta:
        verbose_name = 'Inclusive & xclusion Criteria'

class subjectivepara(models.Model):
# ==============SUBJECTIVE PARAMETERS ================
#========Before Treatment=====
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)

    sympBT1 = models.BooleanField(default=False, verbose_name="a.Difficulty in Movements of the arm")
    sympBT2 = models.BooleanField(default=False, verbose_name="b.Radiating pain from cervical region to shoulder down to the arm")
    sympBT3 = models.BooleanField(default=False, verbose_name="c.Neck pain")
    sympBT4 = models.BooleanField(default=False, verbose_name="d.Weakness & Numbness")
    sympBT5 = models.BooleanField(default=False, verbose_name="e.Clumsy finger movements")
    sympBT6 = models.BooleanField(default=False, verbose_name="f.Paraesthesia (burning and pricking type of pain)")
    sympBT7 = models.BooleanField(default=False, verbose_name="g.Vertigo (feeling of dizziness, feeling of loss of balance of body)")
    sympBT8 = models.BooleanField(default=False, verbose_name="h.Tenderness over cervical region")
    sympBT9 = models.BooleanField(default=False, verbose_name="i.Stiffness in cervical region and upper limb follow up to digits of affected hand")

    sympBT11 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT22 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT33 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT44 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT55 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT66 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT77 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT88 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympBT99 = models.CharField(max_length=50, blank=True, verbose_name="")
# ========After Treatment=====
    sympAT1 = models.BooleanField(default=False, verbose_name="")
    sympAT2 = models.BooleanField(default=False, verbose_name="")
    sympAT3 = models.BooleanField(default=False, verbose_name="")
    sympAT4 = models.BooleanField(default=False, verbose_name="")
    sympAT5 = models.BooleanField(default=False, verbose_name="")
    sympAT6 = models.BooleanField(default=False, verbose_name="")
    sympAT7 = models.BooleanField(default=False, verbose_name="")
    sympAT8 = models.BooleanField(default=False, verbose_name="")
    sympAT9 = models.BooleanField(default=False, verbose_name="")

    sympAT11 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT22 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT33 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT44 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT55 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT66 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT77 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT88 = models.CharField(max_length=50, blank=True, verbose_name="")
    sympAT99 = models.CharField(max_length=50, blank=True, verbose_name="")

    class Meta:
        verbose_name = 'Subjective parameters'
class objectivepara(models.Model):
# ==============OBJECTIVE PARAMETERS ================
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)
#========Before Treatment=====
    paraBT1 = models.CharField(max_length=50, blank=True, verbose_name="1.Neck disability index")

    paraBT21 = models.CharField(max_length=50, blank=True, verbose_name="Visual analog scale - On rest")
    paraBT22 = models.CharField(max_length=50, blank=True, verbose_name="          Activity Time")
# ========Before Treatment RIGHT
    paraBTRT31 = models.CharField(max_length=50, blank=True, verbose_name="Shoulder joint")
    paraBTRT32 = models.CharField(max_length=50, blank=True, verbose_name="Flexion")
    paraBTRT33 = models.CharField(max_length=50, blank=True, verbose_name="Horizontal extension")
    paraBTRT34 = models.CharField(max_length=50, blank=True, verbose_name="Abduction")
    paraBTRT35 = models.CharField(max_length=50, blank=True, verbose_name="Medial rotation")
    paraBTRT36 = models.CharField(max_length=50, blank=True, verbose_name="Lateral rotation")
    paraBTRT37 = models.CharField(max_length=50, blank=True, verbose_name="Cervical spine")
    paraBTRT38 = models.CharField(max_length=50, blank=True, verbose_name="Flexion")
    paraBTRT39 = models.CharField(max_length=50, blank=True, verbose_name="Extension")
    paraBTRT310 = models.CharField(max_length=50, blank=True, verbose_name="Lateral Rotation")
    paraBTRT311 = models.CharField(max_length=50, blank=True, verbose_name="Side flexion")
# ========Before Treatment LEFT
    paraBTLT31 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT32 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT33 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT34 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT35 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT36 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT37 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT38 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT39 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT310 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraBTLT311 = models.CharField(max_length=50, blank=True, verbose_name="")

    paraBT4 = models.CharField(max_length=50, blank=True, verbose_name="5.Foraminal compression (Spurling’s test)")
    paraBT5 = models.CharField(max_length=50, blank=True, verbose_name="6.Distraction test")
    paraBT6 = models.CharField(max_length=50, blank=True, verbose_name="7.Upper limb tension test (brachial plexus tension or Elvey test)")
    paraBT7 = models.CharField(max_length=50, blank=True, verbose_name="8.Cervical rotation test")
    paraBT8 = models.CharField(max_length=50, blank=True, verbose_name="9.Nerve conduction velocity test")
    #paraBT9 = models.CharField(max_length=50, blank=True, verbose_name="")
# ========After Treatment=====
    paraAT1 = models.CharField(max_length=50, blank=True, verbose_name="")

    paraAT21 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraAT22 = models.CharField(max_length=50, blank=True, verbose_name="")
#========RIGHT
    paraATRT31 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT32 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT33 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT34 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT35 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT36 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT37 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT38 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT39 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT310 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATRT311 = models.CharField(max_length=50, blank=True, verbose_name="")
# ========LEFT
    paraATLT31 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT32 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT33 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT34 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT35 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT36 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT37 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT38 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT39 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT310 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraATLT311 = models.CharField(max_length=50, blank=True, verbose_name="")

    paraAT4 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraAT5 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraAT6 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraAT7 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraAT8 = models.CharField(max_length=50, blank=True, verbose_name="")
    paraAT9 = models.CharField(max_length=50, blank=True, verbose_name="")

    class Meta:
        verbose_name = 'Objective parameter'
class bioradioinv(models.Model):
# ==============BIOCHEMISTRY & RADIOLOGY INVESTIGATION ================
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)

    hba1cBP = models.CharField(max_length=50, blank=True, verbose_name="1.HbA1c")
    hba1cAP = models.CharField(max_length=50, blank=True, verbose_name="")

    totalcolBP = models.CharField(max_length=50, blank=True, verbose_name="Total cholesterol")
    totalcolAP = models.CharField(max_length=50, blank=True, verbose_name="")

    ldlcBP = models.CharField(max_length=50, blank=True, verbose_name="LDL-C")
    ldlcAP = models.CharField(max_length=50, blank=True, verbose_name="")

    hdlcBP = models.CharField(max_length=50, blank=True, verbose_name="HDL-C")
    hdlcAP = models.CharField(max_length=50, blank=True, verbose_name="")

    triglyBP = models.CharField(max_length=50, blank=True, verbose_name="Triglycerides")
    triglycAP = models.CharField(max_length=50, blank=True, verbose_name="")

    vldlBP = models.CharField(max_length=50, blank=True, verbose_name="VLDL")
    vldlAP = models.CharField(max_length=50, blank=True, verbose_name="")

    tchdlratioBP = models.CharField(max_length=50, blank=True, verbose_name="TC-HDL Ratio")
    tchdlratioAP = models.CharField(max_length=50, blank=True, verbose_name="")

    ureaBP = models.CharField(max_length=50, blank=True, verbose_name="Urea")
    ureaAP = models.CharField(max_length=50, blank=True, verbose_name="")

    uricacidBP = models.CharField(max_length=50, blank=True, verbose_name="Uric acid")
    uricacidAP = models.CharField(max_length=50, blank=True, verbose_name="")

    creatinineBP = models.CharField(max_length=50, blank=True, verbose_name="Sr. Creatinine")
    creatinineAP = models.CharField(max_length=50, blank=True, verbose_name="")

    albuminBP = models.CharField(max_length=50, blank=True, verbose_name="Sr. Albumin")
    albuminAP = models.CharField(max_length=50, blank=True, verbose_name="")

    altBP = models.CharField(max_length=50, blank=True, verbose_name="ALT")
    altAP = models.CharField(max_length=50, blank=True, verbose_name="")

    astBP = models.CharField(max_length=50, blank=True, verbose_name="AST")
    astAP = models.CharField(max_length=50, blank=True, verbose_name="")

    alpBP = models.CharField(max_length=50, blank=True, verbose_name="ALP")
    alpAP = models.CharField(max_length=50, blank=True, verbose_name="")

    bilirubinBP = models.CharField(max_length=50, blank=True, verbose_name="Sr. Bilirubin")
    bilirubinAP = models.CharField(max_length=50, blank=True, verbose_name="")

    nervecondvelBP = models.CharField(max_length=50, blank=True, verbose_name="5.Nerve conduct ion velocity test of bilateral upper limb")
    nervecondvelAP = models.CharField(max_length=50, blank=True, verbose_name="")

    class Meta:
        verbose_name = 'Biochemical and radiological investigation'
class neckdisabilityindex(models.Model):
# ==============NECK DISABILITY INDEX ================
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)
#====1.Pain interval==========
    pi1 = models.BooleanField(default=False, verbose_name="I can tolerate the pain I have without having to see pain medications.")
    pi2 = models.BooleanField(default=False, verbose_name="The pain is very mild at the moment.")
    pi3 = models.BooleanField(default=False, verbose_name="The pain is moderate at the moment.")
    pi4 = models.BooleanField(default=False, verbose_name="The pain is fairly severe at the moment.")
    pi5 = models.BooleanField(default=False, verbose_name="The pain is very severe at the moment.")
    pi6 = models.BooleanField(default=False, verbose_name="The pain is most imaginable at the moment.")
#====2. Personal care, Washing, Dressing==========
    pk1 = models.BooleanField(default=False, verbose_name="I can take care of myself normally, without causing increased pain.")
    pk2 = models.BooleanField(default=False, verbose_name="I can take care of myself normally, but it increases my pain.")
    pk3 = models.BooleanField(default=False, verbose_name="It is painful to take care of myself, and I am slow and careful.")
    pk4 = models.BooleanField(default=False, verbose_name="I need help, but I am able to manage most of my personal care.")
    pk5 = models.BooleanField(default=False, verbose_name="I need help every day in most aspects of my care.")
    pk6 = models.BooleanField(default=False, verbose_name="I do not get dressed, I wash with difficulty, and I stay in bed.")
#====3.Lifting==========
    lift1 = models.BooleanField(default=False, verbose_name="I can lift heavy weighs without increased pain.")
    lift2 = models.BooleanField(default=False, verbose_name="I can lift heavy weights, but it causes increased pain.")
    lift3 = models.BooleanField(default=False, verbose_name="Pain prevents me from lifting heavy weights off the floor, but I can manage if the weights are conveniently positioned (on a table).")
    lift4 = models.BooleanField(default=False, verbose_name="Pain prevents me from lifting heavy weights off the floor, but I can manage light to medium weights if the weights are conveniently positioned.")
    lift5 = models.BooleanField(default=False, verbose_name="I can lift only very light weights.")
    lift6 = models.BooleanField(default=False, verbose_name="I cannot lift or carry anything at all.")
#====4.Reading==========
    read1 = models.BooleanField(default=False, verbose_name="I can read as much as I want to with no pain in my neck.")
    read2 = models.BooleanField(default=False, verbose_name="I can read as much as I want to with slight pain in my neck.")
    read3 = models.BooleanField(default=False, verbose_name="I can read as much as I want with moderate pain in my neck.")
    read4 = models.BooleanField(default=False, verbose_name="I can’t read as much as I want because of moderate pain in my neck.")
    read5 = models.BooleanField(default=False, verbose_name="I can hardly read at all because of severe pain in my neck.")
    read6 = models.BooleanField(default=False, verbose_name="I cannot read at all.")
#====5.Headache==========
    headache1 = models.BooleanField(default=False, verbose_name="I have no headaches at all.")
    headache2 = models.BooleanField(default=False, verbose_name="I have slight headaches, which come infrequently.")
    headache3 = models.BooleanField(default=False, verbose_name="I have moderate headaches, which come infrequently.")
    headache4 = models.BooleanField(default=False, verbose_name="I have moderate headaches, which come frequently.")
    headache5 = models.BooleanField(default=False, verbose_name="I have severe headaches, which come frequently.")
    headache6 = models.BooleanField(default=False, verbose_name="I have headaches almost all the time.")
#====6. Concentration==========
    conc1 = models.BooleanField(default=False, verbose_name="I can concentrate fully when I want to with no difficulty.")
    conc2 = models.BooleanField(default=False, verbose_name="I can concentrate fully when I want to with slight difficulty.")
    conc3 = models.BooleanField(default=False, verbose_name="I have a fair degree of difficulty in concentrating when I want to.")
    conc4 = models.BooleanField(default=False, verbose_name="I have a lot of difficulty in concentrating when I want to.")
    conc5 = models.BooleanField(default=False, verbose_name="I have a great deal of difficulty in concentrating when I want to.")
    conc6 = models.BooleanField(default=False, verbose_name="I cannot concentrate at all.")
#====7: Work==========
    work1 = models.BooleanField(default=False, verbose_name="I can do as much work as I want to.")
    work2 = models.BooleanField(default=False, verbose_name="I can only do my usual work, but no more.")
    work3 = models.BooleanField(default=False, verbose_name="I can do most of my usual work, but no more.")
    work4 = models.BooleanField(default=False, verbose_name="I cannot do my usual work.")
    work5 = models.BooleanField(default=False, verbose_name="I can hardly do any work at all.")
    work6 = models.BooleanField(default=False, verbose_name="I cant do any work at all.")
#====8: Driving
    driv1 = models.BooleanField(default=False, verbose_name="I can drive my car without any neck pain.")
    driv2 = models.BooleanField(default=False, verbose_name="I can drive my car as long as I want with slight pain in my neck.")
    driv3 = models.BooleanField(default=False, verbose_name="I can drive my car as long as I want with moderate pain in my neck.")
    driv4 = models.BooleanField(default=False, verbose_name="I cant drive my car as long as I want because of moderate pain in my neck.")
    driv5 = models.BooleanField(default=False, verbose_name="I can hardly drive at all because of severe pain in my neck.")
    driv6 = models.BooleanField(default=False, verbose_name="I cant drive my car at all.")
#====9: Sleeping
    sleep1 = models.BooleanField(default=False, verbose_name="I have no trouble sleeping.")
    sleep2 = models.BooleanField(default=False, verbose_name="My sleep is slightly disturbed (less than 1 hr sleepless.")
    sleep3 = models.BooleanField(default=False, verbose_name="My sleep is mildly disturbed (1-2 hrs sleepless.")
    sleep4 = models.BooleanField(default=False, verbose_name="My sleep is moderately disturbed (2-3 hrs sleepless.")
    sleep5 = models.BooleanField(default=False, verbose_name="My sleep is greatly disturbed (3-5 hrs sleepless.")
    sleep6 = models.BooleanField(default=False, verbose_name="My sleep is completely disturbed (5-7 hrs sleepless.")
#====10: Recreation
    rec1 = models.BooleanField(default=False, verbose_name="I am able to engage in all my recreation activities with no neck pain at all.")
    rec2 = models.BooleanField(default=False, verbose_name="I am able to engage in all my recreation activities, with some pain in my neck.")
    rec3 = models.BooleanField(default=False, verbose_name="I am able to engage in most, but not all of my usual recreation activities because of pain in my neck.")
    rec4 = models.BooleanField(default=False, verbose_name="I am able to engage in a few of my usual recreation activities because of pain in my neck.")
    rec5 = models.BooleanField(default=False, verbose_name="I can hardly do any recreation activities because of pain in my neck.")
    rec6 = models.BooleanField(default=False, verbose_name="I can’t do any recreation activities at all.")

    class Meta:
        verbose_name = 'Neck disability index'
# ==============assessment parameter ================
class assesspara(models.Model):
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)

    vasD0 = models.BooleanField(default=True, verbose_name="VAS scale (on rest and activity)")
    vasD8 = models.BooleanField(default=True, verbose_name="Range of motion by goniometer")
    vasD16 = models.BooleanField(default=True, verbose_name="Neck disability index")
    vasD30 =models.BooleanField(default=True, verbose_name="Spurling test")

    rmgD0 = models.BooleanField(default=True, verbose_name="")
    rmgD8 = models.BooleanField(default=True, verbose_name="")
    rmgD16 = models.BooleanField(default=True, verbose_name="")
    rmgD30 = models.BooleanField(default=True, verbose_name="")

    ndiD0 = models.BooleanField(default=True, verbose_name="")
    ndiD8 = models.BooleanField(default=True, verbose_name="")
    ndiD16 = models.BooleanField(default=True, verbose_name="")
    ndiD30 = models.BooleanField(default=True, verbose_name="")

    stestD0 = models.BooleanField(default=True, verbose_name="")
    stestD8 = models.BooleanField(default=True, verbose_name="")
    stestD16 = models.BooleanField(default=True, verbose_name="")
    stestD30 = models.BooleanField(default=True, verbose_name="")

    crtestD0 = models.BooleanField(default=True, verbose_name="")
    crtestD8 = models.BooleanField(default=True, verbose_name="")
    crtestD16 = models.BooleanField(default=True, verbose_name="")
    crtestD30 = models.BooleanField(default=True, verbose_name="")

    ditestD0 = models.BooleanField(default=True, verbose_name="")
    ditestD8 = models.BooleanField(default=True, verbose_name="")
    ditestD16 = models.BooleanField(default=True, verbose_name="")
    ditestD30 = models.BooleanField(default=True, verbose_name="")

    ulttestD0 = models.BooleanField(default=True, verbose_name="")
    ulttestD8 = models.BooleanField(default=True, verbose_name="")
    ulttestD16 = models.BooleanField(default=True, verbose_name="")
    ulttestD30 = models.BooleanField(default=True, verbose_name="")

    sprofileD0 = models.BooleanField(default=True, verbose_name="")
    sprofileD8 = models.BooleanField(default=True, verbose_name="")
    sprofileD16 = models.BooleanField(default=True, verbose_name="")
    sprofileD30 = models.BooleanField(default=True, verbose_name="")

    ncvD0 = models.BooleanField(default=True, verbose_name="")
    ncvD8 = models.BooleanField(default=True, verbose_name="")
    ncvD16 = models.BooleanField(default=True, verbose_name="")
    ncvD30 = models.BooleanField(default=True, verbose_name="")

    class Meta:
        verbose_name = 'Assessment parameters during followup'
# ==============ayurvedic parameter ================
class ayurvedicpara(models.Model):
    my_mala = (
        ("Baddha", "Baddha"),
        ("Abaddha", "Abaddha"),
        ("Vikrita", "Vikrita"),
        ("Prakrata", "Prakrata"),
        ("Atisara", "Atisara"),
        ("Pravahik", "Pravahik"),
        ("Grahini", "Grahini"),
        ("Anyother", "Any other"),
    )
    my_jivha = (
        ("coated", "Coated(lipta)"),
        ("Uncoated", "Uncoated(alipta)"),
        ("PartiallyCoated", "Partially Coated (Alpalipta)"),
        ("color", "Color"),
    )
    my_jivhacolor = (
        ("Whitish", "Whitish"),
        ("Pinkish", "Pinkish"),
        ("Blackish", "Blackish"),
    )
    my_drikcolor = (
        ("White", "White"),
        ("Pink", "Pink"),
        ("Red", "Red"),
        ("Yellow", "Yellow"),
    )
    my_akrita = (
        ("Sthula", "Sthula"),
        ("Madhyama", "Madhyama"),
        ("Heena", "Heena"),
    )
    my_Shabdha = (
        ("Prakrita", "Prakrita"),
        ("Vikrita", "Vikrita"),
    )
    my_mootra = (
        ("Prakrita", "Prakrita"),
        ("Vikrita", "Vikrita"),
    )
    my_sharirika = (
        ("V", "V"),
        ("P", "P"),
        ("VP", "VP"),
        ("VK", "VK"),
        ("PK", "PK"),
        ("Sama", "Sama"),
    )
    my_manasika = (
        ("S", "S"),
        ("R", "R"),
        ("T", "T"),
    )
    my_pranavaha = (
        ("Kupitaabhikshana","Kupitaabhikshana"),
        ("sashabhasholaucchvasa","sashabha shola ucchvasa"),
    )
    my_annavaha = (
        ("Anannabhilasha","Anannabhilasha"),
        ("arochaka","arochaka"),
        ("avipaka","avipaka"),
        ("chardi","chardi"),
    )
    my_udakavaha = (
                    ("Jihwashosha","Jihwashosha"),
                    ("talushosha","talushosha"),
                    ("oshtashosha","oshtashosha"),
                    ("kantashosha","kantashosha"),
                    ("klomashosha","klomashosha"),
                    ("atipravridhapipasa","atipravridhapipasa"),
                    )
    my_rasavaha = (
        ("Asraddha","Asraddha"),
        ("Aruchi","Aruchi"),
        ("Asyavairasya","Asyavairasya"),
        ("Arasajnata","Arasajnata"),
        ("Hrilasa","Hrilasa"),
        ("Gourava","Gourava"),
        ("Tandra","Tandra"),
        ("Angamar","Angamar"),
        ("Dajwara","Dajwara"),
        ("Tama","Tama"),
        ("Pandutva","Pandutva"),
        ("Srotorodha","Srotorodha"),
        ("Klaibya","Klaibya"),
        ("Sada","Sada"),
        ("Krishnangata","Krishnangata"),
        ("Agninasa","Agninasa"),
        ("Akaalavali","Akaalavali"),
        ("Akkaalapalitya","Akkaalapalitya"),
        ("Bhrama","Bhrama"),
        ("Glani","Glani"),
        ("Hritpida","Hritpida"),
        ("Trishna","Trishna"),
        ("Shabdaasahishnuta","Shabda asahishnuta"),
        ("kampa","kampa"),
        ("Shosa","Shosa"),
        ("Rukshata","Rukshata"),
    )
    my_raktavaha = (
                    ("Tilakalaka","Tilakalaka"),
                    ("Dadru","Dadru"),
                    ("Charmadala","Charmadala"),
                    ("Switra","Switra"),
                    ("pama","pama"),
                    ("kota","kota"),
                    ("asramandala","asramandala"),
                    ("amlaprartana","amlaprartana"),
                    ("sheetaprartana","sheetaprartana"),
                    ("Tvakrukshata","Tvak rukshata"),
                    ("Tvakpraushya","Tvakpraushya"),
                    ("TvakSputana","TvakSputana"),
                    ("Shinashitilya","Shina shitilya"),
                    ("Tvakmlanata","Tvakmlanata"),
                    ("Mukhapaka","Mukhapaka"),
                    ("Akshiroga","Akshiroga"),
                    ("Vaivarnya","Vaivarnya"),
                    ("Agnimandya","Agnimandya"),
                    ("Pipasadhikya","Pipasadhikya"),
                    ("Gurugatrta","Gurugatrta"),
                    ("Santapa","Santapa"),
                    ("Dourbalya","Dourbalya"),
                    ("Aruchi","Aruchi"),
                    ("Shirashoola","Shirashoola"),
                    ("Tiktaamlodhara","Tiktaamlodhara"),
                    ("Vidhaannapanasya","Vidhaannapanasya"),
                    ("Klama","Klama"),
                    ("Lavanasyata","Lavanasyata"),
                    ("Swedadhikya","Swedadhikya"),
                    ("Kampa","Kampa"),
                    ("Swarakshaya","Swarakshaya"),
                    ("Tandra","Tandra"),
                    ("Nidradhikya","Nidradhikya"),
                    ("tamapravesha","tamapravesha"),
                    ("kandu","kandu"),
                    ("pidaka","pidaka"),
                    ("pradar","pradar"),
                    ("Gudamedrasyapaka","Gudamedrasyapaka"),
                    ("pleeha","pleeha"),
                    ("gulma","gulma"),
                    ("vidradi","vidradi"),
                    ("neelika","neelika"),
                    ("kamala","kamala"),
                    ("vyanga","vyanga"),
                    ("piplava","piplava"),
                    )
    my_mamsavaha = (
                    ("Sandivedana","Sandivedana"),
                    ("Rukshata","Rukshata"),
                    ("Dhamanishitilya","Dhamanishitilya"),
                    ("Toda","Toda"),
                    ("Grivashuskata","Grivashuskata"),
                    ("Urushuskata","Urushuskata"),
                    ("Gatrasadana","Gatrasadana"),
                    ("Spikshushkata","Spikshushkata"),
                    ("Adhimamsa","Adhi mamsa"),
                    ("arbuda","arbuda"),
                    ("Keelaka","Keelaka"),
                    ("Galashaluka","Gala shaluka"),
                    ("Putimamsa","Putimamsa"),
                    ("alaji","alaji"),
                    ("Galaganda","Galaganda"),
                    ("Gandamala","Gandamala"),
                    ("Upajihwika","Upajihwika"),

                    )
    my_medovaha = (
        ("Astaninditapurushalakshana","Astanindita purusha lakshana"),
        ("Pramehapurvarupa","Pramehapurvarupa"),
    )
    my_asthivaha = (
        ("Adhyasthi","Adhyasthi"),
        ("Adhidantha","Adhidantha"),
        ("Danthabheda","Danthabheda"),
        ("Asthibheda","Asthibheda"),
        ("Vivarnata","Vivarnata"),
        ("Kesha","Kesha"),
        ("Loma","Loma"),
        ("Nakha","Nakha"),
        ("Smashrudosha","Smashru dosha"),
    )
    my_majjavaha = (
        ("Rukparvanam","Rukparvanam"),
        ("Bhrama","Bhrama"),
        ("Moorcha","Moorcha"),
        ("TamaDharshana","TamaDharshana"),
        ("Arumshika","Arumshika"),
        ("Sthoulaparva","Sthoula parva"),
    )
    my_sukravaha = (
                       ("Klaibhya","Klaibhya"),
                       ("Aharshana","Aharshana"),
    )
    my_mootravaha = (
                     ("Kupitam","Kupitam"),
                     ("sashoola","sashoola"),
                     ("bhahalam","bhahalam"),
                     ("mootrayanti","mootrayanti"),
                     )
    my_pureeshvaha = (
        ("Sashabdhashoola","Sashabdhashoola"),
        ("atidrava","atidrava"),
        ("atigrathitam","atigrathitam"),
        ("atibhahu","atibhahu"),
    )
    my_swedavaha = (
                    ("Aswedana","Aswedana"),
                    ("atiswedana","atiswedana"),
                    ("parushanga","parushanga"),
                    ("atishlakshanaanga","atishlakshanaanga"),
                    ("paridaha","paridaha"),
                    ("lomaharsha","lomaharsha"),
                    )

    my_sara=(
             ("Twak","Twak"),
             ("Rakta","Rakta"),
             ("Mamsa","Mamsa"),
             ("Meda","Meda"),
             ("Asthi","Asthi"),
             ("Shukra","Shukra"),
             ("Majja","Majja"),
             ("Satva","Satva"),
             )
    my_Samhanana=(
                  ("Susamhita","Susamhita"),
                  ("Madhyama","Madhyama"),
                  ("Heena","Heena"),
    )
    my_Pramana=(
        ("Supramanita","Supramanita"),
        ("Adhika","Adhika"),
        ("Heena","Heena"),
    )
    my_Satmya=(
        ("Ekarasa","Ekarasa"),
        ("Sarva","Sarva"),
        ("Rasa","Rasa"),
        ("Vyamishra","Vyamishra"),
        ("RookshaSatmya","RookshaSatmya"),
        ("SnigdaSatmya","SnigdaSatmya"),
    )
    my_Satva=(
            ("Pravara","Pravara"),
            ("Madhyama","Madhyama"),
            ("Avara","Avara"),
    )
    my_AbhyavaharanaShakti=(
        ("P","P"),
        ("M","M"),
        ("A","A"),
    )
    my_jaranashakti=(
        ("P","P"),
        ("M","M"),
        ("A","A"),
    )
    my_vyayamshakti=(
                        ("Pravara","Pravara"),
                        ("Madhyama","Madhyama"),
                        ("Avara","Avara"),
    )
    my_Vaya=(
                    ("Bala","Bala"),
                    ("Madhyama","Madhyama"),
                    ("Vrudda","Vrudda"),
    )


    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)

    nadi = models.CharField(max_length=50, blank=True, verbose_name="Nadi")
    mala = models.CharField(max_length=50, blank=True, choices=my_mala, verbose_name="Mala")
    mootra = models.CharField(max_length=50, blank=True, choices=my_mootra, verbose_name="Mootra")
    mootrafreqday = models.CharField(max_length=50, blank=True, verbose_name="Frequency: Day")
    mootrafreqnight = models.CharField(max_length=50, blank=True, verbose_name="Night")
    mootracolor = models.CharField(max_length=50, blank=True, verbose_name="Color")
    mootraother = models.CharField(max_length=50, blank=True, verbose_name="Other associated complaints")

    jivha = models.CharField(max_length=50, blank=True, choices=my_jivha, verbose_name="Jihva")
    jivhacolor = models.CharField(max_length=50, blank=True, choices=my_jivhacolor, verbose_name="Color")

    Shabdha  = models.CharField(max_length=50, blank=True, choices=my_Shabdha, verbose_name="Shabdha")

    sparshUshna = models.CharField(max_length=50, blank=True, verbose_name="Sparsha-Ushna")
    sparshAnushna = models.CharField(max_length=50, blank=True, verbose_name="-Anushna")
    sparshRuksha = models.CharField(max_length=50, blank=True, verbose_name="-Ruksha")
    sparshKhara = models.CharField(max_length=50, blank=True, verbose_name="-Khara")
    sparshMrudhu = models.CharField(max_length=50, blank=True, verbose_name="-Mrudhu")

    drik = models.CharField(max_length=50, blank=True, choices = my_drikcolor, verbose_name="Drik-Color of conjunctiva")
    akrita = models.CharField(max_length=50, blank=True, choices = my_akrita, verbose_name="Akrita ")
#========Dashvidh Pariksha=============
    sharirika = models.CharField(max_length=50, blank=True, choices = my_sharirika, verbose_name="Prakruti")
    manasika = models.CharField(max_length=50, blank=True, choices = my_manasika, verbose_name="Vikruti")
    vikrutidosha = models.CharField(max_length=50, blank=True, verbose_name="Vikruti-Dosha")
    vikrutidhatu = models.CharField(max_length=50, blank=True, verbose_name="-Dhatu")
    vikrutimala = models.CharField(max_length=50, blank=True, verbose_name="-Mala")

    Sara = models.CharField(max_length=50, blank=True, choices=my_sara, verbose_name="Sara")
    Samhanana = models.CharField(max_length=50, blank=True, choices=my_Samhanana, verbose_name="Samhanana")
    pramana = models.CharField(max_length=50, blank=True, choices=my_Pramana, verbose_name="Pramana")
    Satmya = models.CharField(max_length=50, blank=True, choices=my_Satmya, verbose_name="Satmya")
    Satva = models.CharField(max_length=50, blank=True, choices=my_Satva, verbose_name="Satva")
    abhyavaharanashakti = models.CharField(max_length=50, blank=True, choices=my_AbhyavaharanaShakti, verbose_name="Ahara Shakti-Abhyavaharana Shakti")
    jaranashakti = models.CharField(max_length=50, blank=True, choices=my_jaranashakti, verbose_name="-Jarana Shakti")
    vyayamshakti = models.CharField(max_length=50, blank=True, choices=my_vyayamshakti, verbose_name="Vyayam Shakti")
    vaya = models.CharField(max_length=50, blank=True, choices=my_Vaya, verbose_name="Vaya")
#=========Sroto Pareeksha===============
    pranavaha = models.CharField(max_length=50, blank=True, choices=my_pranavaha, verbose_name="Pranavaha")
    annavaha = models.CharField(max_length=50, blank=True, choices=my_annavaha, verbose_name="Annavaha")
    udakavaha = models.CharField(max_length=50, blank=True, choices=my_udakavaha, verbose_name="Udakavaha")
    rasavaha = models.CharField(max_length=50, blank=True, choices=my_rasavaha, verbose_name="Rasavaha")
    raktavaha = models.CharField(max_length=50, blank=True, choices=my_raktavaha, verbose_name="Raktavaha")
    mamsavaha = models.CharField(max_length=50, blank=True, choices=my_mamsavaha, verbose_name="Mamsavaha")
    medovaha = models.CharField(max_length=50, blank=True, choices=my_medovaha, verbose_name="Medovaha")
    asthivaha = models.CharField(max_length=50, blank=True, choices=my_asthivaha, verbose_name="Asthivaha")
    majjavaha = models.CharField(max_length=50, blank=True, choices=my_majjavaha, verbose_name="Majjavaha")
    sukravaha = models.CharField(max_length=50, blank=True, choices=my_sukravaha, verbose_name="Sukravaha")
    mootravaha = models.CharField(max_length=50, blank=True, choices=my_mootravaha, verbose_name="Mootravaha")
    pureeshvaha = models.CharField(max_length=50, blank=True, choices=my_pureeshvaha, verbose_name="Pureeshvaha")
    swedavaha = models.CharField(max_length=50, blank=True, choices=my_swedavaha, verbose_name="Swedavaha")

    class Meta:
        verbose_name = 'Ayurvedic parameters'

class uttarbhaktikasnehanacasesheet (models.Model):
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)

    dateofcompletion = models.DateField(null=False, verbose_name="Date Of Completion")
    dateofstarttreat = models.DateField(null=False, verbose_name="Date of starting treatment")
    chiefcomplaint = models.CharField(max_length=50, blank=True,verbose_name="Chief Complaints")
    examination = models.CharField(max_length=50, blank=True, verbose_name="Examination")
    ghritused = models.CharField(max_length=50, blank=True, verbose_name="Ghrita to be used")

    qty = models.CharField(max_length=50, blank=True, verbose_name="Qty of ghrita")
    time = models.TimeField(null=True, verbose_name="Time")
    duration = models.CharField(max_length=50, blank=True, verbose_name="Duration")
    bp = models.CharField(max_length=50, blank=True, verbose_name="B.P")
    pulse = models.CharField(max_length=50, blank=True, verbose_name="Pulse")
    complications = models.CharField(max_length=50, blank=True, verbose_name="Complications")
    treatment  = models.CharField(max_length=50, blank=True, verbose_name="Treatment")
    assessment_1 = models.TextField(max_length=200, blank=True, verbose_name="Assessment of tests on 1st day")
    assessment_30 = models.TextField(max_length=200, blank=True, verbose_name="Assessment of tests on 30st day")

    class Meta:
        verbose_name = 'Uttarbhaktikasnehana case sheet'

class manyabasticasesheet(models.Model):
        registrationdate = models.DateField(null=False)
        opdno = models.IntegerField(null=False)
        caseno = models.IntegerField(null=False)
        crno = models.IntegerField(null=False)
        ipdno = models.IntegerField(null=False)

        dateofstarttreat = models.DateField(null=False, verbose_name="Date of starting Treatment")
        dateofcompletion = models.DateField(null=False, verbose_name="Date Of Completion ")
        chiefcomplaint = models.CharField(max_length=50, blank=True, verbose_name="Chief Complaints")
        examination = models.CharField(max_length=50, blank=True, verbose_name="Examination")
        oilused = models.CharField(max_length=50, blank=True, verbose_name="Oil to be used")

        qty = models.CharField(max_length=50, blank=True, verbose_name="Qty of ghrita")
        time = models.TimeField(null=True, verbose_name="Time")
        duration = models.CharField(max_length=50, blank=True, verbose_name="Duration")
        bp = models.CharField(max_length=50, blank=True, verbose_name="B.P")
        pulse = models.CharField(max_length=50, blank=True, verbose_name="Pulse")
        complications = models.CharField(max_length=50, blank=True, verbose_name="Complications")
        treatment = models.CharField(max_length=50, blank=True, verbose_name="Treatment")
        assessment_1 = models.TextField(max_length=200, blank=True, verbose_name="Assessment of tests on 1st day")
        assessment_30 = models.TextField(max_length=200, blank=True, verbose_name="Assessment of tests on 30st day")

        class Meta:
            #db_table = 'manyabasticasesheet'
            verbose_name = 'Manya Basti case sheet'



# ==============SUBJECTIVE PARAMETERS ================
# class examination(models.Model):
#     registrationdate = models.DateField()
#     opdno = models.IntegerField(null=True)
#     caseno = models.IntegerField(null=True)
#     crno = models.IntegerField(null=True)
#     ipdno = models.IntegerField(null=True)
#
#     respsystem = models.CharField(max_length=200)
#     gastrointestsystem = models.CharField(max_length=200)
#     cardiovascsystem = models.CharField(max_length=200)
#     nervoussystem = models.CharField(max_length=200)
#     superficialreflexplanter = models.CharField(max_length=50,choices= my_Superficialreflexesplantar)
#     superficialreflexabdominal = models.CharField(max_length=50,choices=my_Superficialreflexesabdominal)
#
#     deepreflexbicepjerk = models.CharField(max_length=50,choices=my_deepreflexesbicepsjerk)
#     deepreflexkneejerk = models.CharField(max_length=50,choices=my_deepreflexeskneejerk)
#     deepreflexanklejerk = models.CharField(max_length=50,choices=my_deepreflexesanklejerk )
#
#     signofmenirr = models.CharField(max_length=50,choices=my_signofmenirr)
#     neckstiff = models.CharField(max_length=50,choices=my_neckstiffness)
#
#     gait = models.CharField(max_length=50,choices=my_gait)
#     deformities = models.CharField(max_length=50,choices=my_deformities)
#
#     musclewaisting = models.CharField(max_length=50,choices=my_musclewasting)
#     asymmetry = models.CharField(max_length=50,choices=my_asymmetry)
#     redness = models.CharField(max_length=50,choices=my_redness)
#     inflammation = models.CharField(max_length=50,choices= my_inflammation)
#     muscletwitch = models.CharField(max_length=50,choices=my_muscletwitch)
#     swellingjoints = models.CharField(max_length=50,choices=my_swellinjoints)
#     scaresjoints = models.CharField(max_length=50,choices=my_scaresjoints)
#
#     warmth = models.CharField(max_length=50,choices=my_palpwarmth)
#     tenderness = models.CharField(max_length=50,choices=my_palptenderness)
#     swelling = models.CharField(max_length=50,choices=my_palpswelling)
#     effusion = models.CharField(max_length=50,choices=my_palpeffusion)
#     crepitus = models.CharField(max_length=50,choices=my_palpcrepitus)
#     activemovement = models.CharField(max_length=50,choices=my_palpactivemov)
#     passivemovement = models.CharField(max_length=50,choices=my_palppassivemov)
#
#     spine = models.CharField(max_length=50,choices=my_spine)
#     gait1 = models.CharField(max_length=50,choices=my_gait1)
#     bone = models.CharField(max_length=50,choices=my_bone)
#     neck = models.CharField(max_length=50,choices=my_neck)
#     handswelljoints = models.CharField(max_length=50,choices=my_handsswelling)
#     handfingdefo = models.CharField(max_length=50,choices=my_handsfingdef)
#     handfingmode = models.CharField(max_length=50,choices=my_handsfingnodes)
#

