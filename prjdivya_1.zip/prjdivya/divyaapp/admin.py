from django.contrib import admin
from .models import perdemoinfo
from .models import clinicalprofile
from .models import incexccriteria
from .models import subjectivepara
from .models import objectivepara
from .models import bioradioinv
from .models import neckdisabilityindex
from .models import assesspara
from .models import ayurvedicpara
from .models import uttarbhaktikasnehanacasesheet
from .models import manyabasticasesheet

# from django.contrib.admin import AdminSite
# class DivyaAdminSite(AdminSite):
#     site_header = "Divya Admin"
#     site_title = "Divya Admin Portal"
#     index_title = "Welcome to Divya Researcher Events Portal"
#
#     event_admin_site = DivyaAdminSite(name='divya_admin');

#from .models import examination

admin.site.site_header="PROJECT BY DIVYA"
admin.site.site_title = "PROJECT BY PANCHAKARMA DEPARTMENT"
admin.site.index_title = "Welcome to Researcher Portal : PANCHAKARMA DEPARTMENT"

admin.site.disable_action('delete_selected')

# Register your models here.
@admin.register(perdemoinfo)
class perdemoinfoAdmin(admin.ModelAdmin):
    list_display= ('registrationdate','opdno','crno','caseno','ipdno','patientname','gender','agemn','dob','ageyr','address','contactno','email','marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify')
    search_fields=('opdno','crno','patientname')
    ordering=['patientname']
    list_filter=('ageyr','gender')

    fieldsets=[
        ('Personal Information', {'fields':['registrationdate','opdno','crno','caseno','ipdno','patientname','gender','dob','ageyr','agemn','address','contactno','email']}),
        ('Demographic Information', {'fields':['marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify']})
    ]
    # fieldsets=[
    #     ('Personal_Information', {'fields':['registrationdate','opdno']}),
    #     ('Demographic_Information', {'fields':['marritalstatus','edustatus']})
    # ]


@admin.register(clinicalprofile)
class clinicalprofileAdmin(admin.ModelAdmin):
    #list_display= ('registrationdate','opdno','crno','caseno','ipdno','dietaryhabit','addiction','addqty','addduration','sleep','bowelhabitat','stoolcons','urineoutput','phyex','alltomaterial','natureofall','symptoms','emotionalstress','gyncobshis','menarche','menopause','lmp','whitedisch', 'familyhist','surhis','prevhistoryspecify','builtavg','nutrition','height','weight','bmi','waistcirm','resprate','pulserate','bp','clubbing','cyanosis','cyanosispresent','temp','pallor','lymphadenopathy','edema','character','siteaffected','joints','jointsabnormal')
    list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
    search_fields = ['ipdno']
    fieldsets=[
     ('Personal History', {'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno', 'dietaryhabit', 'addiction', 'addqty', 'addduration','sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex', 'alltomaterial', 'natureofall', 'symptoms','emotionalstress']}),
     ('Gynecological & Obstetric_History',{'fields':['gyncobshis', 'menarche', 'menopause', 'lmp', 'whitedisch']}),

      ('Family History',{'fields':['familyhist']}),
      ('Surgical History', {'fields': ['surhis']}),
      ('Previous History', {'fields': ['prevhistoryspecify']}),
      ('General Physical Examination',{'fields': ['builtavg', 'nutrition', 'height', 'weight', 'bmi', 'waistcirm', 'resprate', 'pulserate',
      'bp', 'clubbing', 'cyanosis', 'cyanosispresent', 'temp', 'pallor', 'lymphadenopathy', 'edema', 'character',
      'siteaffected', 'joints', 'jointsabnormal']}),

      ('Respiratory System:', {'fields': ['respsystem']}),
      ('Gastro-Intestinal System:', {'fields': ['gastrointestsystem']}),
      ('Cardio-vascular System:', {'fields': ['cardiovascsystem']}),
      ('Nervous System:', {'fields': ['nervoussystem']}),

      ('Superficial reflexes:', {'fields': ['superficialreflexplanter','superficialreflexabdominal']}),
      ('Deep reflexes:', {'fields': ['deepreflexbicepjerk', 'deepreflexkneejerk','deepreflexanklejerk']}),

      ('Signs of Meningeal Irritation', {'fields': ['signofmenirr', 'neckstiff']}),

      ('Musculo-skeletal system', {'fields': ['gait', 'deformities','musclewaisting','asymmetry','redness','inflammation','muscletwitch','swellingjoints','scaresjoints']}),

     ('Palpation :', {'fields': ['warmth', 'tenderness', 'swelling', 'effusion', 'crepitus', 'activemovement', 'passivemovement']}),
     ('', {'fields': ['gait1', 'bone', 'neck', 'handswelljoints', 'handfingdefo', 'handfingmode']}),
    ]



@admin.register(incexccriteria)
class incexccriteriaAdmin(admin.ModelAdmin):
     list_display = ('registrationdate','opdno','crno','caseno','ipdno')
     fieldsets=[
                ('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                ('Inclusion Creteria :', {'fields':['ic1','ic2','ic3']}),
                ('Exclusion Creteria :', {'fields': ['ec1', 'ec2', 'ec3','ec4','ec5','ec6']}),
                ('Screening Form Questions :', {'fields': ['sfq1', 'sfq2', 'sfq3', 'sfq4', 'sfq5', 'sfq6', 'sfq7']}),
     ]

@admin.register(subjectivepara)
class subjectiveparaAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
    search_fields = ['ipdno']
    fieldsets = [('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                 ('Subjective Parameter :', {'fields': [('sympBT1', 'sympBT11', 'sympAT1', 'sympAT11'),
                                                        ('sympBT2', 'sympBT22', 'sympAT2', 'sympAT22'),
                                                        ('sympBT3', 'sympBT33', 'sympAT3', 'sympAT33'),
                                                        ('sympBT4', 'sympBT44', 'sympAT4', 'sympAT44'),
                                                        ('sympBT5', 'sympBT55', 'sympAT5', 'sympAT55'),
                                                        ('sympBT6', 'sympBT66', 'sympAT6', 'sympAT66'),
                                                        ('sympBT7', 'sympBT77', 'sympAT7', 'sympAT77'),
                                                        ('sympBT8', 'sympBT88', 'sympAT8', 'sympAT88'),
                                                        ('sympBT9', 'sympBT99', 'sympAT9', 'sympAT99'),
                                                        ]}),
                 ]
@admin.register(objectivepara)
class objectiveparaAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
    search_fields = ['ipdno']
    fieldsets = [('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                 ('1.Neck disability index:', {'fields': [('paraBT1','paraAT1')]}),
                 ('2.Visual analog scale :', {'fields': [('paraBT21', 'paraAT21'),('paraBT22', 'paraAT22')]}),

                 ('3.Range of motion through goniometer:', {'fields': [ ('paraBTRT31','paraBTLT31','paraATRT31','paraATLT31'),
                                                                        ('paraBTRT32','paraBTLT32','paraATRT32','paraATLT32'),
                                                                        ('paraBTRT33','paraBTLT33','paraATRT33','paraATLT33'),
                                                                        ('paraBTRT34','paraBTLT34','paraATRT34','paraATLT34'),
                                                                        ('paraBTRT35','paraBTLT35','paraATRT35','paraATLT35'),
                                                                        ('paraBTRT36','paraBTLT36','paraATRT36','paraATLT36'),
                                                                        ('paraBTRT37','paraBTLT37','paraATRT37','paraATLT37'),
                                                                        ('paraBTRT38','paraBTLT38','paraATRT38','paraATLT38'),
                                                                        ('paraBTRT39','paraBTLT39','paraATRT39','paraATLT39'),
                                                                        ('paraBTRT310','paraBTLT310','paraATRT310','paraATLT310'),
                                                                        ('paraBTRT311', 'paraBTLT311', 'paraATRT311','paraATLT311'),
                                                                       ]}),
                ('4.Foraminal compression Spurling’s test:', {'fields': ['paraAT5']}),
                ('5.Distraction test:', {'fields': ['paraAT6']}),
                ('6.Upper limb tension test brachial plexus tension or Elvey test:', {'fields': ['paraAT7']}),
                ('7.Cervical rotation test:', {'fields': ['paraAT8']}),
                ('8.Nerve conduction velocity test:', {'fields': ['paraAT9']}),
    ]

@ admin.register(bioradioinv)
class bioradioinvAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
        search_fields = ['ipdno']
        fieldsets = [
                     ('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                     ('HbA1c:', {'fields': [('hba1cBP', 'hba1cAP')]}),
                     ('Total Cholesterol:', {'fields': [('totalcolBP', 'totalcolAP')]}),
                     ('HDL-C:', {'fields': [('hdlcBP', 'hdlcAP')]}),
                     ('Triglycerides:', {'fields': [('triglyBP', 'triglycAP')]}),
                     ('VLDL:', {'fields': [('vldlBP', 'vldlAP')]}),
                     ('TC-HDL Ratio:', {'fields': [('tchdlratioBP', 'tchdlratioAP')]}),
                     #('3. Kidney Function tests:', {'fields': [('', '')]}),
                     ('Urea:', {'fields': [('ureaBP', 'ureaAP')]}),
                     ('Uric acid:', {'fields': [('uricacidBP', 'uricacidAP')]}),
                     ('Sr. Creatinine:', {'fields': [('creatinineBP', 'creatinineAP')]}),
                     ('Sr. Albumin:', {'fields': [('albuminBP', 'albuminAP')]}),
                     ('ALT:', {'fields': [('altBP', 'altAP')]}),
                     ('AST:', {'fields': [('astBP', 'astAP')]}),
                     ('ALP:', {'fields': [('alpBP', 'alpAP')]}),
                     ('Sr. Bilirubin:', {'fields': [('bilirubinBP', 'bilirubinAP')]}),
                     ('5.Nerve conduction velocity test of bilateral upper limb:', {'fields': [('nervecondvelBP', 'nervecondvelAP')]}),
                     ]

@ admin.register(neckdisabilityindex)
class neckdisabilityindexAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
        search_fields = ['ipdno']
        fieldsets = [
                     ('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                     ('1.Pain interval', {'fields': [('pi1','pi2','pi3','pi4','pi5','pi6')]}),
                     ('2. Personal care, Washing, Dressing', {'fields': [('pk1', 'pk2', 'pk3', 'pk4', 'pk5', 'pk6')]}),
                     ('3.Lifting', {'fields': [('lift1', 'lift2', 'lift3', 'lift4', 'lift5', 'lift6')]}),
                     ('4.Reading', {'fields': [('read1', 'read2', 'read3', 'read4', 'read5', 'read6')]}),
                     ('5.Headache', {'fields': [('headache1', 'headache2', 'headache3', 'headache4', 'headache5', 'headache6')]}),
                     ('6. Concentration', {'fields': [('conc1', 'conc2', 'conc3', 'conc4','conc5', 'conc6')]}),
                     ('7: Work', {'fields': [('work1', 'work2', 'work3', 'work4', 'work5', 'work6')]}),
                     ('8: Driving', {'fields': [('driv1', 'driv2', 'driv3', 'driv4', 'driv5', 'driv6')]}),
                     ('9: Sleeping', {'fields': [('sleep1', 'sleep2', 'sleep3', 'sleep4', 'sleep5', 'sleep6')]}),
                     ('10: Recreation', {'fields': [('rec1', 'rec2', 'rec3', 'rec4', 'rec5', 'rec6')]}),

]

@ admin.register(assesspara)
class assessparaAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
        search_fields = ['ipdno']
        fieldsets = [
                     ('', {'fields': ['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                     ('VAS scale on rest and activity', {'fields': [('vasD0','vasD8','vasD16','vasD30')]}),
                     ('Range of motion by goniometer', {'fields': [('rmgD0','rmgD8','rmgD16','rmgD30')]}),
                     ('Neck disability index', {'fields': [('ndiD0', 'ndiD8', 'ndiD16', 'ndiD30')]}),
                     ('Spurling test', {'fields': [('stestD0', 'stestD8', 'stestD16', 'stestD30')]}),
                     ('Cervical rotation test', {'fields': [('crtestD0', 'crtestD8', 'crtestD16', 'crtestD30')]}),
                     ('Distraction test', {'fields': [('ditestD0', 'ditestD8', 'ditestD16', 'ditestD30')]}),
                     ('Upper limb tension test -brachial plexus tension or Elvey test', {'fields': [('ulttestD0', 'ulttestD8', 'ulttestD16', 'ulttestD30')]}),
                     ('Safety profile-HbA1c,LFT,KFT,Lipid profile', {'fields': [('sprofileD0', 'sprofileD8', 'sprofileD16', 'sprofileD30')]}),
                     ('Nerve conduction velocity test', {'fields': [('ncvD0', 'ncvD8', 'ncvD16', 'ncvD30')]}),

]

@admin.register(ayurvedicpara)
class ayurvedicparaAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
        search_fields = ['ipdno']
        fieldsets = [
            ('', {'fields': ['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
            ('Ashta Sthana Pareeksha:', {'fields': ['nadi','mala','mootra','mootrafreqday','mootrafreqnight','mootracolor','mootraother',
                                         'jivha','jivhacolor','Shabdha','sparshUshna','sparshAnushna','sparshRuksha','sparshKhara','sparshMrudhu','drik','akrita']}),
            ('Dashvidh Pareeksha:',
             {'fields': ['sharirika', 'manasika', 'vikrutidosha', 'vikrutidhatu', 'vikrutimala', 'Sara', 'Samhanana',
                         'pramana', 'Satmya', 'Satva', 'abhyavaharanashakti', 'jaranashakti', 'vyayamshakti','vaya']}),

            ('Sroto Pareeksha:',
             {'fields': ['pranavaha', 'annavaha', 'udakavaha', 'rasavaha', 'raktavaha', 'mamsavaha', 'medovaha',
                         'asthivaha', 'majjavaha', 'sukravaha', 'mootravaha', 'pureeshvaha', 'swedavaha']}),

]

@admin.register(uttarbhaktikasnehanacasesheet)
class uttarbhaktikasnehanacasesheetAdmin(admin.ModelAdmin):
            list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
            search_fields = ['ipdno']
            fieldsets = [
                ('', {'fields': ['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                ('Ashta Sthana Pareeksha:',
                 {'fields': ['dateofstarttreat','dateofcompletion',  'chiefcomplaint', 'examination', 'ghritused',
                             'qty', 'time','duration', 'bp', 'pulse', 'complications', 'treatment','assessment_1','assessment_30']}),
            ]

@admin.register(manyabasticasesheet)
class manyabasticasesheetAdmin(admin.ModelAdmin):

            list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
            search_fields = ['ipdno']
            fieldsets = [
                ('', {'fields': ['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                ('Ashta Sthana Pareeksha:',
                 {'fields': ['dateofstarttreat','dateofcompletion',  'chiefcomplaint', 'examination', 'oilused',
                             'qty', 'time','duration', 'bp', 'pulse', 'complications', 'treatment','assessment_1','assessment_30']}),

            ]


# @ admin.register(assesspara)
# class assessparaAdmin(admin.ModelAdmin):
#         list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
#         search_fields = ['ipdno']
#         fieldsets = [('VAS scale on rest and activity', {'fields': [('vasD0','vasD8','vasD16','vasD30')]}),
#
# ]





























