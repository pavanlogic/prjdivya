from django.db import models
from django.utils import timezone
from  datetime import datetime,date

class screeningbhav(models.Model):
    my_gender = (
        ("Male", "Male"),
        ("Female", "Female"),
    )
    my_ic = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_jinv = (
        ("0", "0"),
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
        ("5", "5"),
    )
    my_sero = (
        ("0", "0"),
        ("2", "2"),
        ("3", "3"),
    )
    my_apr = (
        ("0", "0"),
        ("1", "1"),
    )
    my_dusymp = (
        ("0", "0"),
        ("1", "1"),
    )

    centre = models.CharField(max_length=200, verbose_name="Centre")
    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    crno = models.IntegerField(null=True, verbose_name="CR No.")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")
    patientname = models.CharField(max_length=200,verbose_name="Name of Participant")

    ageyr = models.IntegerField(verbose_name="Age(Year)")
    agemn = models.IntegerField(verbose_name="Age(Month)")
    dob = models.DateField(verbose_name="D.O.B")
    gender = models.CharField(max_length=50, choices=my_gender, verbose_name="Gender")
    address = models.CharField(max_length=200,verbose_name="Address")
    contactno = models.CharField(max_length=50,verbose_name="Contact No.")
    email = models.EmailField(max_length=100,verbose_name="Email")

    # ==============INCLUSION CRITERIA================
    ic1 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject aged between 18 to 60 years?")
    ic2 = models.CharField(max_length=50, choices=my_ic, verbose_name="Has the subject willingly given written informed consent?")
    ic3 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subjectfulfilling the 2010 ACR / EULAR criteria for rheumatoid arthritis?")
    ic4 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject had chronicity of disease of at least 6 months and not more than 5 years?")
    ic5 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subjecthaving at least 4 symptoms out of these 9 classical symptoms: sandhisotha (swelling in multiple joints), sandhiruja (polyarthralgia), gatrasatabdta (stiffness in body parts), angamarda (bodyache), jwara (fever), aruchi (anorexia), aalasya (laziness), utsaha-hani (lack of enthusiasm), gauravam (heaviness).")
    # ==============EXCLUSION CRITERIA================
    ec1 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject is strictly contradicted for virechan karma like muktanala, gudabhransa?")
    ec2 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject had chronicity of disease less than 6 months and more than 5 years?")
    ec3 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject having severe crippling bone deformities and severely damaged joints?")
    ec4 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the diabetic subject having HbA1c more than 7.5%?")
    ec5 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject immune-compromised?")
    ec6 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject diagnosed with malignancy of any system?")
    ec7 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject having CRF, fatty liver stage 3 and chronic illness of other body organs?")
    ec8 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject pregnant women and lactating mothers?")
    ec9 = models.CharField(max_length=50, choices=my_ic, verbose_name="Is the subject had a history of Cholecystectomy?")
    #===========================CONSENT=====================
    iconsent = models.CharField(max_length=50, choices=my_ic, verbose_name="Informed consent taken :")
    # ===========================DIAGNOSTIC CRITERIA=====================
    jinv = models.CharField(max_length=50, choices=my_jinv, verbose_name="Joint Involvement")
    sero = models.CharField(max_length=50, choices=my_sero, verbose_name="Serology")
    apr = models.CharField(max_length=50, choices=my_apr, verbose_name="Acute-phase reactants ")
    dusymp = models.CharField(max_length=50, choices=my_dusymp, verbose_name="Duration of symptoms")
    #=======================================================
    class Meta:
        verbose_name = 'CASE RECORD FORM  1:  SCREENING'
        verbose_name_plural = "1. Case Record Form 1(Screening):"

class baselineassbhav(models.Model):
    my_gender = (
        ("Male", "Male"),
        ("Female", "Female"),
    )

    my_marritalstatus = (
        ("Married", "Married"),
        ("Unmarried", "Unmarried"),
        ("other", "other"),
    )

    my_edustatus = (
        ("Illiterate", "Illiterate"),
        ("Literate", "Literate"),
    )

    my_socecostatus = (
        ("Above Poverty Line", "Above Poverty Line"),
        ("Below Poverty Line", "Below Poverty Line"),
    )

    my_habitat = (
        ("Urban", "Urban"),
        ("Semi-Urban", "Semi-Urban"),
        ("Rural", "Rural"),
    )

    my_religion = (
        ("Hindu", "Hindu"),
        ("Muslim", "Muslim"),
        ("Sikh", "Sikh"),
        ("Christian", "Christian"),
        ("Others", "Others"),
    )

    my_prevhis = (
        ("Yes", "Yes"),
        ("No", "No"),
    )

    centre = models.CharField(max_length=200, verbose_name="Centre")
    inductiondate = models.DateField(null=True,verbose_name="Date od induction into study")
    completiondate = models.DateField(null=True, verbose_name="Date od induction into study")
    crno = models.IntegerField(null=True, verbose_name="CR No.")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")
    # patientname = models.CharField(max_length=200,verbose_name="Name of Participant")
    # ageyr = models.IntegerField(verbose_name="Age(Year)")
    # agemn = models.IntegerField(verbose_name="Age(Month)")
    # dob = models.DateField(verbose_name="D.O.B")
    # gender = models.CharField(max_length=50, choices=my_gender, verbose_name="Gender")
    # address = models.CharField(max_length=200,verbose_name="Address")
    # contactno = models.CharField(max_length=50,verbose_name="Contact No.")
    # email = models.EmailField(max_length=100,verbose_name="Email")

    marritalstatus = models.CharField(max_length=50, choices=my_marritalstatus, verbose_name="Marrital Status")
    edustatus = models.CharField(max_length=50, choices=my_edustatus, verbose_name="Educational Status")
    education = models.CharField(max_length=200, verbose_name="Education")
    qualification = models.CharField(max_length=200, verbose_name="Qualification")
    socecostatus = models.CharField(max_length=50, choices=my_socecostatus, verbose_name="Socio-Economic Status")
    habitat = models.CharField(max_length=50, choices=my_habitat, verbose_name="Habitat")
    religion = models.CharField(max_length=50, choices=my_religion, verbose_name="Religion")
    chiefcomplaint = models.CharField(max_length=200, verbose_name="Chief Complaint")
    #durationofillness = models.CharField(max_length=200, verbose_name="Duration Of Illness")
    #otherinfo = models.CharField(max_length=200, verbose_name="Any other information")
    preshistory = models.CharField(max_length=50, choices=my_prevhis,verbose_name="History of Present illness")
    prevhistoryyesno = models.CharField(max_length=1000,choices=my_prevhis, verbose_name="History of Previous illness")
    surghistory=models.CharField(max_length=200, verbose_name="Surgical History")

    class Meta:
        verbose_name = 'Case Record Form 2:(Baseline Assessment'
        verbose_name_plural = "2. Case Record Form 2:(Baseline Assessment"

class clinicalprofilebhav(models.Model):
    my_diethabit = (
        ("Vegetarian", "Vegetarian"),
        ("Non-Vegetarian", "Non-Vegetarian"),
    )
    my_addictions = (
        ("Tea","Tea"),
        ("Coffee", "Coffee"),
        ("Tea","Tea"),
        ("Coffee","Coffee"),
        ("Alcohol", "Alcohol"),
        ("Tobacco", "Tobacco"),
        ("Smoking", "Smoking"),
        ("None", "None"),
    )
    my_sleep = (
        ("Normal", "Normal"),
        ("Disturbed", "Disturbed"),
    )
    my_bowelhabit = (
        ("Regular", "Regular"),
        ("Irregular", "Irregular"),
    )
    my_stoolconsist = (
        ("Normal", "Normal"),
        ("Loose", "Loose"),
        ("Constipated", "Constipated"),
    )
    my_urineoutput = (
        ("Normal", "Normal"),
        ("Frequent", "Frequent"),
        ("Urgency", "Urgency"),
        ("Strangury", "Strangury"),
        ("Nocturia", "Nocturia"),
    )
    my_physicalex = (
        ("Heavy Labour", "Heavy Labour"),
        ("Moderate Labour", "Moderate Labour"),
        ("Office Job", "Office Job"),
        ("Sedentary", "Sedentary"),
    )
    my_alltomaterial = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_emostress = (
        ("Average", "Average"),
        ("Moderate", "Moderate"),
        ("Too Much", "Too Much"),
    )
    my_gyncobshis = (
        ("Applicable", "Applicable"),
        ("Non-Applicable", "Non-Applicable"),
    )
    my_whitedisch = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_built = (
        ("Average", "Average"),
        ("Emaciated", "Emaciated"),
        ("Well built", "Well built"),
        ("Tall", "Tall"),
        ("Dwarf", "Dwarf"),
    )
    my_nutrition=(
        ("ModeratelyNourished", "Moderately nourished"),
        ("Malnourished", "Malnourished"),
        ("Wellnourished ", "Well nourished "),
    )
    my_clubbing = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosis = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosispresent = (
        ("Central", "Central"),
        ("Peripheral", "Peripheral"),
    )
    my_pallor = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_lymphadenopathy = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_edema = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_character = (
        ("Pitting", "Pitting"),
        ("Non- pitting", "Non- pitting"),
    )
    my_veribralcol = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    dietaryhabit = models.CharField(max_length=50,choices=my_diethabit, blank=True,verbose_name="Dietary Habits")
    addiction = models.CharField(max_length=50,choices=my_addictions, blank=True,verbose_name="Addiction")
    addqty = models.CharField(max_length=200, blank=True,verbose_name="Specify quantity/day")
    addduration = models.CharField(max_length=200, blank=True,verbose_name="Duration of Addiction")
    sleep = models.CharField(max_length=50,choices=my_sleep, blank=True,verbose_name="Sleep")
    bowelhabitat = models.CharField(max_length=50,choices=my_bowelhabit, blank=True,verbose_name="Bowel Habits")
    stoolcons = models.CharField(max_length=50,choices=my_stoolconsist, blank=True,verbose_name="Stool Consistency")
    urineoutput = models.CharField(max_length=50,choices=my_urineoutput, blank=True,verbose_name="Urine Output")
    phyex = models.CharField(max_length=50,choices=my_physicalex, blank=True,verbose_name="Physical Exercise")
    alltomaterial = models.CharField(max_length=50,choices=my_alltomaterial, blank=True,verbose_name="Allergy to Some Material")
    natureofall = models.CharField(max_length=200,choices=my_emostress, blank=True,verbose_name="If yes, then nature of the allergen")
    symptoms = models.CharField(max_length=200, blank=True,verbose_name="Symptom(s) produced upon exposure")
    emotionalstress = models.CharField(max_length=50,choices=my_emostress, blank=True,verbose_name="Emotional Stresses")
    gyncobshis = models.CharField(max_length=50,choices=my_gyncobshis, blank=True,verbose_name="Gynecological/obstetric history")

    menarche = models.CharField(max_length=200, blank=True,verbose_name="a)Menarche(years)")
    menopause = models.CharField(max_length=200, blank=True,verbose_name="b)Menopause(years")
    lmp = models.DateField(null=True, blank=True,verbose_name="LMP")
    whitedisch = models.CharField(max_length=50,choices=my_whitedisch, blank=True,verbose_name="White discharge per vagina")

    familyhist = models.TextField(max_length=200, blank=True,verbose_name="Family History")
    #surhis =  models.TextField(max_length=200, blank=True,verbose_name="Surgical History")
    #prevhistoryspecify = models.TextField(max_length=200, blank=True,verbose_name="Previous History (specify)")

    builtavg = models.CharField(max_length=50,choices=my_built, blank=True,verbose_name="Built")
    nutrition = models.CharField(max_length=50,choices=my_nutrition, blank=True,verbose_name="Nutrition")

    height = models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="Height(cm)")
    weight= models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="Weight(kg)")
    bmi = models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="B.M.I.(kg/m2) ")

    waistcirm = models.DecimalField(max_digits=5,decimal_places=1, default=0,verbose_name="Waist Circumference (cm)")
    resprate = models.IntegerField(default=0,verbose_name="Respiratory Rate(/minute)")
    pulserate = models.IntegerField(default=0,verbose_name="Pulse Rate(/minute)")
    bp = models.CharField(max_length=100, null=True, blank=True,verbose_name="Blood Pressure(mmHg)")

    clubbing = models.CharField(max_length=100,choices=my_clubbing, blank=True,verbose_name="Clubbing")
    cyanosis = models.CharField(max_length=100,choices=my_cyanosis, blank=True,verbose_name="Cyanosis")
    cyanosispresent = models.CharField(max_length=100,choices=my_cyanosispresent, blank=True,verbose_name="If present")

    temp = models.DecimalField(max_digits=5,decimal_places=1,null=True, blank=True,verbose_name="Temperature(oF)")
    pallor = models.CharField(max_length=50,choices=my_pallor, blank=True,verbose_name="Pallor")
    lymphadenopathy = models.CharField(max_length=50,choices=my_lymphadenopathy, blank=True,verbose_name="Lymphadenopathy")
    edema = models.CharField(max_length=50,choices=my_edema, blank=True,verbose_name="Edema")
    character = models.CharField(max_length=50,choices=my_character, blank=True,verbose_name="Character")
    siteaffected =  models.CharField(max_length=200, blank=True,verbose_name="Site Affected")

    class Meta:
        verbose_name = 'Clinical Profile'
        verbose_name_plural = "3. Clinical Profile"


class ashtvidhparikshabhav(models.Model):
    # =========================ASTAVIDDHA PARIKSHA==========================
    my_mala = (
        ("Baddha", "Baddha"),
        ("Abaddha", "Abaddha"),
        ("Vikrita", "Vikrita"),
        ("Prakrata", "Prakrata"),
        ("Atisara", "Atisara"),
        ("Pravahik", "Pravahik"),
        ("Grahini", "Grahini"),
        ("Anyother", "Any other"),
    )
    my_jivha = (
        ("coated", "Coated(lipta)"),
        ("Uncoated", "Uncoated(alipta)"),
        ("PartiallyCoated", "Partially Coated (Alpalipta)"),
        ("color", "Color"),
    )
    my_jivhacolor = (
        ("Whitish", "Whitish"),
        ("Pinkish", "Pinkish"),
        ("Blackish", "Blackish"),
    )
    my_drikcolor = (
        ("White", "White"),
        ("Pink", "Pink"),
        ("Red", "Red"),
        ("Yellow", "Yellow"),
    )
    my_akrita = (
        ("Sthula", "Sthula"),
        ("Madhyama", "Madhyama"),
        ("Heena", "Heena"),
    )
    my_Shabdha = (
        ("Prakrita", "Prakrita"),
        ("Vikrita", "Vikrita"),
    )
    my_mootra = (
        ("Prakrita", "Prakrita"),
        ("Vikrita", "Vikrita"),
    )
    my_sparsh=(
        ("Ushna","Ushna"),
        ("Anushna", "Anushna"),
        ("Ruksha","Ruksha"),
        ("Khara","Khara"),
        ("Mrudhu","Mrudhu"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    nadi = models.CharField(max_length=50, blank=True, verbose_name="Nadi")
    mootra = models.CharField(max_length=50, blank=True, choices=my_mootra, verbose_name="Mootra")
    mala = models.CharField(max_length=50, blank=True, choices=my_mala, verbose_name="Mala")

    # mootrafreqday = models.CharField(max_length=50, blank=True, verbose_name="Frequency: Day")
    # mootrafreqnight = models.CharField(max_length=50, blank=True, verbose_name="Night")
    # mootracolor = models.CharField(max_length=50, blank=True, verbose_name="Color")
    # mootraother = models.CharField(max_length=50, blank=True, verbose_name="Other associated complaints")

    jivha = models.CharField(max_length=50, blank=True, choices=my_jivha, verbose_name="Jihva")
    #jivhacolor = models.CharField(max_length=50, blank=True, choices=my_jivhacolor, verbose_name="Color")

    Shabdha  = models.CharField(max_length=50, blank=True, choices=my_Shabdha, verbose_name="Shabdha")
    sparsh = models.CharField(max_length=50,choices=my_sparsh, blank=True, verbose_name="Sparsh")

    # sparshUshna = models.CharField(max_length=50, blank=True, verbose_name="Sparsha-Ushna")
    # sparshAnushna = models.CharField(max_length=50, blank=True, verbose_name="-Anushna")
    # sparshRuksha = models.CharField(max_length=50, blank=True, verbose_name="-Ruksha")
    # sparshKhara = models.CharField(max_length=50, blank=True, verbose_name="-Khara")
    # sparshMrudhu = models.CharField(max_length=50, blank=True, verbose_name="-Mrudhu")

    drika = models.CharField(max_length=50, blank=True, choices = my_drikcolor, verbose_name="Drika")
    akriti = models.CharField(max_length=50, blank=True, choices = my_akrita, verbose_name="Akriti ")

    class Meta:
        verbose_name = 'Astavidha Pariksha'
        verbose_name_plural = "4. Astavidha Pariksha"

# =========================DASHVIDDHA PARIKSHA==========================
class dashvidhparikshabhav(models.Model):

    my_prakruti = (
        ("K", "K"),
        ("V", "V"),
        ("P", "P"),
        ("VP", "VP"),
        ("VK", "VK"),
        ("PK", "PK"),
        ("Sannipataj", "Sannipataj"),
    )
    my_vrikruti = (
        ("prakrutisamasemveta ", "prakrutisamasemveta"),
        ("vrikrutisamasemveta", "vrikrutisamasemveta"),
    )
    my_rasatwakaSaara = (
        ("twacha", "Snigdha evum prassana twacha"),
        ("sparsha", "Alpa evum komalloma sparsha"),
    )
    my_raktaSaara= (
        ("akshi", "Snigdha and rakta varna of akshi"),
        ("jivha", "Snigdha and rakta varna of jivha"),
        ("nakha", "Snigdha and rakta varna of nakha"),
        ("panitala", "Snigdha and rakta varna of panitala"),
    )
    my_mamsaSaara=(
        ("Sthira", "Sthira"),
        ("griva", "pustha evum guru muscle of griva"),
        ("bahu", "pustha evum guru muscle of bahu"),
        ("adhoshakha", "pustha evum guru muscle of adhoshakha"),
    )
    my_medaSaara=(
        ("Snighdakesha ", "Snighdakesha "),
        ("oshtha", "oshtha"),
        ("nakha", "nakha"),
    )
    my_asthiSaara=(
        ("Sthoola sandhi", "Sthoola sandhi"),
        ("chibuka", "chibuka"),
        ("Jatru", "Jatru"),
    )
    my_majjaSaara=(
        ("Snigdha varna", "Snigdha varna"),
        ("snigdhaswara", "snigdhaswara"),
    )
    my_shukraSaara=(
        ("Kshirapoornalochana", "SKshirapoornalochana"),
        ("saumayaprekshan", "saumayaprekshan"),
        ("mahaspikha", "mahaspikha"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    prakruti = models.CharField(max_length=50, blank=True, choices=my_prakruti, verbose_name="Prakruti")
    vrikruti = models.CharField(max_length=50, blank=True, choices=my_vrikruti, verbose_name="Vrikruti")

    rasaTwakaSaara = models.CharField(max_length=50, blank=True, choices=my_rasatwakaSaara, verbose_name="Rasa/TwakaSaara")
    raktaSaara = models.CharField(max_length=50, blank=True, choices=my_raktaSaara, verbose_name="RaktaSaara")
    mamsaSaara = models.CharField(max_length=50, blank=True, choices=my_mamsaSaara, verbose_name="MamsaSaara")
    medaSaara = models.CharField(max_length=50, blank=True, choices=my_medaSaara, verbose_name="MedaSaara")
    asthiSaara = models.CharField(max_length=50, blank=True, choices=my_asthiSaara, verbose_name="AsthiSaara")
    majjaSaara = models.CharField(max_length=50, blank=True, choices=my_majjaSaara, verbose_name="MajjaSaara")
    shukraSaara = models.CharField(max_length=50, blank=True, choices=my_shukraSaara, verbose_name="ShukraSaara")
    #=========================Type of Sara===================================
    my_saara=(
        ("rasatwakasaara","rasa/twakasaara"),
        ("raktasaara","raktasaara"),
        ("mamsasaara", "mamsasaara"),
        ("medasaara", "medasaara"),
        ("asthisaara", "asthisaara"),
        ("majjasaara", "majjasaara"),
        ("sukrasaara", "sukrasaara"),
    )
    my_samahana=(
        ("Pravara","Pravara"),
        ("Madhyama","Madhyama"),
        ("Avara ", "Avara"),
    )
    my_satmya=(
        ("3","3"),
        ("2","2"),
        ("1","1"),
    )
    my_satva=(
        ("Pravar","Pravar"),
        ("madhyama","madhyama"),
        ("avara","avara"),
    )
    saara = models.CharField(max_length=200,choices=my_saara, blank=True,verbose_name="Types of Saara")
    samahana = models.CharField(max_length=200,choices=my_samahana, blank=True,verbose_name="Types of samahana")

    aharasatmya  = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Aharasatmya(change of food habits)")
    deshasatmya  = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Deshasatmya(change of place)")
    kaalsatmya   = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Kaal satmya(change of season)")

    # pravarasatmya  = models.CharField(max_length=50, blank=True,verbose_name="Pravarasatmya(ahara+ desha+ kaal)[0-9]")
    # pravarasatmya = models.CharField(max_length=50, blank=True, verbose_name="Madhyamasatmya(ahara+ desha+ kaal)[6-8] ")
    # avarasatmya  = models.CharField(max_length=50, blank=True, verbose_name="Avarasatmya (ahara+ desha+ kaal)[3-5] ")

    # ================Assessment of Satva================
    my_asssatva = (
        ("satva", "In the recent past, any event of a crisis like loss of a family member/ close friend, loss of money/loss in business or Severe deterioration in the health of self or loved one"),
        ("satva", "Was tolerated well (pravarasatva)"),
        ("satva", "Could be tolerated with support of others (madhyamasatva)"),
        ("satva", "Was inconsolable (avarasatva)"),
    )
    asssatva = models.CharField(max_length=500, choices=my_asssatva, default='0', verbose_name="Assessment of Satva")

    satvatype = models.CharField(max_length=50,choices=my_satva ,blank=True, verbose_name="Type of satva")

    # ================Assessment of aahar shakti================
    my_aaharshakti = (
        ("3", "3"),
        ("2", "2"),
        ("1", "1"),
    )
    my_aahartype = (
        ("pravar", "pravar"),
        ("madhyam", "madhyam"),
        ("avara", "avara"),
    )

    aahartype = models.CharField(max_length=50, choices=my_aahartype, default='0',verbose_name="Type of aahar")
    assaaharshakti1 = models.CharField(max_length=50, choices=my_aaharshakti, default='0', verbose_name="how many major meals do you have a day? ")
    assaaharshakti2 = models.CharField(max_length=500, choices=my_aaharshakti, default='0',   verbose_name="how many major meals do you have a day? ")
    scoreaaharshakti= models.CharField(max_length=500, default='0', verbose_name="Score :")
    # ================Assessment of vyayam shakti================
    my_vyayamshakti = (
        ("3", "3"),
        ("2", "2"),
        ("1", "1"),
    )
    vyayamtype = models.CharField(max_length=50, choices=my_aahartype, default='0', verbose_name="Type of aahar")
    assvyayamshakti1 = models.CharField(max_length=50, choices=my_vyayamshakti, default='0',
                                      verbose_name="can you climb up stairs to the next floor of the house?")
    assvyayamshakti2 = models.CharField(max_length=500, choices=my_vyayamshakti, default='0',
                                      verbose_name="daily routine activities:")
    scorevyayamshakti = models.CharField(max_length=500, default='0', verbose_name="Score :")

    my_vaya = (
        ("Bal", "Bal"),
        ("Yuva", "Yuva"),
        ("madhyam", "Madhyam"),
        ("vriddha", "Vriddha"),
    )
    vaya = models.CharField(max_length=200, choices=my_vaya, default='0',verbose_name="Vaya")

    class Meta:
        verbose_name = 'Dashvidha Pariksha'
        verbose_name_plural = '5. Dashvidha Pariksha'

# =========================EXAMINATION==========================
class sysexaminationbhav(models.Model):
    my_respsystem = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    respsystem = models.CharField(max_length=200,choices=my_respsystem, blank=True, verbose_name="Respiratory System")
    respsystemspecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")

    gastrointestsystem = models.CharField(max_length=200,choices=my_respsystem, blank=True, verbose_name="Gastro- Intestinal System")
    gastrointestsystemspecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")

    cardiovascsystem = models.CharField(max_length=200,choices=my_respsystem, blank=True, verbose_name="Cardio- vascular System")
    cardiovascsystemspecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")

    nervoussystem = models.CharField(max_length=200,choices=my_respsystem, blank=True, verbose_name="Nervous System")
    nervoussystemspecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")

    genitourinarysystem = models.CharField(max_length=200,choices=my_respsystem, blank=True, verbose_name="Genito-urinary system")
    genitourinarysystemspecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")

    #============Musculo-skeletal system=====
    my_respsystem = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    spine = models.CharField(max_length=200, choices=my_respsystem, blank=True,verbose_name="a.Spine")
    spinespecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")

    gait = models.CharField(max_length=50, choices=my_respsystem, blank=True, verbose_name="b.Gait(walking freely/with stick) ")
    gaitspecify = models.CharField(max_length=200, blank=True, verbose_name="Specify:")
    #=====================HAND==================
    my_hand = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    swellingjointshand = models.CharField(max_length=50, choices=my_hand, blank=True,verbose_name="Swelling of MCP,PIP or DIP Joints")
    fingerdeformitieshand  = models.CharField(max_length=50, choices=my_hand, blank=True,verbose_name="toes Deformities")
    fingernodeshand = models.CharField(max_length=50, choices=my_hand, blank=True,verbose_name="toes Nodes")
    #=====================FEET==================
    my_feet = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    swellingjointsfeet = models.CharField(max_length=50, choices=my_feet, blank=True,
                                                verbose_name="Swelling of TMT, MTP, PP, MP, DP joints")
    fingerdeformitiesfeet  = models.CharField(max_length=50, choices=my_feet, blank=True,
                                                  verbose_name="toes Deformities")
    fingernodesfeet = models.CharField(max_length=50, choices=my_feet, blank=True,
                                         verbose_name="toes Nodes")
    #===========================================
    alignofbone = models.CharField(max_length=200, choices=my_respsystem, blank=True, verbose_name="i) alignment of one bone on another")
    musclebulk = models.CharField(max_length=200, choices=my_respsystem, blank=True, verbose_name="ii) muscle bulk")
    scareofjoints = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="iii) Scares in and around the joint")
    jointswelling = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="iv) Joint swelling")
    jointwarmth = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="v) Joint warmth")
    jointtenderness = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="vi) Joint tenderness")
    jointstiffness = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="vii) joint stiffness")
    jointeffusion = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="viii) Joint effusion")
    jointcrepitus = models.CharField(max_length=200, choices=my_feet, blank=True, verbose_name="ix) Joint crepitus")
    rangeofmotion = models.CharField(max_length=200, choices=my_respsystem, blank=True, verbose_name="x) Range of motion")

    class Meta:
        verbose_name = 'Systemic Examination'
        verbose_name_plural = '6. Systemic Examination'

# ==============) Laboratory examination   ================
class labexambhav(models.Model):

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    hbBT = models.CharField(max_length=50, blank=True, verbose_name="Hemoglobin(g/dl) ")
    hbAT = models.CharField(max_length=50, blank=True, verbose_name="")

    tlcBT = models.CharField(max_length=50, blank=True, verbose_name="T.L.C.(cu.mm.)")
    tlcAT = models.CharField(max_length=50, blank=True, verbose_name="")

    dlcBT = models.CharField(max_length=50, blank=True, verbose_name="D.L.C.(N %, E %, B %, L%, M %)")
    dlcAT = models.CharField(max_length=50, blank=True, verbose_name="")

    hba1cBT = models.CharField(max_length=50, blank=True, verbose_name="HbA1C(for screening purpose)")
    hba1cAT = models.CharField(max_length=50, blank=True, verbose_name="")

    lftBT = models.CharField(max_length=50, blank=True, verbose_name="LFT")
    lftAT = models.CharField(max_length=50, blank=True, verbose_name="")

    kftBT = models.CharField(max_length=50, blank=True, verbose_name="KFT(including uric acid)")
    kftAT = models.CharField(max_length=50, blank=True, verbose_name="")

    esrBT = models.CharField(max_length=50, blank=True, verbose_name="E.S.R.(mm at the end of 1st hour)")
    esrAT = models.CharField(max_length=50, blank=True, verbose_name="")

    rafactorBT = models.CharField(max_length=50, blank=True, verbose_name="Serum RA FACTOR")
    rafactorAT = models.CharField(max_length=50, blank=True, verbose_name="")

    crpBT = models.CharField(max_length=50, blank=True, verbose_name="CRP(C-reactive Protein)")
    crpAT = models.CharField(max_length=50, blank=True, verbose_name="")

    anticcpBT = models.CharField(max_length=50, blank=True, verbose_name="ANTI-CCP")
    anticppAT = models.CharField(max_length=50, blank=True, verbose_name="")

    urineroutineBT = models.CharField(max_length=50, blank=True, verbose_name="Urine routine and microscopic")
    urineroutineAT = models.CharField(max_length=50, blank=True, verbose_name="")

    class Meta:
        verbose_name = 'Laboratory examination'
        verbose_name_plural = '7. Laboratory examination '

class assparameterbhav(models.Model):
    registrationdate = models.DateField(null=False)
    opdno = models.IntegerField(null=False)
    #caseno = models.IntegerField(null=False)
    crno = models.IntegerField(null=False)
    ipdno = models.IntegerField(null=False)

    sdaiscore = models.CharField(max_length=50, blank=True, verbose_name="SDAI Score")
    walktime = models.CharField(max_length=50, blank=True, verbose_name="1.Walking time(in seconds)")
    handgrip = models.CharField(max_length=50, blank=True, verbose_name="2. Hand grip (mm Hg)")
    footpressure = models.CharField(max_length=50, blank=True, verbose_name="3. Foot pressure")

    class Meta:
        verbose_name = 'Assessment Parameter'
        verbose_name_plural = '8. Assessment Parameter'

# ==============OBJECTIVE PARAMETERS ================
class objectiveparabhav(models.Model):

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")
# ========Before Treatment LEFT
    shLTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    shLTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    shRTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    shRTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    elbLTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    elbLTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    elbRTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    elbRTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    wriLTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    wriLTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    wriRTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    wriRTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    mcp1LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    mcp1LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    mcp1RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    mcp1RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    mcp2LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    mcp2LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    mcp2RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    mcp2RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    mcp3LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    mcp3LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    mcp3RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    mcp3RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    mcp4LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    mcp4LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    mcp4RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    mcp4RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    mcp5LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    mcp5LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    mcp5RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    mcp5RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    pip1LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    pip1LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    pip1RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    pip1RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    pip2LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    pip2LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    pip2RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    pip2RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    pip3LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    pip3LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    pip3RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    pip3RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    pip4LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    pip4LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    pip4RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    pip4RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    pip5LTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    pip5LTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    pip5RTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    pip5RTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    kneeLTTD = models.CharField(max_length=50, blank=True, verbose_name="L/Tender")
    kneeLTSW = models.CharField(max_length=50, blank=True, verbose_name="L/Swollen")
    kneeRTTD = models.CharField(max_length=50, blank=True, verbose_name="R/Tender")
    kneeRTSW = models.CharField(max_length=50, blank=True, verbose_name="R/Swollen")

    #===============SDAI Score===========
    Tenderjointscore = models.IntegerField(null=True, blank=True, verbose_name="Tender joint score")
    Swollenjointscore = models.IntegerField(null=True, blank=True, verbose_name="Swollen joint score")
    Patientglobalscore = models.IntegerField(null=True, blank=True, verbose_name="Patient global score")
    Providerglobalscore = models.IntegerField(null=True, blank=True, verbose_name="Provider global score")
    creactiveprotein = models.IntegerField(null=True, blank=True, verbose_name="C-reactive protein (mg/dl)")
    sdaitotalscore= models.IntegerField(null=True,blank=True, verbose_name="Total Score")
    class Meta:
        verbose_name = 'Objective parameter'
        verbose_name_plural = '9. Objective parameter'

# ==============SUBJECTIVE PARAMETERS ================
class subjectiveparabhav(models.Model):
    my_subpara=(
        ("0","0"),
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
    )
    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    angamardasubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Angamarda(bodyache)")
    aruchisubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Aruchi(anorexia)")
    trshnasubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Trshna(thirst)")
    alasyasubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Alasya(laziness)")
    gouravasubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Gourava(heaviness)")
    apakasubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Apaka(indigestion)")
    jwarasubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Jwara(fever)")
    sandhisothsubpara = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Sandhi sotha(swelling of joints)")

    sandhigata = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Sandhigata Vrishchikdansavatvedana(scorpion sting like pain)")
    agni = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Agni daurbalya(weakness of digestive fire)")
    preseka = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Preseka(hypersalivation)")
    utsahahani = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Utsahahani(lack of enthusium)")
    vairsaya = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Vairsaya(tastelessness)")
    vaha = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Daha(burning sensation)")
    bahu = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Bahu mutrata(frequent micturition)")
    kushikathinya = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Kushikathinya(feeling of abdominal rigidity)")
    kukshi = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Kukshi shola(pain in abdomen)")
    nidravirprayaya = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Nidravirprayaya(changes in sleeping pattern)")
    chardi = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Chardi(vomiting)")
    bharma = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Bharma(vertigo)")
    murcha = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Murcha(unconsciousness)")
    hridgrah = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Hridgrah(constricting like feeling in cardiac region)")
    vidbadhatta = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Vid badhatta(constipation)")
    jadaya = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Jadaya(stiffness)")
    antrakujana = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Antrakujana(gurgling bowel sounds)")
    anaha = models.CharField(max_length=50,choices=my_subpara, blank=True, verbose_name="Anaha(flatulence)")

    class Meta:
        verbose_name = 'Subjective parameter'
        verbose_name_plural = '10. Sujective parameter'

#=============CASE REPORT FORM 3 (schedule of assessment) =====================
class casereportform3bhav(models.Model):

    centre = models.CharField(max_length=200, verbose_name="Centre")
    registrationdate = models.DateField(null=False, verbose_name="Participation Date")
    opdno = models.IntegerField(null=False, verbose_name="OPD NO.")
    crno = models.IntegerField(null=False, verbose_name="CR No.")
    nameofparticipant = models.CharField(max_length=200, verbose_name="Name of Participant")
    ipdno = models.IntegerField(null=False)

    # ====== TRIAL GROUP A================
    #===Temperature
    tempD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #tempD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    tempD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    tempD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    tempD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    tempD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")
    #===BP
    bpD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #bpD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    bpD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    bpD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    bpD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    bpD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===Pulse Rate
    pulseD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #pulseD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    pulseD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    pulseD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    pulseD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    pulseD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===Amavatalakshan
    amavatalakshanD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #amavatalakshanD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    amavatalakshanD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    amavatalakshanD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    amavatalakshanD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    amavatalakshanD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===SDAI Score
    sdaiD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #sdaiD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    sdaiD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    sdaiD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    sdaiD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    sdaiD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===Walking Time
    walkD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #walkD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    walkD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    walkD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    walkD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    walkD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #=====Hand grip
    handgripD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #handgripD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    handgripD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    handgripD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    handgripD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    handgripD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #=====Foot pressure
    footpressD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #footpressD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    footpressD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    footpressD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    footpressD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    footpressD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #=====E.S.R.
    esrD0_A =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #esrD8_A =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    esrD16_A = models.CharField(max_length=50, blank=True, verbose_name="D16")
    esrD31_A = models.CharField(max_length=50, blank=True, verbose_name="D31")
    esrD46_A = models.CharField(max_length=50, blank=True, verbose_name="D46")
    esrD61_A = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # ====== TRIAL GROUP B================
    # ===Temperature
    tempD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #tempD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    tempD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    tempD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    tempD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    tempD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")
    # ===BP
    bpD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #bpD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    bpD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    bpD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    bpD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    bpD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # ===Pulse Rate
    pulseD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #pulseD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    pulseD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    pulseD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    pulseD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    pulseD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # ===Amavatalakshan
    amavatalakshanD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #amavatalakshanD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    amavatalakshanD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    amavatalakshanD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    amavatalakshanD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    amavatalakshanD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # ===SDAI Score
    sdaiD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #sdaiD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    sdaiD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    sdaiD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    sdaiD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    sdaiD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # ===Walking Time
    walkD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #walkD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    walkD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    walkD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    walkD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    walkD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # =====Hand grip
    handgripD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #handgripD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    handgripD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    handgripD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    handgripD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    handgripD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # =====Foot pressure
    footpressD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #footpressD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    footpressD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    footpressD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    footpressD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    footpressD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

    # =====E.S.R.
    esrD0_B =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #esrD8_B =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    esrD16_B = models.CharField(max_length=50, blank=True, verbose_name="D16")
    esrD31_B = models.CharField(max_length=50, blank=True, verbose_name="D31")
    esrD46_B = models.CharField(max_length=50, blank=True, verbose_name="D46")
    esrD61_B = models.CharField(max_length=50, blank=True, verbose_name="D61")

# ====== TRIAL GROUP C================
    #===Temperature
    tempD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #tempD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    tempD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    tempD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    tempD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    tempD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")
    #===BP
    bpD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #bpD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    bpD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    bpD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    bpD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    bpD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===Pulse Rate
    pulseD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #pulseD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    pulseD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    pulseD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    pulseD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    pulseD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===Amavatalakshan
    amavatalakshanD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #amavatalakshanD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    amavatalakshanD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    amavatalakshanD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    amavatalakshanD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    amavatalakshanD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===SDAI Score
    sdaiD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #sdaiD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    sdaiD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    sdaiD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    sdaiD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    sdaiD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #===Walking Time
    walkD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #walkD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    walkD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    walkD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    walkD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    walkD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #=====Hand grip
    handgripD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #handgripD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    handgripD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    handgripD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    handgripD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    handgripD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #=====Foot pressure
    footpressD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #footpressD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    footpressD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    footpressD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    footpressD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    footpressD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    #=====E.S.R.
    esrD0_C =  models.CharField(max_length=50, blank=True, verbose_name="D0")
    #esrD8_C =  models.CharField(max_length=50, blank=True, verbose_name="D8")
    esrD16_C = models.CharField(max_length=50, blank=True, verbose_name="D16")
    esrD31_C = models.CharField(max_length=50, blank=True, verbose_name="D31")
    esrD46_C = models.CharField(max_length=50, blank=True, verbose_name="D46")
    esrD61_C = models.CharField(max_length=50, blank=True, verbose_name="D61")

    class Meta:
        verbose_name = 'Case Report Form 3 '
        verbose_name_plural = '11.Case Report Form 3(schedule of assessment) '
# ==============LAB TEST SUMMARY================
class labtestsummarybhav(models.Model):

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    hbD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    tlcD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    dlcD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    lftD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    kftD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    urineroutineD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    esrD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    rafactorD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    crpD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")
    anticcpD0 = models.CharField(max_length=50, blank=True, verbose_name="D0")

    hbD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    tlcD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    dlcD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    lftD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    kftD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    urineroutineD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    esrD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    rafactorD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    crpD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")
    anticcpD31 = models.CharField(max_length=50, blank=True, verbose_name="D31")

    class Meta:
        verbose_name = 'Summary of all Laboratory Test'
        verbose_name_plural = '12. Summary of all Laboratory Test'
