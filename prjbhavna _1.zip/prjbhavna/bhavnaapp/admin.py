from django.contrib import admin
from .models import screeningbhav
from .models import baselineassbhav
from .models import clinicalprofilebhav
from .models import ashtvidhparikshabhav
from .models import dashvidhparikshabhav
from .models import sysexaminationbhav

from .models import labexambhav
from .models import assparameterbhav
from .models import objectiveparabhav
from .models import subjectiveparabhav
from .models import casereportform3bhav
from .models import labtestsummarybhav

#from .models import testme

# from django.contrib.admin import AdminSite
# class DivyaAdminSite(AdminSite):
#     site_header = "Divya Admin"
#     site_title = "Divya Admin Portal"
#     index_title = "Welcome to Divya Researcher Events Portal"
#
#     event_admin_site = DivyaAdminSite(name='divya_admin');

#from .models import examination

admin.site.site_header="PROJECT BY BHAWNA"
admin.site.site_title = "PROJECT BY PANCHAKARMA DEPARTMENT"
admin.site.index_title = "Welcome to Researcher Portal : PANCHAKARMA DEPARTMENT"

admin.site.disable_action('delete_selected')

# Register your models here.
@admin.register(screeningbhav)
class screeningbhavAdmin(admin.ModelAdmin):
    list_display= ('centre','registrationdate','opdno','crno','ipdno')
    #,'patientname','gender','dob','ageyr','agemn','address','contactno','email')
    search_fields=('opdno','crno','patientname')
    ordering=['patientname']
    list_filter=('ageyr','gender')

    fieldsets=[
        ('Scereening', {'fields':['registrationdate','opdno','crno','patientname','gender','dob','ageyr','agemn','address','contactno','email']}),
        ('Inclusion Criteria', {'fields': ['ic1', 'ic2', 'ic3', 'ic4', 'ic5']}),
        ('Exclusion Criteria', {'fields': ['ec1', 'ec2', 'ec3', 'ec4', 'ec5','ec6','ec7','ec8','ec9']}),
        ('Informed consent taken :', {'fields': ['iconsent']}),
        ('ACR-EULAR CRITERIA 2010 ', {'fields': ['jinv', 'sero', 'apr', 'dusymp']}),
    ]

@admin.register(baselineassbhav)
class baselineassbhavAdmin(admin.ModelAdmin):
    list_display= ('centre','inductiondate','completiondate','crno','opdno','ipdno')\
                # ,'patientname','gender','dob','ageyr','agemn','address','contactno','email'
                #    'marritalstatus','edustatus', 'education', 'qualification', 'socecostatus', 'habitat', 'religion', 'chiefcomplaint',
                #    'preshistory', 'prevhistoryyesno','surghistory'
                #    )
    #list_display = ('centre','registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
    search_fields = ['opdno','crno','patientname','ipdno']
    fieldsets=[
     ('', {'fields': ['centre','inductiondate','completiondate']}),
     ('Personal Identification', {'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno', 'dietaryhabit', 'addiction', 'addqty', 'addduration','sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex', 'alltomaterial', 'natureofall', 'symptoms','emotionalstress']}),
     ('Demographic Information', {
            'fields': ['marritalstatus', 'edustatus', 'education', 'qualification', 'socecostatus', 'habitat',
                       'religion', 'chiefcomplaint', 'preshistory', 'prevhistoryyesno','surghistory']})

      ]

@admin.register(clinicalprofilebhav)
class clinicalprofilebhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno',  'ipdno')
                    # 'dietaryhabit', 'addiction', 'addqty', 'addduration', 'sleep', 'bowelhabitat', 'stoolcons',
                    # 'urineoutput', 'phyex', 'alltomaterial', 'natureofall', 'symptoms', 'emotionalstress',
                    # 'registrationdate', 'opdno', 'crno', 'ipdno', 'dietaryhabit', 'addiction', 'addqty', 'addduration','sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex',
                    # 'alltomaterial', 'natureofall', 'symptoms','emotionalstress',
                    # 'gyncobshis', 'menarche', 'menopause', 'lmp', 'whitedisch',
                    # 'familyhist',
                    # 'builtavg', 'nutrition', 'height', 'weight', 'bmi', 'waistcirm', 'resprate', 'pulserate',
                    # 'bp', 'clubbing', 'cyanosis', 'cyanosispresent', 'temp', 'pallor', 'lymphadenopathy',
                    # 'edema', 'character', 'siteaffected'
                    # ]}),

    search_fields = ['opdno', 'crno',  'ipdno']
    fieldsets=[
     ('Personal History', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno', 'dietaryhabit', 'addiction', 'addqty', 'addduration','sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex', 'alltomaterial', 'natureofall', 'symptoms','emotionalstress']}),
     ('Gynecological & Obstetric_History',{'fields':['gyncobshis', 'menarche', 'menopause', 'lmp', 'whitedisch']}),

      ('Family History',{'fields':['familyhist']}),

      ('General Physical Examination',{'fields': ['builtavg', 'nutrition', 'height', 'weight', 'bmi', 'waistcirm', 'resprate', 'pulserate',
                                                  'bp', 'clubbing', 'cyanosis', 'cyanosispresent', 'temp', 'pallor', 'lymphadenopathy',
                                                  'edema', 'character','siteaffected']}),
 ]

@admin.register(ashtvidhparikshabhav)
class ashtvidhparikshabhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')\
        # ,'nadi', 'mala', 'mootra', 'mootrafreqday', 'mootrafreqnight','mootracolor','mootraother','jivha','jivhacolor',
        #                              'Shabdha','sparshUshna','sparshAnushna','sparshRuksha','sparshKhara','sparshMrudhu','drik','akrita')
    search_fields = ['opdno','crno','ipdno']
    fieldsets=[
     ('', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno']}),
     ('Ashtavidh Pariksha',{'fields':['nadi', 'mala', 'mootra', 'mootrafreqday', 'mootrafreqnight','mootracolor','mootraother','jivha','jivhacolor',
                                     'Shabdha','sparshUshna','sparshAnushna','sparshRuksha','sparshKhara','sparshMrudhu','drik','akrita']}),

 ]

@admin.register(dashvidhparikshabhav)
class dashvidhparikshabhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')

                    # 'prakruti', 'vrikruti', 'rasaTwakaSaara', 'raktaSaara', 'mamsaSaara', 'medaSaara', 'asthiSaara',
                    # 'majjaSaara', 'shukraSaara', 'saara', 'samahana', 'aharasatmya', 'deshasatmya', 'kaalsatmya', 'pravarasatmya',
                    # 'pravarasatmya', 'avarasatmya','asssatva', 'satvatype',
                    # 'assaaharshakti1', 'assaaharshakti2', 'scoreaaharshakti',
                    # 'assvyayamshakti1', 'assvyayamshakti2', 'scorevyayamshakti',
                    # 'vaya'
                    # )
    search_fields = ['opdno','crno','ipdno']
    fieldsets=[
     ('', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno']}),
     ('Dashvidh Pariksha',{'fields':['prakruti', 'vrikruti', 'rasaTwakaSaara', 'raktaSaara', 'mamsaSaara','medaSaara','asthiSaara',
                                     'majjaSaara','shukraSaara','saara','samahana','aharasatmya','deshasatmya','kaalsatmya',
                                     'pravarasatmya','avarasatmya','asssatva','satvatype']}),
    ('Assessment of aahar shakti',{'fields':['assaaharshakti1','assaaharshakti2','scoreaaharshakti']}),
    ('Assessment of vyayam shakti', {'fields': ['assvyayamshakti1', 'assvyayamshakti2', 'scorevyayamshakti']}),
    ('vaya', {'fields': ['vaya']}),

 ]


@admin.register(sysexaminationbhav)
class sysexaminationbhavAdmin(admin.ModelAdmin):
    #list_display= ('registrationdate','opdno','crno','caseno','ipdno','dietaryhabit','addiction','addqty','addduration','sleep','bowelhabitat','stoolcons','urineoutput','phyex','alltomaterial','natureofall','symptoms','emotionalstress','gyncobshis','menarche','menopause','lmp','whitedisch', 'familyhist','surhis','prevhistoryspecify','builtavg','nutrition','height','weight','bmi','waistcirm','resprate','pulserate','bp','clubbing','cyanosis','cyanosispresent','temp','pallor','lymphadenopathy','edema','character','siteaffected','joints','jointsabnormal')
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets=[
      ('Respiratory System:', {'fields': ['respsystem','respsystemspecify']}),
      ('Gastro-Intestinal System:', {'fields': ['gastrointestsystem','gastrointestsystemspecify']}),
      ('Cardio-vascular System:', {'fields': ['cardiovascsystem','cardiovascsystemspecify']}),
      ('Nervous System:', {'fields': ['nervoussystem','nervoussystemspecify']}),
      ('Genito-urinary system:', {'fields': ['genitourinarysystem','genitourinarysystemspecify']}),
      ('Spine:', {'fields': ['spine', 'spinespecify']}),
      ('Gait:', {'fields': ['gait', 'gaitspecify']}),
      ('Swelling of MCP,PIP or DIP Joints:', {'fields': ['swellingjointshand']}),
      ('Finger Deformities:', {'fields': ['fingerdeformitieshand']}),
      ('Finger Nodes:', {'fields': ['fingernodeshand']}),

      ('Swelling of TMT, MTP, PP, MP, DP joints:', {'fields': ['swellingjointsfeet']}),
      ('Finger Deformities:', {'fields': ['fingerdeformitiesfeet']}),
      ('Finger Nodes:', {'fields': ['fingernodesfeet']}),

      ('i) alignment of one bone on another', {'fields': ['alignofbone']}),
      ('ii) muscle bulk', {'fields': ['musclebulk']}),
      ('iii) Scares in and around the joint', {'fields': ['scareofjoints']}),
      ('iv) Joint swelling', {'fields': ['jointswelling']}),
      ('v) Joint warmth', {'fields': ['jointwarmth']}),
      ('vi) Joint tenderness', {'fields': ['jointtenderness']}),
      ('vii) joint stiffness', {'fields': ['jointeffusion']}),
      ('viii) Joint effusion', {'fields': ['jointcrepitus']}),
      ('x) Range of motion', {'fields': ['rangeofmotion']}),
]

@admin.register(labexambhav)
class labexambhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets = [
        ('Hemoglobin(g/dl)', {'fields': [('hbBT', 'hbAT')]}),
        ('T.L.C.(cu.mm.)', {'fields': [('tlcBT', 'tlcAT')]}),
        ('D.L.C.(N %, E %, B %, L%, M %)', {'fields': [('dlcBT', 'dlcAT')]}),
        ('HbA1C(for screening purpose)', {'fields': [('hba1cBT', 'hba1cAT')]}),
        ('LFT', {'fields': [('lftBT', 'lftAT')]}),
        ('KFT(including uric acid)', {'fields': [('kftBT', 'kftAT')]}),
        ('E.S.R.(mm at the end of 1st hour)', {'fields': [('esrBT', 'esrAT')]}),
        ('Serum RA Factor', {'fields': [('rafactorBT', 'rafactorAT')]}),
        ('CRP(C-reactive Protein)', {'fields': [('crpBT', 'crpAT')]}),
        ('ANTI-CCP', {'fields': [('anticcpBT', 'anticppAT')]}),
        ('Urine routine and microscopic', {'fields': [('urineroutineBT', 'urineroutineAT')]}),

    ]

@admin.register(assparameterbhav)
class assparameterbhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets = [
        ('SDAI Score', {'fields': ['sdaiscore']}),
        ('1.Walking time(in seconds)', {'fields': ['walktime']}),
        ('2. Hand grip (mm Hg)', {'fields': ['handgrip']}),
        ('3. Foot pressure', {'fields': ['footpressure']}),

    ]
@admin.register(objectiveparabhav)
class objectiveparabhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets = [
        #('Joint'          'L.Tender'     'L.Swollen'     'R.Tender'      'R.Swollen')
        ( 'Shoulder',{'fields': [('shLTTD','shLTSW','shRTTD','shRTSW')]}),
        ('Elbow', {'fields': [('elbLTTD', 'elbLTSW', 'elbRTTD', 'elbRTSW')]}),
        ('Wrist', {'fields': [('wriLTTD', 'wriLTSW', 'wriRTTD', 'wriRTSW')]}),

        ('MCP 1', {'fields': [('mcp1LTTD', 'mcp1LTSW', 'mcp1RTTD', 'mcp1RTSW')]}),
        ('MCP 2', {'fields': [('mcp2LTTD', 'mcp2LTSW', 'mcp2RTTD', 'mcp2RTSW')]}),
        ('MCP 3', {'fields': [('mcp3LTTD', 'mcp3LTSW', 'mcp3RTTD', 'mcp3RTSW')]}),
        ('MCP 4', {'fields': [('mcp4LTTD', 'mcp4LTSW', 'mcp4RTTD', 'mcp4RTSW')]}),
        ('MCP 5', {'fields': [('mcp5LTTD', 'mcp5LTSW', 'mcp5RTTD', 'mcp5RTSW')]}),

        ('PIP 1', {'fields': [('pip1LTTD', 'pip1LTSW', 'pip1RTTD', 'pip1RTSW')]}),
        ('PIP 2', {'fields': [('pip2LTTD', 'pip2LTSW', 'pip2RTTD', 'pip2RTSW')]}),
        ('PIP 3', {'fields': [('pip3LTTD', 'pip3LTSW', 'pip3RTTD', 'pip3RTSW')]}),
        ('PIP 4', {'fields': [('pip4LTTD', 'pip4LTSW', 'pip4RTTD', 'pip4RTSW')]}),
        ('PIP 5', {'fields': [('pip5LTTD', 'pip5LTSW', 'pip5RTTD', 'pip5RTSW')]}),

        ('Knee', {'fields': [('kneeLTTD', 'kneeLTSW', 'kneeRTTD', 'kneeRTSW')]}),

        ('Tender joint score', {'fields': ['Tenderjointscore']}),
        ('Swollen joint score', {'fields': ['Swollenjointscore']}),
        ('Patient global score', {'fields': ['Patientglobalscore']}),
        ('Provider global score', {'fields': ['Providerglobalscore']}),
        ('C-reactive protein (mg/dl)', {'fields': ['creactiveprotein']}),
    ]

@admin.register(subjectiveparabhav)
class subjectiveparabhavAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
        search_fields = ['opdno', 'crno', 'ipdno']
        fieldsets = [
            ('Angamarda(bodyache)', {'fields': ['angamardasubpara']}),
            ('Aruchi(anorexia)', {'fields': ['aruchisubpara']}),
            ('Trshna(thirst)', {'fields': ['trshnasubpara']}),
            ('Alasya(laziness)', {'fields': ['alasyasubpara']}),
            ('Gourava(heaviness)', {'fields': ['gouravasubpara']}),
            ('Apaka(indigestion)', {'fields': ['apakasubpara']}),

            ('Jwara(fever)', {'fields': ['jwarasubpara']}),
            ('Sandhi sotha(swelling of joints)', {'fields': ['sandhisothsubpara']}),
            ('Sandhigata Vrishchikdansavatvedana(scorpion sting like pain)', {'fields': ['sandhigata']}),
            ('Agni daurbalya(weakness of digestive fire)', {'fields': ['agni']}),
            ('Preseka(hypersalivation)', {'fields': ['preseka']}),
            ('Utsahahani(lack of enthusium)', {'fields': ['utsahahani']}),

            ('Vairsaya(tastelessness)', {'fields': ['vairsaya']}),
            ('Daha(burning sensation)', {'fields': ['vaha']}),
            ('Bahu mutrata(frequent micturition)', {'fields': ['bahu']}),
            ('Kushikathinya(feeling of abdominal rigidity)', {'fields': ['kushikathinya']}),
            ('Kukshi shola(pain in abdomen)', {'fields': ['kukshi']}),
            ('Nidravirprayaya(changes in sleeping pattern)', {'fields': ['nidravirprayaya']}),
            ('Chardi(vomiting)', {'fields': ['chardi']}),
            ('Bharma(vertigo)', {'fields': ['bharma']}),
            ('Murcha(unconsciousness)', {'fields': ['murcha']}),
            ('Hridgrah(constricting like feeling in cardiac region)', {'fields': ['hridgrah']}),

            ('Vid badhatta(constipation)', {'fields': ['vidbadhatta']}),
            ('Jadaya(stiffness)', {'fields': ['jadaya']}),
            ('Antrakujana(gurgling bowel sounds)', {'fields': ['antrakujana']}),
            ('Anaha(flatulence)', {'fields': ['anaha']}),

    ]


@admin.register(casereportform3bhav)
class casereportform3bhavAdmin(admin.ModelAdmin):
    list_display = ('centre','registrationdate', 'opdno', 'crno', 'ipdno')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets = [
# =========GROUP A
        ('Temperature', {'fields': [('tempD0_A','tempD8_A','tempD16_A','tempD31_A','tempD46_A','tempD61_A')]}),
        ('B.P.', {'fields': [('bpD0_A', 'bpD8_A', 'bpD16_A', 'bpD31_A', 'bpD46_A', 'bpD61_A')]}),
        ('Pulse Rate', {'fields': [('pulseD0_A', 'pulseD8_A', 'pulseD16_A', 'pulseD31_A', 'pulseD46_A', 'pulseD61_A')]}),
        ('Amavata lakshan', {'fields': [('amavatalakshanD0_A', 'amavatalakshanD8_A', 'amavatalakshanD16_A', 'amavatalakshanD31_A', 'amavatalakshanD46_A', 'amavatalakshanD61_A')]}),
        ('SDAI Score', {'fields': [('sdaiD0_A', 'sdaiD8_A', 'sdaiD16_A', 'sdaiD31_A', 'sdaiD46_A', 'sdaiD61_A')]}),
        ('Walking Time(in seconds)', {'fields': [('walkD0_A', 'walkD8_A', 'walkD16_A', 'walkD31_A', 'walkD46_A', 'walkD61_A')]}),
        ('Hand grip(mm hg)', {'fields': [('handgripD0_A', 'handgripD8_A', 'handgripD16_A', 'handgripD31_A', 'handgripD46_A', 'handgripD61_A')]}),
        ('Foot pressure', {'fields': [('footpressD0_A', 'footpressD8_A', 'footpressD16_A', 'footpressD31_A', 'footpressD46_A', 'footpressD61_A')]}),
        ('E.S.R.(mm at the end of 1st hour)', {'fields': [('esrD0_A', 'esrD8_A', 'esrD16_A', 'esrD31_A', 'esrD46_A', 'esrD61_A')]}),
#=========GROUP B
         ('Temperature', {'fields': [('tempD0_B', 'tempD8_B', 'tempD16_B', 'tempD31_B', 'tempD46_B', 'tempD61_B')]}),
         ('B.P.', {'fields': [('bpD0_B', 'bpD8_B', 'bpD16_B', 'bpD31_B', 'bpD46_B', 'bpD61_B')]}),
         (
         'Pulse Rate', {'fields': [('pulseD0_B', 'pulseD8_B', 'pulseD16_B', 'pulseD31_B', 'pulseD46_B', 'pulseD61_B')]}),
         ('Amavata lakshan', {'fields': [('amavatalakshanD0_B', 'amavatalakshanD8_B', 'amavatalakshanD16_B',
                                          'amavatalakshanD31_B', 'amavatalakshanD46_B', 'amavatalakshanD61_B')]}),
         ('SDAI Score', {'fields': [('sdaiD0_B', 'sdaiD8_B', 'sdaiD16_B', 'sdaiD31_B', 'sdaiD46_B', 'sdaiD61_B')]}),
         ('Walking Time(in seconds)', {'fields': [('walkD0_B', 'walkD8_B', 'walkD16_B', 'walkD31_B', 'walkD46_B', 'walkD61_B')]}),
         ('Hand grip(mm hg)', {'fields': [('handgripD0_B', 'handgripD8_B', 'handgripD16_B', 'handgripD31_B', 'handgripD46_B', 'handgripD61_B')]}),
         ('Foot pressure', {'fields': [('footpressD0_B', 'footpressD8_B', 'footpressD16_B', 'footpressD31_B',
                                        'footpressD46_B', 'footpressD61_B')]}),
         ('E.S.R.(mm at the end of 1st hour)', {'fields': [('esrD0_B', 'esrD8_B', 'esrD16_B', 'esrD31_B', 'esrD46_B', 'esrD61_B')]}),

#=========GROUP C
        ('Temperature', {'fields': [('tempD0_C', 'tempD8_C', 'tempD16_C', 'tempD31_C', 'tempD46_C', 'tempD61_C')]}),
         ('B.P.', {'fields': [('bpD0_C', 'bpD8_C', 'bpD16_C', 'bpD31_C', 'bpD46_C', 'bpD61_C')]}),
         ('Pulse Rate', {'fields': [('pulseD0_C', 'pulseD8_C', 'pulseD16_C', 'pulseD31_C', 'pulseD46_C', 'pulseD61_C')]}),
         ('Amavata lakshan', {'fields': [('amavatalakshanD0_C', 'amavatalakshanD8_C', 'amavatalakshanD16_C',
                                          'amavatalakshanD31_C', 'amavatalakshanD46_C', 'amavatalakshanD61_C')]}),
         ('SDAI Score', {'fields': [('sdaiD0_C', 'sdaiD8_C', 'sdaiD16_C', 'sdaiD31_C', 'sdaiD46_C', 'sdaiD61_C')]}),
         ('Walking Time(in seconds)', {'fields': [('walkD0_C', 'walkD8_C', 'walkD16_C', 'walkD31_C', 'walkD46_C', 'walkD61_C')]}),
         ('Hand grip(mm hg)', {'fields': [('handgripD0_C', 'handgripD8_C', 'handgripD16_C', 'handgripD31_C', 'handgripD46_C', 'handgripD61_C')]}),
         ('Foot pressure', {'fields': [('footpressD0_C', 'footpressD8_C', 'footpressD16_C', 'footpressD31_C',
                                        'footpressD46_C', 'footpressD61_C')]}),
         ('E.S.R.(mm at the end of 1st hour)', {'fields': [('esrD0_C', 'esrD8_C', 'esrD16_C', 'esrD31_C', 'esrD46_C', 'esrD61_C')]}),

    ]
@admin.register(labtestsummarybhav)
class labtestsummarybhavAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
         #     ,
         #                 'hbD0','dlcD0','kftD0','esrD0','rafactorD0','crpD0','anticcpD0','esrD0','rafactorBT','crpD0','anticcpD0','urineroutineD0,'anticcpD0''
         # ')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets = [
             ('', {'fields': ['registrationdate', 'opdno', 'crno', 'ipdno']}),
             ('Hemoglobin(g/dl)', {'fields': [('hbD0', 'hbD31')]}),
             ('T.L.C. (cu.mm.)', {'fields': [('tlcD0', 'tlcD31')]}),
             ('D.L.C.(N %, E %, B %, L%, M %)', {'fields': [('dlcD0', 'dlcD31')]}),
             ('LFT', {'fields': [('lftD0', 'lftD31')]}),
             ('KFT (including uric acid)', {'fields': [('kftD0', 'kftD31')]}),
             ('Urine routine and microscopic', {'fields': [('urineroutineD0', 'urineroutineD31')]}),
             ('E.S.R.(mm at the end of 1st hour)', {'fields': [('esrD0', 'esrD31')]}),
             ('Serum RA FACTOR', {'fields': [('rafactorD0', 'rafactorD31')]}),
             ('CRP(C-reactive Protein)', {'fields': [('crpD0', 'crpD31')]}),
             ('ANTI-CCP', {'fields': [('anticcpD0', 'anticcpD31')]}),

         ]