from django.db import models
from django.utils import timezone
from  datetime import datetime,date

class perdemoinfopri(models.Model):
    my_gender = (
        ("Male", "Male"),
        ("Female", "Female"),
    )
    my_marritalstatus = (
        ("Married", "Married"),
        ("Unmarried", "Unmarried"),
        ("other", "other"),
    )

    my_edustatus = (
        ("Illiterate", "Illiterate"),
        ("Literate", "Literate"),
    )

    my_socecostatus = (
        ("Above Poverty Line", "Above Poverty Line"),
        ("Below Poverty Line", "Below Poverty Line"),
    )

    my_habitat = (
        ("Urban", "Urban"),
        ("Semi-Urban", "Semi-Urban"),
        ("Rural", "Rural"),
    )

    my_religion = (
        ("Hindu", "Hindu"),
        ("Muslim", "Muslim"),
        ("Sikh", "Sikh"),
        ("Christian", "Christian"),
        ("Others", "Others"),
    )

    my_prevhis = (
        ("Yes", "Yes"),
        ("No", "No"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    patientname = models.CharField(max_length=200,verbose_name="Patient Name")
    dob = models.DateField(verbose_name="D.O.B")
    ageyr = models.IntegerField(verbose_name="Age(Year)")
    agemn = models.IntegerField(verbose_name="Age(Month)")
    gender = models.CharField(max_length=50,choices=my_gender,verbose_name="Gender")
    address = models.CharField(max_length=200,verbose_name="Address")
    contactno = models.CharField(max_length=50,verbose_name="Contact No.")
    email = models.EmailField(max_length=100,verbose_name="Email")
    marritalstatus =  models.CharField(max_length=50, choices=my_marritalstatus,verbose_name="Marrital Status")
    edustatus = models.CharField(max_length=50,choices=my_edustatus,verbose_name="Educational Status")
    education = models.CharField(max_length=200,verbose_name="Education")
    qualification = models.CharField(max_length=200,verbose_name="Qualification")
    socecostatus = models.CharField(max_length=50,choices=my_socecostatus,verbose_name="Socio-Economic Status")
    habitat = models.CharField(max_length=50,choices=my_habitat,verbose_name="Habitat")
    religion = models.CharField(max_length=50,choices=my_religion,verbose_name="Religion")
    chiefcomplaint = models.CharField(max_length=200,verbose_name="Chief Complaint")
    durationofillness = models.CharField(max_length=200,verbose_name="Duration Of Illness")
    otherinfo = models.CharField(max_length=200,verbose_name="Any other information")
    prevhistory = models.CharField(max_length=50,choices=my_prevhis,verbose_name="History of Previous illness (if any)")
    prevhistoryspecify = models.CharField(max_length=1000,verbose_name="Any significant medical or surgical history If yes, then specify")

    class Meta:
        verbose_name = 'Personal & Demographic Info'
        verbose_name_plural = "1. Personal & Demographic Infos"

class clinicalprofilepri(models.Model):
    my_diethabit = (
        ("Vegetarian", "Vegetarian"),
        ("Non-Vegetarian", "Non-Vegetarian"),
    )
    my_addictions = (
        ("Tea","Tea"),
        ("Coffee", "Coffee"),
        ("Tea","Tea"),
        ("Coffee","Coffee"),
        ("Alcohol", "Alcohol"),
        ("Tobacco", "Tobacco"),
        ("Smoking", "Smoking"),
        ("None", "None"),
    )
    my_sleep = (
        ("Normal", "Normal"),
        ("Disturbed", "Disturbed"),
    )
    my_bowelhabit = (
        ("Regular", "Regular"),
        ("Irregular", "Irregular"),
    )
    my_stoolconsist = (
        ("Normal", "Normal"),
        ("Loose", "Loose"),
        ("Constipated", "Constipated"),
    )
    my_urineoutput = (
        ("Normal", "Normal"),
        ("Frequent", "Frequent"),
        ("Urgency", "Urgency"),
        ("Strangury", "Strangury"),
        ("Nocturia", "Nocturia"),
    )
    my_physicalex = (
        ("Heavy Labour", "Heavy Labour"),
        ("Moderate Labour", "Moderate Labour"),
        ("Office Job", "Office Job"),
        ("Sedentary", "Sedentary"),
    )
    my_alltomaterial = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_emostress = (
        ("Average", "Average"),
        ("Moderate", "Moderate"),
        ("Too Much", "Too Much"),
    )
    my_gyncobshis = (
        ("Applicable", "Applicable"),
        ("Non-Applicable", "Non-Applicable"),
    )
    my_whitedisch = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_built = (
        ("Average", "Average"),
        ("Emaciated", "Emaciated"),
        ("Well built", "Well built"),
        ("Tall", "Tall"),
        ("Dwarf", "Dwarf"),
    )
    my_clubbing = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosis = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosispresent = (
        ("Central", "Central"),
        ("Peripheral", "Peripheral"),
    )
    my_pallor = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_lymphadenopathy = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_edema = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_character = (
        ("Pitting", "Pitting"),
        ("Non- pitting", "Non- pitting"),
    )
    my_veribralcol = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_joints = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_Superficialreflexesplantar = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_Superficialreflexesabdominal = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_deepreflexesbicepsjerk = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_deepreflexeskneejerk = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_deepreflexesanklejerk = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_signofmenirr = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_neckstiffness = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_gait = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_deformities = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_musclewasting  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_asymmetry  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_redness  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_inflammation  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_muscletwitch  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_swellinjoints  = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )

    my_scaresjoints = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )

    my_palpwarmth = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palptenderness = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpswelling = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpeffusion = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpcrepitus = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_palpactivemov = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_palppassivemov = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )
    my_spine = (
        ("Thoracickyphosis", "Thoracic kyphosis"),
        ("Lumbarlorodosis", "Lumbar lorodosis"),
        ("Limitedrangeonmovements", "Limited range on movements"),
    )
    my_gait1 = (
        ("Limp", "Limp"),
        ("rendelenburg", "Rendelenburg"),
        ("Antalgic", "Antalgic"),
        ("Highstepping", "High stepping"),
        ("Crouch", "Crouch"),
    )

    my_bone = (
        ("Congenitaldeformity", "Congenital deformity"),
        ("Fracture", "Fracture"),
        ("Tumour", "Tumour"),
        ("Degenerativechanges", "Degenerative changes"),
    )

    my_neck = (
        ("Pain", "Pain"),
        ("Limitedmovements", "Limited movements"),
        ("Deformity", "Deformity"),
    )

    my_handsswelling = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_handsfingdef = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_handsfingnodes = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    dietaryhabit = models.CharField(max_length=50,choices=my_diethabit, blank=True,verbose_name="Dietary Habits")
    addiction = models.CharField(max_length=50,choices=my_addictions, blank=True,verbose_name="Addiction")
    addqty = models.CharField(max_length=200, blank=True,verbose_name="Specify quantity/day")
    addduration = models.CharField(max_length=200, blank=True,verbose_name="Duration of Addiction")
    sleep = models.CharField(max_length=50,choices=my_sleep, blank=True,verbose_name="Sleep")
    bowelhabitat = models.CharField(max_length=50,choices=my_bowelhabit, blank=True,verbose_name="Bowel Habits")
    stoolcons = models.CharField(max_length=50,choices=my_stoolconsist, blank=True,verbose_name="Stool Consistency")
    urineoutput = models.CharField(max_length=50,choices=my_urineoutput, blank=True,verbose_name="Urine Output")
    phyex = models.CharField(max_length=50,choices=my_physicalex, blank=True,verbose_name="Physical Exercise")
    alltomaterial = models.CharField(max_length=50,choices=my_alltomaterial, blank=True,verbose_name="Allergy to Some Material")
    natureofall = models.CharField(max_length=200,choices=my_emostress, blank=True,verbose_name="If yes, then nature of the allergen")
    symptoms = models.CharField(max_length=200, blank=True,verbose_name="Symptom(s) produced upon exposure")
    emotionalstress = models.CharField(max_length=50,choices=my_emostress, blank=True,verbose_name="Emotional Stresses")
    gyncobshis = models.CharField(max_length=50,choices=my_gyncobshis, blank=True,verbose_name="Gynecological/obstetric history")

    menarche = models.CharField(max_length=200, blank=True,verbose_name="a)Menarche(years)")
    menopause = models.CharField(max_length=200, blank=True,verbose_name="b)Menopause(years")
    lmp = models.DateField(null=True, blank=True,verbose_name="LMP")
    whitedisch = models.CharField(max_length=50,choices=my_whitedisch, blank=True,verbose_name="White discharge per vagina")

    familyhist = models.TextField(max_length=200, blank=True,verbose_name="Family History")
    surhis =  models.TextField(max_length=200, blank=True,verbose_name="Surgical History")
    prevhistoryspecify = models.TextField(max_length=200, blank=True,verbose_name="Previous History (specify)")

    builtavg = models.CharField(max_length=50,choices=my_built, blank=True,verbose_name="Built")
    nutrition = models.CharField(max_length=50, blank=True,verbose_name="Nutrition")

    height = models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="Height(cm)")
    weight= models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="Weight(kg)")
    bmi = models.DecimalField(max_digits=5,decimal_places=2, default=0,verbose_name="B.M.I.(kg/m2) ")

    waistcirm = models.DecimalField(max_digits=5,decimal_places=1, default=0,verbose_name="Waist Circumference (cm)")
    resprate = models.IntegerField(default=0,verbose_name="Respiratory Rate(/minute)")
    pulserate = models.IntegerField(default=0,verbose_name="Pulse Rate(/minute)")
    bp = models.CharField(max_length=100, null=True, blank=True,verbose_name="Blood Pressure(mmHg)")

    clubbing = models.CharField(max_length=100,choices=my_clubbing, blank=True,verbose_name="Clubbing")
    cyanosis = models.CharField(max_length=100,choices=my_cyanosis, blank=True,verbose_name="Cyanosis")
    cyanosispresent = models.CharField(max_length=100,choices=my_cyanosispresent, blank=True,verbose_name="If present")

    temp = models.DecimalField(max_digits=5,decimal_places=1,null=True, blank=True,verbose_name="Temperature(oF)")
    pallor = models.CharField(max_length=50,choices=my_pallor, blank=True,verbose_name="Pallor")
    lymphadenopathy = models.CharField(max_length=50,choices=my_lymphadenopathy, blank=True,verbose_name="Lymphadenopathy")
    edema = models.CharField(max_length=50,choices=my_edema, blank=True,verbose_name="Edema")
    character = models.CharField(max_length=50,choices=my_character, blank=True,verbose_name="Character")
    siteaffected =  models.CharField(max_length=200, blank=True,verbose_name="Site Affected")
    vertebralcol = models.CharField(max_length=50, choices=my_veribralcol, blank=True,verbose_name="Vertebral column")
    vertebralcolanyother = models.CharField(max_length=200, blank=True,verbose_name="Any other")
    joints = models.CharField(max_length=50,choices=my_joints, blank=True,verbose_name="Joints")
    jointsabnormal = models.CharField(max_length=200, blank=True,verbose_name="If abnormal, then specific joint and associated abnormality")

    #=========================EXAMINATION==========================
    respsystem = models.CharField(max_length=200, blank=True,verbose_name="Respiratory System")
    gastrointestsystem = models.CharField(max_length=200, blank=True,verbose_name="Gastro- Intestinal System")
    cardiovascsystem = models.CharField(max_length=200, blank=True,verbose_name="Cardio- vascular System")
    nervoussystem = models.CharField(max_length=200, blank=True,verbose_name="Nervous System")
    superficialreflexplanter = models.CharField(max_length=50, choices=my_Superficialreflexesplantar, blank=True,verbose_name="Superficial reflexes: Planter")
    superficialreflexabdominal = models.CharField(max_length=50, choices=my_Superficialreflexesabdominal, blank=True,verbose_name="Superficial reflexes: Abdominal")

    deepreflexbicepjerk = models.CharField(max_length=50, choices=my_deepreflexesbicepsjerk, blank=True,verbose_name="Deep reflexes :Biceps Jerk")
    deepreflexkneejerk = models.CharField(max_length=50, choices=my_deepreflexeskneejerk, blank=True,verbose_name="Deep reflexes :Knee Jerk ")
    deepreflexanklejerk = models.CharField(max_length=50, choices=my_deepreflexesanklejerk, blank=True,verbose_name="Deep reflexes :Ankle Jerk")

    signofmenirr = models.CharField(max_length=50, choices=my_signofmenirr, blank=True,verbose_name="Signs of Meningeal Irritation")
    neckstiff = models.CharField(max_length=50, choices=my_neckstiffness, blank=True,verbose_name="If present then, Neck stiffness")

    gait = models.CharField(max_length=50, choices=my_gait, blank=True,verbose_name="Gait(walking freely/with stick) ")
    deformities = models.CharField(max_length=50, choices=my_deformities, blank=True,verbose_name="Deformities(knock knees,bowlegs,pigeon toes")

    musclewaisting = models.CharField(max_length=50, choices=my_musclewasting, blank=True,verbose_name="Muscle wasting just above and around the joint ")
    asymmetry = models.CharField(max_length=50, choices=my_asymmetry, blank=True,verbose_name="Asymmetry")
    redness = models.CharField(max_length=50, choices=my_redness, blank=True,verbose_name="Redness")
    inflammation = models.CharField(max_length=50, choices=my_inflammation, blank=True,verbose_name="Inflammation")
    muscletwitch = models.CharField(max_length=50, choices=my_muscletwitch, blank=True,verbose_name="Muscle Twitch")
    swellingjoints = models.CharField(max_length=50, choices=my_swellinjoints, blank=True,verbose_name="Swellings in and around the joint")
    scaresjoints = models.CharField(max_length=50, choices=my_scaresjoints, blank=True,verbose_name="Scares in and around the joint")

    warmth = models.CharField(max_length=50, choices=my_palpwarmth, blank=True,verbose_name="Warmth")
    tenderness = models.CharField(max_length=50, choices=my_palptenderness, blank=True,verbose_name="Tenderness")
    swelling = models.CharField(max_length=50, choices=my_palpswelling, blank=True,verbose_name="Swelling")
    effusion = models.CharField(max_length=50, choices=my_palpeffusion, blank=True,verbose_name="Effusion")
    crepitus = models.CharField(max_length=50, choices=my_palpcrepitus, blank=True,verbose_name="Crepitus")
    activemovement = models.CharField(max_length=50, choices=my_palpactivemov, blank=True,verbose_name="Active movement")
    passivemovement = models.CharField(max_length=50, choices=my_palppassivemov , blank=True,verbose_name="Passive movement")

    spine = models.CharField(max_length=50, choices=my_spine, blank=True,verbose_name="Spine")
    gait1 = models.CharField(max_length=50, choices=my_gait1, blank=True,verbose_name="Gait")
    bone = models.CharField(max_length=50, choices=my_bone, blank=True,verbose_name="Bone")
    neck = models.CharField(max_length=50, choices=my_neck, blank=True,verbose_name="Neck")
    handswelljoints = models.CharField(max_length=50, choices=my_handsswelling, blank=True,verbose_name="Hands:swelling of MCP,PTP or DIP Joints")
    handfingdefo = models.CharField(max_length=50, choices=my_handsfingdef, blank=True,verbose_name="Hands:finger deformities")
    handfingmode = models.CharField(max_length=50, choices=my_handsfingnodes, blank=True,verbose_name="Hands:finger nodes")

    class Meta:
        verbose_name = 'Clinical Profile'
        verbose_name_plural = '2. Clinical Profile'

