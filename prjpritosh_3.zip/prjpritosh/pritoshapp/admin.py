from django.contrib import admin
from .models import perdemoinfopri
from .models import clinicalprofilepri
from .models import incexccriteria
from .models import asthikshyapri
from .models import bioradioinvpri

#from .models import examination

admin.site.site_header="PROJECT BY PRITOSH"
admin.site.site_title = "PROJECT BY PANCHAKARMA DEPARTMENT"
admin.site.index_title = "Welcome to Researcher Portal : PANCHAKARMA DEPARTMENT"

#admin.site.disable_action('delete_selected')

# Register your models here.
@admin.register(perdemoinfopri)
class perdemoinfoprAdminpri(admin.ModelAdmin):
    list_display= ('registrationdate','opdno','crno','caseno','ipdno','patientname','gender','agemn','dob','ageyr','address','contactno','email','marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify')
    search_fields=('opdno','crno','patientname')
    ordering=['patientname']
    list_filter=('ageyr','gender')

    fieldsets=[
        ('Personal Information', {'fields':['registrationdate','opdno','crno','caseno','ipdno','patientname','gender','dob','ageyr','agemn','address','contactno','email']}),
        ('Demographic Information', {'fields':['marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify']})
    ]
    # fieldsets=[
    #     ('Personal_Information', {'fields':['registrationdate','opdno']}),
    #     ('Demographic_Information', {'fields':['marritalstatus','edustatus']})
    # ]


@admin.register(clinicalprofilepri)
class clinicalprofileprAdminpri(admin.ModelAdmin):
    #list_display= ('registrationdate','opdno','crno','caseno','ipdno','dietaryhabit','addiction','addqty','addduration','sleep','bowelhabitat','stoolcons','urineoutput','phyex','alltomaterial','natureofall','symptoms','emotionalstress','gyncobshis','menarche','menopause','lmp','whitedisch', 'familyhist','surhis','prevhistoryspecify','builtavg','nutrition','height','weight','bmi','waistcirm','resprate','pulserate','bp','clubbing','cyanosis','cyanosispresent','temp','pallor','lymphadenopathy','edema','character','siteaffected','joints','jointsabnormal')
    list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
    search_fields = ['ipdno']
    fieldsets=[
     ('Personal History', {'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno', 'dietaryhabit', 'addiction', 'addqty', 'addduration','sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex', 'alltomaterial', 'natureofall', 'symptoms','emotionalstress']}),
     ('Gynecological & Obstetric_History',{'fields':['gyncobshis', 'menarche', 'menopause', 'lmp', 'whitedisch']}),

      ('Family History',{'fields':['familyhist']}),
      ('Surgical History', {'fields': ['surhis']}),
      ('Previous History', {'fields': ['prevhistoryspecify']}),
      ('General Physical Examination',{'fields': ['builtavg', 'nutrition', 'height', 'weight', 'bmi', 'waistcirm', 'resprate', 'pulserate',
      'bp', 'clubbing', 'cyanosis', 'cyanosispresent', 'temp', 'pallor', 'lymphadenopathy', 'edema', 'character',
      'siteaffected', 'joints', 'jointsabnormal']}),

      ('Respiratory System:', {'fields': ['respsystem']}),
      ('Gastro-Intestinal System:', {'fields': ['gastrointestsystem']}),
      ('Cardio-vascular System:', {'fields': ['cardiovascsystem']}),
      ('Nervous System:', {'fields': ['nervoussystem','nervoussystemabnormal']}),

      # ('Superficial reflexes:', {'fields': ['superficialreflexplanter','superficialreflexabdominal']}),
      # ('Deep reflexes:', {'fields': ['deepreflexbicepjerk', 'deepreflexkneejerk','deepreflexanklejerk']}),
      #
      # ('Signs of Meningeal Irritation', {'fields': ['signofmenirr', 'neckstiff']}),

      ('Musculo-skeletal system', {'fields': ['gait', 'deformities','musclewaisting','asymmetry','redness','inflammation','muscletwitch','swellingjoints','scaresjoints']}),

     ('Palpation :', {'fields': ['warmth', 'tenderness', 'swelling', 'effusion', 'crepitus', 'activemovement', 'passivemovement']}),
     #('', {'fields': ['gait1', 'bone', 'neck', 'handswelljoints', 'handfingdefo', 'handfingmode']}),
     ('', {'fields': ['gait1', 'bone']}),
    ]

@admin.register(incexccriteria)
class incexccriteriaAdmin(admin.ModelAdmin):
     list_display = ('registrationdate','opdno','crno','caseno','ipdno')
     fieldsets=[
                ('',{'fields':[('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')]}),
                ('Inclusion Creteria :', {'fields':['ic1','ic2','ic3']}),
                ('Exclusion Creteria :', {'fields': ['ec1', 'ec2', 'ec3','ec4','ec5','ec6']}),
                ('Screening Form Questions :', {'fields': ['sfq1', 'sfq2', 'sfq3', 'sfq4', 'sfq5', 'sfq6', 'sfq7']}),
     ]


@ admin.register(asthikshyapri)
class asthikshyaprAdminpri(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
        search_fields = ['ipdno']
        fieldsets = [
                     ('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                     ('keshapatana', {'fields': [('keshapatanaBT', 'keshapatanaAT')]}),
                     ('daantpatana', {'fields': [('daantpatanaBT', 'daantpatanaAT')]}),
                     ('nakaprapatana', {'fields': [('nakaprapatanaBT', 'nakaprapatanaAT')]}),
                     ('santhishithaliya', {'fields': [('santhishithaliyaBT', 'santhishithaliyaAT')]}),
                     ('rukshaya', {'fields': [('rukshayaBT', 'rukshayaAT')]}),
                     ('shrama', {'fields': [('shramaBT', 'shramaAT')]}),

                     ]

@ admin.register(bioradioinvpri)
class bioradioinvprAdminpri(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
        search_fields = ['ipdno']
        fieldsets = [
                     ('',{'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno']}),
                     ('Serum Calcium:', {'fields': [('serumCalciumBT', 'serumCalciumAT')]}),
                     ('Vitamin D:', {'fields': [('vitaminDBT', 'vitaminDAT')]}),
                     ('BMD:', {'fields': [('bmdBT', 'bmdAT')]}),
                     ]





# #from django.conf.urls import include, url
# #from django.contrib.admin import AdminSite
# from django.contrib import admin
# from .models import perdemoinfopri
# from .models import clinicalprofilepri
# #from .admin import pritosh.admin
#
# admin.site.site_header="PROJECT BY PRITOSH"
# admin.site.site_title = "PROJECT BY PANCHAKARMA DEPARTMENT"
# admin.site.index_title = "Welcome to Researcher Portal : PANCHAKARMA DEPARTMENT"
#
# #admin.site.disable_action('delete_selected')
#
# # Register your models here.
# @admin.register(perdemoinfopri)
# class perdemoinfoAdminpri(admin.ModelAdmin):
#
#     list_display= ('registrationdate','opdno','crno','caseno','ipdno','patientname','gender','agemn','dob','ageyr','address','contactno','email','marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify')
#     search_fields=('opdno','crno','patientname')
#     ordering=['patientname']
#     list_filter=('ageyr','gender')
#
#     fieldsets=[
#         ('Personal Information', {'fields':['registrationdate','opdno','crno','caseno','ipdno','patientname','gender','dob','ageyr','agemn','address','contactno','email']}),
#         ('Demographic Information', {'fields':['marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify']})
#     ]
# #    perdemoinfoAdminp = perdemoinfopri(name='perdemoinfoAdminp')
#     # fieldsets=[
#     #     ('Personal_Information', {'fields':['registrationdate','opdno']}),
#     #     ('Demographic_Information', {'fields':['marritalstatus','edustatus']})
#     # ]
#
#
# @admin.register(clinicalprofilepri)
# class clinicalprofileAdminpri(admin.ModelAdmin):
#     #list_display= ('registrationdate','opdno','crno','caseno','ipdno','dietaryhabit','addiction','addqty','addduration','sleep','bowelhabitat','stoolcons','urineoutput','phyex','alltomaterial','natureofall','symptoms','emotionalstress','gyncobshis','menarche','menopause','lmp','whitedisch', 'familyhist','surhis','prevhistoryspecify','builtavg','nutrition','height','weight','bmi','waistcirm','resprate','pulserate','bp','clubbing','cyanosis','cyanosispresent','temp','pallor','lymphadenopathy','edema','character','siteaffected','joints','jointsabnormal')
#     list_display = ('registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
#     search_fields = ['ipdno']
#     fieldsets=[
#      ('Personal History', {'fields':['registrationdate', 'opdno', 'crno', 'caseno', 'ipdno', 'dietaryhabit', 'addiction', 'addqty', 'addduration','sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex', 'alltomaterial', 'natureofall', 'symptoms','emotionalstress']}),
#      ('Gynecological & Obstetric_History',{'fields':['gyncobshis', 'menarche', 'menopause', 'lmp', 'whitedisch']}),
#
#       ('Family History',{'fields':['familyhist']}),
#       ('Surgical History', {'fields': ['surhis']}),
#       ('Previous History', {'fields': ['prevhistoryspecify']}),
#       ('General Physical Examination',{'fields': ['builtavg', 'nutrition', 'height', 'weight', 'bmi', 'waistcirm', 'resprate', 'pulserate',
#       'bp', 'clubbing', 'cyanosis', 'cyanosispresent', 'temp', 'pallor', 'lymphadenopathy', 'edema', 'character',
#       'siteaffected', 'joints', 'jointsabnormal']}),
#
#       ('Respiratory System:', {'fields': ['respsystem']}),
#       ('Gastro-Intestinal System:', {'fields': ['gastrointestsystem']}),
#       ('Cardio-vascular System:', {'fields': ['cardiovascsystem']}),
#       ('Nervous System:', {'fields': ['nervoussystem']}),
#
#       ('Superficial reflexes:', {'fields': ['superficialreflexplanter','superficialreflexabdominal']}),
#       ('Deep reflexes:', {'fields': ['deepreflexbicepjerk', 'deepreflexkneejerk','deepreflexanklejerk']}),
#
#       ('Signs of Meningeal Irritation', {'fields': ['signofmenirr', 'neckstiff']}),
#
#       ('Musculo-skeletal system', {'fields': ['gait', 'deformities','musclewaisting','asymmetry','redness','inflammation','muscletwitch','swellingjoints','scaresjoints']}),
#
#      ('Palpation :', {'fields': ['warmth', 'tenderness', 'swelling', 'effusion', 'crepitus', 'activemovement', 'passivemovement']}),
#      ('', {'fields': ['gait1', 'bone', 'neck', 'handswelljoints', 'handfingdefo', 'handfingmode']}),
#     ]
#
#
