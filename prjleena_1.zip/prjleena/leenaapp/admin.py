from django.contrib import admin
from .models import casereportform1leena
from .models import casereportform2leena
from .models import ashtvidhparikshaleena
from .models import dashvidhparikshleena
from .models import physicalexaminationleena
from .models import scaleexaminationleena
from .models import summaryofmedleena

#from .models import testme

# from django.contrib.admin import AdminSite
# class DivyaAdminSite(AdminSite):
#     site_header = "Divya Admin"
#     site_title = "Divya Admin Portal"
#     index_title = "Welcome to Divya Researcher Events Portal"
#
#     event_admin_site = DivyaAdminSite(name='divya_admin');

#from .models import examination

admin.site.site_header="PROJECT BY LEENA"
admin.site.site_title = "PROJECT BY PANCHAKARMA DEPARTMENT"
admin.site.index_title = "Welcome to Researcher Portal : PANCHAKARMA DEPARTMENT"

admin.site.disable_action('delete_selected')

# Register your models here.
@admin.register(casereportform1leena)
class casereportform1leenaAdmin(admin.ModelAdmin):
    list_display= ('hospitalcare','registrationdate','medicalrecordno','opdno','screeningid','ipdno')
    #,'patientname','gender','dob','ageyr','agemn','address','contactno','email')
    search_fields=('opdno','ipdno','screeningid','medicalrecordno','firstname','middlename','lastname')
    ordering=['firstname','middlename','lastname']
    list_filter=('ageyr','gender')

    fieldsets=[
        ('Scereening', {'fields':['hospitalcare','registrationdate','medicalrecordno','opdno','screeningid','firstname','middlename','lastname','gender','dob','ageyr','agemn','address','contactno','preferedmethodofcontact','email']}),
        ('Inclusion Criteria', {'fields': ['ic1', 'ic2', 'ic3', 'ic4']}),
        ('Exclusion Criteria', {'fields': ['ec1', 'ec2', 'ec3', 'ec4', 'ec5','ec6']}),
        ('Informed consent taken :', {'fields': ['iconsent']}),

    ]

@admin.register(casereportform2leena)
class casereportform2leenaAdmin(admin.ModelAdmin):
    list_display= ('inductiondate','completiondate','opdno','ipdno')\
                # ,'patientname','gender','dob','ageyr','agemn','address','contactno','email'
                #    'marritalstatus','edustatus', 'education', 'qualification', 'socecostatus', 'habitat', 'religion', 'chiefcomplaint',
                #    'preshistory', 'prevhistoryyesno','surghistory'
                #    )
    #list_display = ('centre','registrationdate', 'opdno', 'crno', 'caseno', 'ipdno')
    search_fields = ['opdno','crno','patientname','ipdno']
    fieldsets=[
     ('', {'fields': ['inductiondate','completiondate','screeningid','opdno','ipdno']}),
     ('Personal Identification', {'fields':['dietaryhabit', 'sleep', 'bowelhabitat', 'stoolcons', 'urineoutput', 'phyex',
                                            'alltomaterial', 'natureofallergy', 'symptoms','mentalstress','natureofstress','familyhist','surhis']}),
     # ('Demographic Information', {
     #        'fields': ['marritalstatus', 'edustatus', 'education', 'qualification','occupation', 'socecostatus', 'habitat',
     #                   'religion']})

     ('Gynecological/obstetric history', {
            'fields': ['gyncobshis', 'menarche', 'menopause', 'lmp', 'whitedisch', 'nooflivechildson','nooflivechilddaughter']}),
     ('Treatment history', {
         'fields': ['disease', 'medicine', 'therapy', 'since']}),
      ]

# @admin.register(ashtvidhparikshaleena)
# class ashtvidhparikshaleenaAdmin(admin.ModelAdmin):
#     list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')\
#         # ,'nadi', 'mala', 'mootra', 'mootrafreqday', 'mootrafreqnight','mootracolor','mootraother','jivha','jivhacolor',
#         #                              'Shabdha','sparsh','drik','akrita')
#     search_fields = ['opdno','crno','ipdno']
#     fieldsets=[
#      ('', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno']}),
#      ('Ashtavidh Pariksha',{'fields':['nadi', 'mala', 'mootra', 'jivha','Shabdha','sparsh','drik','akrita']}),
#
#  ]
#
# @admin.register(dashvidhparikshleena)
# class dashvidhparikshleenaAdmin(admin.ModelAdmin):
#     list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
#
#                     # 'prakruti', 'vrikruti', 'rasaTwakaSaara', 'raktaSaara', 'mamsaSaara', 'medaSaara', 'asthiSaara',
#                     # 'majjaSaara', 'shukraSaara', 'saara', 'samahana', 'aharasatmya', 'deshasatmya', 'kaalsatmya', 'pravarasatmya',
#                     # 'pravarasatmya', 'avarasatmya','asssatva', 'satvatype',
#                     # 'assaaharshakti1', 'assaaharshakti2', 'scoreaaharshakti',
#                     # 'assvyayamshakti1', 'assvyayamshakti2', 'scorevyayamshakti',
#                     # 'vaya'
#                     # )
#     search_fields = ['opdno','crno','ipdno']
#     fieldsets=[
#      ('', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno']}),
#      ('Dashvidh Pariksha',{'fields':['prakruti', 'vrikruti', 'rasatwakasaara', 'raktaSaara', 'mamsaSaara','medaSaara','asthiSaara','majjaSaara','shukraSaara',
#                                      'saara','samahana','aharasatmya','deshasatmya','kaalsatmya',
#                                      'pravarasatmya','madhyasatmya','avarasatmya',
#                                      'asssatva','satvatype']}),
#     ('Assessment of aahar shakti',{'fields':['assaaharshakti1','assaaharshakti2','scoreaaharshakti']}),
#     ('Assessment of vyayam shakti', {'fields': ['assvyayamshakti1', 'assvyayamshakti2', 'scorevyayamshakti']}),
#     ('vaya', {'fields': ['vaya']}),
#
#  ]

@admin.register(ashtvidhparikshaleena)
class ashtvidhparikshaleenaAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')\
        # ,'nadi', 'mala', 'mootra', 'mootrafreqday', 'mootrafreqnight','mootracolor','mootraother','jivha','jivhacolor',
        #                              'Shabdha','sparshUshna','sparshAnushna','sparshRuksha','sparshKhara','sparshMrudhu','drik','akrita')
    search_fields = ['opdno','crno','ipdno']
    fieldsets=[
     ('', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno']}),
     ('Ashtavidh Pariksha',{'fields':['nadi', 'mootra','mala', 'jivha',
                                     'Shabdha','sparsh','drika','akriti']}),

 ]

@admin.register(dashvidhparikshleena)
class dashvidhparikshleenaAdmin(admin.ModelAdmin):
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')

                    # 'prakruti', 'vrikruti', 'rasaTwakaSaara', 'raktaSaara', 'mamsaSaara', 'medaSaara', 'asthiSaara',
                    # 'majjaSaara', 'shukraSaara', 'saara', 'samahana', 'aharasatmya', 'deshasatmya', 'kaalsatmya', 'pravarasatmya',
                    # 'pravarasatmya', 'avarasatmya','asssatva', 'satvatype',
                    # 'assaaharshakti1', 'assaaharshakti2', 'scoreaaharshakti',
                    # 'assvyayamshakti1', 'assvyayamshakti2', 'scorevyayamshakti',
                    # 'vaya'
                    # )
    search_fields = ['opdno','crno','ipdno']
    fieldsets=[
     ('', {'fields':['registrationdate', 'opdno', 'crno', 'ipdno']}),
     ('Dashvidh Pariksha',{'fields':['prakruti', 'vrikruti', 'rasaTwakaSaara', 'raktaSaara', 'mamsaSaara','medaSaara','asthiSaara',
                                     'majjaSaara','shukraSaara','saara','samahana','aharasatmya','deshasatmya','kaalsatmya','satvatype']}),
                                     #'pravarasatmya','avarasatmya','asssatva',
    ('Assessment of aahar shakti',{'fields':['aahartype','assaaharshakti1','assaaharshakti2','scoreaaharshakti']}),
    ('Assessment of vyayam shakti', {'fields': ['vyayamtype','assvyayamshakti1', 'assvyayamshakti2', 'scorevyayamshakti']}),
    ('vaya', {'fields': ['vaya']}),

 ]

@admin.register(physicalexaminationleena)
class physicalexaminationleenaAdmin(admin.ModelAdmin):
    #list_display= ('registrationdate','opdno','crno','caseno','ipdno','dietaryhabit','addiction','addqty','addduration','sleep','bowelhabitat','stoolcons','urineoutput','phyex','alltomaterial','natureofall','symptoms','emotionalstress','gyncobshis','menarche','menopause','lmp','whitedisch', 'familyhist','surhis','prevhistoryspecify','builtavg','nutrition','height','weight','bmi','waistcirm','resprate','pulserate','bp','clubbing','cyanosis','cyanosispresent','temp','pallor','lymphadenopathy','edema','character','siteaffected','joints','jointsabnormal')
    list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
    search_fields = ['opdno', 'crno', 'ipdno']
    fieldsets=[
      ('Respiratory System:', {'fields': ['respsystem','respsystemspecify','respcs']}),
      ('Cardio-vascular System:', {'fields': ['cardiovascsystem','cardiovascsystemspecify','cardiovasc']}),
      ('Nervous System:', {'fields': ['nervoussystem','nervoussystemspecify','nervsc']}),
      ('Musculo-Skeletal:', {'fields': ['musculoskeletal', 'musculoskeletalspecify', 'musculocs']}),
      ('Genito-urinary system:', {'fields': ['genitourinarysystem','genitourinarysystemspecify','genitocs']}),
      #('Gastro-Intestinal System:', {'fields': ['gastrointestsystem', 'gastrointestsystemspecify']}),
      ('Other Specify:', {'fields': ['other','otherspecify','othercs']}),
      ('Any other note:', {'fields': ['anyothernote']}),

      ('6) History of present illness::', {'fields': ['hisofpresentillduration','hisofpresentillanyotherinfo']}),

      ('7) History of previous illness :', {'fields': ['hisofprevtill']}),

      ('8) General Physical Examination',
         {'fields': ['builtavg', 'nutrition', 'height', 'weight', 'bmi', 'waistcirm', 'resprate', 'pulserate','rhythm',
                     'bp', 'clubbing', 'cyanosis', 'cyanosispresent', 'temp']}),

]

@admin.register(scaleexaminationleena)
class scaleexaminationleenaAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
        search_fields = ['opdno', 'crno', 'ipdno']
        fieldsets = [
            ('Perceived Stress scale:', {'fields': ['psc1','psc2','psc3','psc4','psc5','psc6','psc7','psc8','psc9','psc10','mytotalscore']}),
            ('Quality of Life Scale:', {
                'fields': ['qol1', 'qol2', 'qol3', 'qol4', 'qol5', 'qol6', 'qol7', 'qol8', 'qol9', 'qol10',
                           'qol11','qol12','qol13','qol14','qol15','qol16']}),
            ('Medication Taken:', {'fields': ['medtaken']}),
            ('Previous Medical History:', {
                'fields': ['cardiovascular', 'respiratory', 'hepatobiliary', 'gastrointestinal', 'genitourinary', 'endocrine',
                           'haematological', 'musculoskeletal', 'neoplasia','neurological', 'psychological',
                           'immunological', 'dermatological', 'allergies', 'eyesearnosethroat','other']}),
            ('Physical Examination:', {
                'fields': ['ga', 'heart', 'lung', 'abdomen', 'extremities']}),
            ('Vital Sign:', {
                'fields': ['ps', 'bp', 'srcortisol', 'finalresult', 'description','contradict']}),
        ]

@admin.register(summaryofmedleena)
class summaryofmedleenaAdmin(admin.ModelAdmin):
        list_display = ('registrationdate', 'opdno', 'crno', 'ipdno')
        search_fields = ['opdno', 'crno', 'ipdno']
        fieldsets = [
                ('Summary of Medication:', {
                    'fields': ['medication', 'doses', 'units', 'reason', 'startdate', 'stopdate']}),
                ('Serum Cortisol:', {'fields': ['srcortisol01', 'srcortisol14']}),
                ('Scale (Scores of scale):', {'fields': [('scale01', 'scale07','scale14'),]}),
                ('PSS (Perceived Stress Scale)):', {'fields': [('pss01', 'pss07', 'pss14'),]}),
                ('QOL (Quality of life):', {'fields': [('qol01', 'qol07', 'qol14'), ]}),

            ]