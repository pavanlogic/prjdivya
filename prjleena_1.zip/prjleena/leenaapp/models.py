from django.db import models
from django.utils import timezone
from  datetime import datetime,date

class casereportform1leena(models.Model):
    my_gender = (
        ("Male", "Male"),
        ("Female", "Female"),
    )
    my_ic = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_jinv = (
        ("0", "0"),
        ("1", "1"),
        ("2", "2"),
        ("3", "3"),
        ("5", "5"),
    )
    my_sero = (
        ("0", "0"),
        ("2", "2"),
        ("3", "3"),
    )
    my_apr = (
        ("0", "0"),
        ("1", "1"),
    )
    my_dusymp = (
        ("0", "0"),
        ("1", "1"),
    )
    hospitalcare = models.CharField(max_length=200, verbose_name="Hospital Care")
    registrationdate = models.DateField(null=True, verbose_name="Registration Date")
    medicalrecordno = models.IntegerField(null=True, verbose_name="Medical Record No.")
    opdno = models.IntegerField(null=True, verbose_name="OPD No.")
    ipdno = models.IntegerField(null=True, verbose_name="IPD No.")
    screeningid = models.IntegerField(null=True, verbose_name="Screening ID")
    firstname = models.CharField(max_length=200, verbose_name="First Name")
    middlename = models.CharField(max_length=200, verbose_name="Middle Name")
    lastname = models.CharField(max_length=200, verbose_name="Last Name")

    dob = models.DateField(verbose_name="D.O.B")
    ageyr = models.IntegerField(verbose_name="Age(Year)")
    agemn = models.IntegerField(verbose_name="Age(Month)")
    gender = models.CharField(max_length=50, choices=my_gender, verbose_name="Gender")
    address = models.CharField(max_length=200, verbose_name="Address")
    contactno = models.CharField(max_length=50, verbose_name="Contact No.")
    preferedmethodofcontact= models.CharField(max_length=50, verbose_name="Prefered Method of Contact")
    email = models.EmailField(max_length=100, verbose_name="Email")

   # ==============INCLUSION CRITERIA================
    ic1 = models.CharField(max_length=50, choices=my_ic, verbose_name="1.Is the subject aged between 18 to 60 years?")
    ic2 = models.CharField(max_length=50, choices=my_ic, verbose_name="2.Is the subject having stress (moderate or severe)?")
    ic3 = models.CharField(max_length=50, choices=my_ic, verbose_name="3.Is the subject suffering mental illness (on the basis of questionnaire)?")
    ic4 = models.CharField(max_length=50, choices=my_ic, verbose_name="4.Has the subject willingly given written informed consent?")

    # ==============EXCLUSION CRITERIA================
    ec1 = models.CharField(max_length=50, choices=my_ic, verbose_name="1.Known case of Neuropathy.")
    ec2 = models.CharField(max_length=50, choices=my_ic, verbose_name="2.Is the subject is Known case of any major illness")
    ec3 = models.CharField(max_length=50, choices=my_ic, verbose_name="3.Is the subject a pregnant or lactating women?")
    ec4 = models.CharField(max_length=50, choices=my_ic, verbose_name="4.Poorly controlled hypertension (systolic >140 and diastolic >90 mm of Hg)")
    ec5 = models.CharField(max_length=50, choices=my_ic, verbose_name="5.Those who have completed participation in any other clinical trial drugs or their ingredients in one -month period.")
    ec6 = models.CharField(max_length=50, choices=my_ic, verbose_name="6.Person having mild stress as per Perceived Stress Scale")
    #===========================CONSENT=====================
    iconsent = models.CharField(max_length=50, choices=my_ic, verbose_name="Informed consent taken :")
    #=======================================================
    class Meta:
        verbose_name = 'CASE RECORD FORM  1:  SCREENING'
        verbose_name_plural = "1. Case Record Form 1(Screening):"

class casereportform2leena(models.Model):
    my_gender = (
        ("Male", "Male"),
        ("Female", "Female"),
    )

    my_marritalstatus = (
        ("Married", "Married"),
        ("Unmarried", "Unmarried"),
        ("other", "other"),
    )

    my_edustatus = (
        ("Illiterate", "Illiterate"),
        ("Literate", "Literate"),
        ("upto10th", "upto 10th"),
        ("upto12th", "upto 12th"),
        ("Graduate", "Graduate"),
        ("PostGraduate ", "Post Graduate"),
    )

    my_socecostatus = (
        ("Above Poverty Line", "Above Poverty Line"),
        ("Below Poverty Line", "Below Poverty Line"),
    )

    my_habitat = (
        ("Urban", "Urban"),
        ("Semi-Urban", "Semi-Urban"),
        ("Rural", "Rural"),
    )

    my_religion = (
        ("Hindu", "Hindu"),
        ("Muslim", "Muslim"),
        ("Sikh", "Sikh"),
        ("Christian", "Christian"),
        ("Others", "Others"),
    )
    my_prevhis = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_occupation = (
        ("Deskwork", "Desk work"),
        ("Fieldworkwithphysicallabour", "Field work with physical labour"),
        ("Fieldwork ", "Field work"),
        ("Housewife", "House wife"),
        ("Student", "Student"),
        ("Others", "Others"),
    )
    my_gyncobshis = (
        ("Applicable", "Applicable"),
        ("Non-Applicable", "Non-Applicable"),
    )
    my_whitedisch = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_diethabit = (
        ("Vegetarian", "Vegetarian"),
        ("Non-Vegetarian", "Non-Vegetarian"),
    )
    my_addictions = (
        ("Tea", "Tea"),
        ("Coffee", "Coffee"),
        ("Tea", "Tea"),
        ("Coffee", "Coffee"),
        ("Alcohol", "Alcohol"),
        ("Tobacco", "Tobacco"),
        ("Smoking", "Smoking"),
        ("None", "None"),
    )
    my_sleep = (
        ("Normal", "Normal"),
        ("Disturbed", "Disturbed"),
    )
    my_bowelhabit = (
        ("Regular", "Regular"),
        ("Irregular", "Irregular"),
    )
    my_stoolconsist = (
        ("Normal", "Normal"),
        ("Loose", "Loose"),
        ("Constipated", "Constipated"),
    )
    my_urineoutput = (
        ("Normal", "Normal"),
        ("Frequent", "Frequent"),
        ("Urgency", "Urgency"),
        ("Strangury", "Strangury"),
        ("Nocturia", "Nocturia"),
    )
    my_physicalex = (
        ("Heavy Labour", "Heavy Labour"),
        ("Moderate Labour", "Moderate Labour"),
        ("Office Job", "Office Job"),
        ("Sedentary", "Sedentary"),
    )
    my_alltomaterial = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_natureofall=(
        ('Dust','Dust'),
        ('Moulds','Moulds'),
        ('Denders','Denders'),
        ('Food','Food'),
        ('Drugs','Drugs'),
        ('Pollens','Pollens'),
        ('Anyother','Anyother'),
    )
    my_mentalstress=(
        ("Yes", "Yes"),
        ("No", "No"),
    )
    my_natureofstress=(
        ("Average", "Average"),
        ("Moderate", "Moderate"),
        ("Toomuch", "Too much"),
    )
    inductiondate = models.DateField(null=True, verbose_name="1.Date of induction into the clinical trial")
    completiondate = models.DateField(null=True, verbose_name="2.Expected date of completion of the clinical trial")
    screeningid = models.IntegerField(verbose_name="3.Participants screening Id:")
    #crno = models.IntegerField(null=True, verbose_name="CR No.")
    opdno = models.IntegerField(null=True, verbose_name="OPD No.")
    # caseno = models.IntegerField(null=True,verbose_name="Case No.")
    ipdno = models.IntegerField(null=True, verbose_name="IPD No.")
    # patientname = models.CharField(max_length=200, verbose_name="Name of Participant")
    # ageyr = models.IntegerField(verbose_name="Age(Year)")
    # agemn = models.IntegerField(verbose_name="Age(Month)")
    # dob = models.DateField(verbose_name="D.O.B")
    # gender = models.CharField(max_length=50, choices=my_gender, verbose_name="Gender")
    # address = models.CharField(max_length=200, verbose_name="Address")
    # contactno = models.CharField(max_length=50, verbose_name="Contact No.")
    # preferedmethodcontact = models.CharField(max_length=50, verbose_name="Prefered Method of Contact")
    # email = models.EmailField(max_length=100, verbose_name="Email")

    marritalstatus = models.CharField(max_length=50, choices=my_marritalstatus, verbose_name="Marrital Status")
    edustatus = models.CharField(max_length=50, choices=my_edustatus, verbose_name="Educational Status")
    education = models.CharField(max_length=200, verbose_name="Education")
    qualification = models.CharField(max_length=200, verbose_name="Qualification")
    occupation = models.CharField(max_length=200,choices=my_occupation,verbose_name="Occupation")
    socecostatus = models.CharField(max_length=50, choices=my_socecostatus, verbose_name="Socio-Economic Status")
    habitat = models.CharField(max_length=50, choices=my_habitat, verbose_name="Habitat")
    religion = models.CharField(max_length=50, choices=my_religion, verbose_name="Religion")

    dietaryhabit = models.CharField(max_length=50, choices=my_diethabit, blank=True, verbose_name="Dietary Habits")
    sleep = models.CharField(max_length=50, choices=my_sleep, blank=True, verbose_name="Sleep")
    bowelhabitat = models.CharField(max_length=50, choices=my_bowelhabit, blank=True, verbose_name="Bowel Habits")
    stoolcons = models.CharField(max_length=50, choices=my_stoolconsist, blank=True, verbose_name="Stool Consistency")
    urineoutput = models.CharField(max_length=50, choices=my_urineoutput, blank=True, verbose_name="Urine Output")
    phyex = models.CharField(max_length=50, choices=my_physicalex, blank=True, verbose_name="Physical Exercise")
    alltomaterial = models.CharField(max_length=50, choices=my_alltomaterial, blank=True,
                                     verbose_name="Allergy to Some Material")
    natureofallergy = models.CharField(max_length=50, choices=my_natureofall, blank=True,
                                     verbose_name="If yes, then nature of the allergen ")
    symptoms = models.CharField(max_length=100, blank=True, verbose_name="Symptom(s) produced upon exposure ")
    mentalstress = models.CharField(max_length=50, blank=True,choices=my_mentalstress, verbose_name="Any Mental Stress")
    natureofstress = models.CharField(max_length=50, blank=True, choices=my_natureofstress,verbose_name="If yes, then nature of the stress")
    familyhist = models.TextField(max_length=200, blank=True, verbose_name="Family History")
    surhis = models.TextField(max_length=200, blank=True, verbose_name="Surgical History")

    gyncobshis = models.CharField(max_length=50,choices=my_gyncobshis, blank=True,verbose_name="Gynecological/obstetric history")
    menarche = models.CharField(max_length=200, blank=True,verbose_name="a)Menarche(years)")
    menopause = models.CharField(max_length=200, blank=True,verbose_name="b)Menopause(years")
    lmp = models.DateField(null=True, blank=True,verbose_name="LMP")
    whitedisch = models.CharField(max_length=50,choices=my_whitedisch, blank=True,verbose_name="White discharge per vagina")
    nooflivechildson = models.CharField(max_length=200, blank=True, verbose_name="Son(s)")
    nooflivechilddaughter = models.CharField(max_length=200, blank=True, verbose_name="Daughter(s)")

    disease = models.CharField(max_length=100, blank=True, verbose_name="Disease")
    medicine = models.CharField(max_length=100, blank=True, verbose_name="Medicine")
    therapy = models.CharField(max_length=100, blank=True, verbose_name="Therapy/Procedure")
    since = models.CharField(max_length=100, blank=True, verbose_name="Taking Since")

    class Meta:
        verbose_name = 'Case Record Form 2:(Baseline Assessment'
        verbose_name_plural = "2. Case Record Form 2:(Baseline Assessment"

# class ashtvidhparikshaleena(models.Model):
#     # =========================ASTAVIDDHA PARIKSHA==========================
#     my_mala = (
#         ("Baddha", "Baddha"),
#         ("Abaddha", "Abaddha"),
#         ("Vikrita", "Vikrita"),
#         ("Prakrata", "Prakrata"),
#         ("Atisara", "Atisara"),
#         ("Pravahik", "Pravahik"),
#         ("Grahini", "Grahini"),
#         ("Anyother", "Any other"),
#     )
#     my_jivha = (
#         ("coated", "Coated(lipta)"),
#         ("Uncoated", "Uncoated(alipta)"),
#         ("PartiallyCoated", "Partially Coated (Alpalipta)"),
#         ("color", "Color"),
#     )
#     my_jivhacolor = (
#         ("Whitish", "Whitish"),
#         ("Pinkish", "Pinkish"),
#         ("Blackish", "Blackish"),
#     )
#     my_drikcolor = (
#         ("White", "White"),
#         ("Pink", "Pink"),
#         ("Red", "Red"),
#         ("Yellow", "Yellow"),
#     )
#     my_akrita = (
#         ("Sthula", "Sthula"),
#         ("Madhyama", "Madhyama"),
#         ("Heena", "Heena"),
#     )
#     my_Shabdha = (
#         ("Prakrita", "Prakrita"),
#         ("Vikrita", "Vikrita"),
#     )
#     my_mootra = (
#         ("Prakrita", "Prakrita"),
#         ("Vikrita", "Vikrita"),
#     )
#
#     registrationdate = models.DateField(null=True,verbose_name="Registration Date")
#     opdno = models.IntegerField(null=True,verbose_name="OPD No.")
#     #caseno = models.IntegerField(null=True,verbose_name="Case No.")
#     crno = models.IntegerField(null=True,verbose_name="CR No.")
#     ipdno = models.IntegerField(null=True,verbose_name="IPD No.")
#
#     nadi = models.CharField(max_length=50, blank=True, verbose_name="Nadi")
#     mala = models.CharField(max_length=50, blank=True, choices=my_mala, verbose_name="Mala")
#     mootra = models.CharField(max_length=50, blank=True, choices=my_mootra, verbose_name="Mootra")
#     mootrafreqday = models.CharField(max_length=50, blank=True, verbose_name="Frequency: Day")
#     mootrafreqnight = models.CharField(max_length=50, blank=True, verbose_name="Night")
#     mootracolor = models.CharField(max_length=50, blank=True, verbose_name="Color")
#     mootraother = models.CharField(max_length=50, blank=True, verbose_name="Other associated complaints")
#
#     jivha = models.CharField(max_length=50, blank=True, choices=my_jivha, verbose_name="Jihva")
#     jivhacolor = models.CharField(max_length=50, blank=True, choices=my_jivhacolor, verbose_name="Color")
#
#     Shabdha  = models.CharField(max_length=50, blank=True, choices=my_Shabdha, verbose_name="Shabdha")
#
#     sparsh = models.CharField(max_length=50, blank=True, verbose_name="Sparsh")
#
#     drik = models.CharField(max_length=50, blank=True, choices = my_drikcolor, verbose_name="Drik-Color of conjunctiva")
#     akrita = models.CharField(max_length=50, blank=True, choices = my_akrita, verbose_name="Akrita ")
#
#     class Meta:
#         verbose_name = 'Astavidha Pariksha'
#         verbose_name_plural = "3. Astavidha Pariksha"
#
# # =========================DASHVIDDHA PARIKSHA==========================
# class dashvidhparikshleena(models.Model):
#
#     my_prakruti = (
#         ("V", "V"),
#         ("P", "P"),
#         ("VP", "VP"),
#         ("VK", "VK"),
#         ("PK", "PK"),
#         ("Sannipataj", "Sannipataj"),
#     )
#     my_vrikruti = (
#         ("prakrutisamasemveta ", "prakrutisamasemveta"),
#         ("vrikrutisamasemveta", "vrikrutisamasemveta"),
#     )
#     my_rasatwakaSaara = (
#         ("twacha", "Snigdha evum prassana twacha"),
#         ("sparsha", "Alpa evum komalloma sparsha"),
#     )
#     my_raktaSaara= (
#         ("akshi", "Snigdha and rakta varna of akshi"),
#         ("jivha", "Snigdha and rakta varna of jivha"),
#         ("nakha", "Snigdha and rakta varna of nakha"),
#         ("panitala", "Snigdha and rakta varna of panitala"),
#     )
#     my_mamsaSaara=(
#         ("Sthira", "Sthira"),
#         ("griva", "pustha evum guru muscle of griva"),
#         ("bahu", "pustha evum guru muscle of bahu"),
#         ("adhoshakha", "pustha evum guru muscle of adhoshakha"),
#     )
#     my_medaSaara=(
#         ("Snighdakesha ", "Snighdakesha "),
#         ("oshtha", "oshtha"),
#         ("nakha", "nakha"),
#     )
#     my_asthiSaara=(
#         ("Sthoola sandhi", "Sthoola sandhi"),
#         ("chibuka", "chibuka"),
#         ("Jatru", "Jatru"),
#     )
#     my_majjaSaara=(
#         ("Snigdha varna", "Snigdha varna"),
#         ("snigdhaswara", "snigdhaswara"),
#     )
#     my_shukraSaara=(
#         ("Kshirapoornalochana", "SKshirapoornalochana"),
#         ("saumayaprekshan", "saumayaprekshan"),
#         ("mahaspikha", "mahaspikha"),
#     )
#
#     registrationdate = models.DateField(null=True,verbose_name="Registration Date")
#     opdno = models.IntegerField(null=True,verbose_name="OPD No.")
#     #caseno = models.IntegerField(null=True,verbose_name="Case No.")
#     crno = models.IntegerField(null=True,verbose_name="CR No.")
#     ipdno = models.IntegerField(null=True,verbose_name="IPD No.")
#
#     prakruti = models.CharField(max_length=50, blank=True, choices=my_prakruti, verbose_name="Prakruti")
#     vrikruti = models.CharField(max_length=50, blank=True, choices=my_vrikruti, verbose_name="Vrikruti")
#
#     rasatwakasaara = models.CharField(max_length=50, blank=True, choices=my_rasatwakaSaara, verbose_name="Rasa/TwakaSaara")
#     raktaSaara = models.CharField(max_length=50, blank=True, choices=my_raktaSaara, verbose_name="RaktaSaara")
#     mamsaSaara = models.CharField(max_length=50, blank=True, choices=my_mamsaSaara, verbose_name="MamsaSaara")
#     medaSaara = models.CharField(max_length=50, blank=True, choices=my_medaSaara, verbose_name="MedaSaara")
#     asthiSaara = models.CharField(max_length=50, blank=True, choices=my_asthiSaara, verbose_name="AsthiSaara")
#     majjaSaara = models.CharField(max_length=50, blank=True, choices=my_majjaSaara, verbose_name="MajjaSaara")
#     shukraSaara = models.CharField(max_length=50, blank=True, choices=my_shukraSaara, verbose_name="ShukraSaara")
#     #=========================Type of Sara===================================
#     my_saara=(
#         ("rasatwakasaara","Rasa/twakasaara"),
#         ("raktasaara","raktasaara"),
#         ("mamsasaara", "mamsasaara"),
#         ("medasaara", "medasaara"),
#         ("asthisaara", "asthisaara"),
#         ("majjasaara", "majjasaara"),
#         ("sukrasaara", "sukrasaara"),
#     )
#     my_samahana=(
#         ("Pravara","Pravara"),
#         ("Madhyama","Madhyama"),
#         ("Avara ", "Avara"),
#     )
#     my_satmya=(
#         ("3","3"),
#         ("2","2"),
#         ("1","1"),
#     )
#     my_satva=(
#         ("Pravar","Pravar"),
#         ("madhyama","madhyama"),
#         ("avara","avara"),
#     )
#     saara = models.CharField(max_length=50,choices=my_saara, blank=True,verbose_name="Types of Saara")
#     samahana = models.CharField(max_length=50,choices=my_samahana, blank=True,verbose_name="Types of samahana")
#
#     aharasatmya  = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Aharasatmya(change of food habits)")
#     deshasatmya  = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Deshasatmya(change of place)")
#     kaalsatmya   = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Kaal satmya(change of season)")
#
#     pravarasatmya  = models.CharField(max_length=50, blank=True,verbose_name="Pravarasatmya(ahara+ desha+ kaal)[0-9]")
#     madhyasatmya = models.CharField(max_length=50, blank=True, verbose_name="Madhyamasatmya(ahara+ desha+ kaal)[6-8]")
#     avarasatmya  = models.CharField(max_length=50, blank=True, verbose_name="Avarasatmya (ahara+ desha+ kaal)[3-5]")
#
#     # ================Assessment of Satva================
#     my_asssatva = (
#         ("satva1", "In the recent past, any event of a crisis like loss of a family member/ close friend, loss of money/loss in business or Severe deterioration in the health of self or loved one"),
#         ("satva2", "Was tolerated well (pravarasatva)"),
#         ("satva3", "Could be tolerated with support of others (madhyamasatva)"),
#         ("satva4", "Was inconsolable (avarasatva)"),
#     )
#     asssatva = models.CharField(max_length=500, choices=my_asssatva, default='0', verbose_name="Assessment of Satva")
#
#     satvatype = models.CharField(max_length=50,choices=my_satva ,blank=True, verbose_name="Type of satva")
#
#     # ================Assessment of aahar shakti================
#     my_aaharshakti = (
#         ("3", "3"),
#         ("2", "2"),
#         ("1", "1"),
#     )
#     assaaharshakti1 = models.CharField(max_length=50, choices=my_aaharshakti, default='0', verbose_name="how many major meals do you have a day? ")
#     assaaharshakti2 = models.CharField(max_length=500, choices=my_aaharshakti, default='0',   verbose_name="how many major meals do you have a day? ")
#     scoreaaharshakti= models.CharField(max_length=500, default='0', verbose_name="Score :")
#     # ================Assessment of vyayam shakti================
#     my_vyayamshakti = (
#         ("3", "3"),
#         ("2", "2"),
#         ("1", "1"),
#     )
#     assvyayamshakti1 = models.CharField(max_length=50, choices=my_vyayamshakti, default='0',
#                                       verbose_name="can you climb up stairs to the next floor of the house?")
#     assvyayamshakti2 = models.CharField(max_length=500, choices=my_vyayamshakti, default='0',
#                                       verbose_name="daily routine activities:")
#     scorevyayamshakti = models.CharField(max_length=500, default='0', verbose_name="Score :")
#
#     my_vaya = (
#         ("Bal", "Bal"),
#         ("Yuva", "Yuva"),
#         ("madhyam", "Madhyam"),
#         ("vriddha", "Vriddha"),
#     )
#     vaya = models.CharField(max_length=50, choices=my_vaya, default='0',verbose_name="Vaya")
#
#     class Meta:
#         verbose_name = 'Dashvidha Pariksha'
#         verbose_name_plural = '4. Dashvidha Pariksha'
#
class ashtvidhparikshaleena(models.Model):
    # =========================ASTAVIDDHA PARIKSHA==========================
    my_mala = (
        ("Baddha", "Baddha"),
        ("Abaddha", "Abaddha"),
        ("Vikrita", "Vikrita"),
        ("Prakrata", "Prakrata"),
        ("Atisara", "Atisara"),
        ("Pravahik", "Pravahik"),
        ("Grahini", "Grahini"),
        ("Anyother", "Any other"),
    )
    my_jivha = (
        ("saam", "saam"),
        ("niram", "niram"),
    )
    my_jivhacolor = (
        ("Whitish", "Whitish"),
        ("Pinkish", "Pinkish"),
        ("Blackish", "Blackish"),
    )
    my_drikcolor = (
        ("White", "White"),
        ("Pink", "Pink"),
        ("Red", "Red"),
        ("Yellow", "Yellow"),
    )
    my_akrita = (
        ("Sthula", "Sthula"),
        ("Madhyama", "Madhyama"),
        ("Heena", "Heena"),
    )
    my_Shabdha = (
        ("Prakrita", "Prakrita"),
        ("Vikrita", "Vikrita"),
    )
    my_mootra = (
        ("Prakrita", "Prakrita"),
        ("Vikrita", "Vikrita"),
    )
    my_sparsh=(
        ("Ushna","Ushna"),
        ("Anushna", "Anushna"),
        ("Ruksha","Ruksha"),
        ("Khara","Khara"),
        ("Mrudhu","Mrudhu"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    nadi = models.CharField(max_length=50, blank=True, verbose_name="Nadi")
    mootra = models.CharField(max_length=50, blank=True, choices=my_mootra, verbose_name="Mootra")
    mala = models.CharField(max_length=50, blank=True, choices=my_mala, verbose_name="Mala")

    # mootrafreqday = models.CharField(max_length=50, blank=True, verbose_name="Frequency: Day")
    # mootrafreqnight = models.CharField(max_length=50, blank=True, verbose_name="Night")
    # mootracolor = models.CharField(max_length=50, blank=True, verbose_name="Color")
    # mootraother = models.CharField(max_length=50, blank=True, verbose_name="Other associated complaints")

    jivha = models.CharField(max_length=50, blank=True, choices=my_jivha, verbose_name="Jivha")
    #jivhacolor = models.CharField(max_length=50, blank=True, choices=my_jivhacolor, verbose_name="Color")

    Shabdha  = models.CharField(max_length=50, blank=True, choices=my_Shabdha, verbose_name="Shabdha")
    sparsh = models.CharField(max_length=50,choices=my_sparsh, blank=True, verbose_name="Sparsh")

    # sparshUshna = models.CharField(max_length=50, blank=True, verbose_name="Sparsha-Ushna")
    # sparshAnushna = models.CharField(max_length=50, blank=True, verbose_name="-Anushna")
    # sparshRuksha = models.CharField(max_length=50, blank=True, verbose_name="-Ruksha")
    # sparshKhara = models.CharField(max_length=50, blank=True, verbose_name="-Khara")
    # sparshMrudhu = models.CharField(max_length=50, blank=True, verbose_name="-Mrudhu")

    drika = models.CharField(max_length=50, blank=True, choices = my_drikcolor, verbose_name="Drika")
    akriti = models.CharField(max_length=50, blank=True, choices = my_akrita, verbose_name="Akriti ")

    class Meta:
        verbose_name = 'Astavidha Pariksha'
        verbose_name_plural = "4. Astavidha Pariksha"

# =========================DASHVIDDHA PARIKSHA==========================
class dashvidhparikshleena(models.Model):

    my_prakruti = (
        ("K", "K"),
        ("V", "V"),
        ("P", "P"),
        ("VP", "VP"),
        ("VK", "VK"),
        ("PK", "PK"),
        ("Sannipataj", "Sannipataj"),
    )
    my_vrikruti = (
        ("prakrutisamasemveta ", "prakrutisamasemveta"),
        ("vrikrutisamasemveta", "vrikrutisamasemveta"),
    )
    my_rasatwakaSaara = (
        ("twacha", "Snigdha evum prassana twacha"),
        ("sparsha", "Alpa evum komalloma sparsha"),
    )
    my_raktaSaara= (
        ("akshi", "Snigdha and rakta varna of akshi"),
        ("jivha", "Snigdha and rakta varna of jivha"),
        ("nakha", "Snigdha and rakta varna of nakha"),
        ("panitala", "Snigdha and rakta varna of panitala"),
    )
    my_mamsaSaara=(
        ("Sthira", "Sthira"),
        ("griva", "pustha evum guru muscle of griva"),
        ("bahu", "pustha evum guru muscle of bahu"),
        ("adhoshakha", "pustha evum guru muscle of adhoshakha"),
    )
    my_medaSaara=(
        ("Snighdakesha ", "Snighdakesha "),
        ("oshtha", "oshtha"),
        ("nakha", "nakha"),
    )
    my_asthiSaara=(
        ("Sthoola sandhi", "Sthoola sandhi"),
        ("chibuka", "chibuka"),
        ("Jatru", "Jatru"),
    )
    my_majjaSaara=(
        ("Snigdha varna", "Snigdha varna"),
        ("snigdhaswara", "snigdhaswara"),
    )
    my_shukraSaara=(
        ("Kshirapoornalochana", "SKshirapoornalochana"),
        ("saumayaprekshan", "saumayaprekshan"),
        ("mahaspikha", "mahaspikha"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    prakruti = models.CharField(max_length=50, blank=True, choices=my_prakruti, verbose_name="Prakruti")
    vrikruti = models.CharField(max_length=50, blank=True, choices=my_vrikruti, verbose_name="Vrikruti")

    rasaTwakaSaara = models.CharField(max_length=50, blank=True, choices=my_rasatwakaSaara, verbose_name="Rasa/TwakaSaara")
    raktaSaara = models.CharField(max_length=50, blank=True, choices=my_raktaSaara, verbose_name="RaktaSaara")
    mamsaSaara = models.CharField(max_length=50, blank=True, choices=my_mamsaSaara, verbose_name="MamsaSaara")
    medaSaara = models.CharField(max_length=50, blank=True, choices=my_medaSaara, verbose_name="MedaSaara")
    asthiSaara = models.CharField(max_length=50, blank=True, choices=my_asthiSaara, verbose_name="AsthiSaara")
    majjaSaara = models.CharField(max_length=50, blank=True, choices=my_majjaSaara, verbose_name="MajjaSaara")
    shukraSaara = models.CharField(max_length=50, blank=True, choices=my_shukraSaara, verbose_name="ShukraSaara")
    #=========================Type of Sara===================================
    my_saara=(
        ("rasatwakasaara","rasa/twakasaara"),
        ("raktasaara","raktasaara"),
        ("mamsasaara", "mamsasaara"),
        ("medasaara", "medasaara"),
        ("asthisaara", "asthisaara"),
        ("majjasaara", "majjasaara"),
        ("sukrasaara", "sukrasaara"),
    )
    my_samahana=(
        ("Pravara","Pravara"),
        ("Madhyama","Madhyama"),
        ("Avara ", "Avara"),
    )
    my_satmya=(
        ("3","3"),
        ("2","2"),
        ("1","1"),
    )
    my_satva=(
        ("Pravar","Pravar"),
        ("madhyama","madhyama"),
        ("avara","avara"),
    )
    saara = models.CharField(max_length=200,choices=my_saara, blank=True,verbose_name="Types of Saara")
    samahana = models.CharField(max_length=200,choices=my_samahana, blank=True,verbose_name="Types of samahana")

    aharasatmya  = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Aharasatmya(change of food habits)")
    deshasatmya  = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Deshasatmya(change of place)")
    kaalsatmya   = models.CharField(max_length=50,choices=my_satmya, blank=True,verbose_name="Kaal satmya(change of season)")

    # pravarasatmya  = models.CharField(max_length=50, blank=True,verbose_name="Pravarasatmya(ahara+ desha+ kaal)[0-9]")
    # pravarasatmya = models.CharField(max_length=50, blank=True, verbose_name="Madhyamasatmya(ahara+ desha+ kaal)[6-8] ")
    # avarasatmya  = models.CharField(max_length=50, blank=True, verbose_name="Avarasatmya (ahara+ desha+ kaal)[3-5] ")

    # ================Assessment of Satva================
    my_asssatva = (
        ("satva", "In the recent past, any event of a crisis like loss of a family member/ close friend, loss of money/loss in business or Severe deterioration in the health of self or loved one"),
        ("satva", "Was tolerated well (pravarasatva)"),
        ("satva", "Could be tolerated with support of others (madhyamasatva)"),
        ("satva", "Was inconsolable (avarasatva)"),
    )
    asssatva = models.CharField(max_length=500, choices=my_asssatva, default='0', verbose_name="Assessment of Satva")

    satvatype = models.CharField(max_length=50,choices=my_satva ,blank=True, verbose_name="Type of satva")

    # ================Assessment of aahar shakti================
    my_aaharshakti = (
        ("3", "3"),
        ("2", "2"),
        ("1", "1"),
    )
    my_aahartype = (
        ("pravar", "pravar"),
        ("madhyam", "madhyam"),
        ("avara", "avara"),
    )

    aahartype = models.CharField(max_length=50, choices=my_aahartype, default='0',verbose_name="Type of aahar")
    assaaharshakti1 = models.CharField(max_length=50, choices=my_aaharshakti, default='0', verbose_name="how many major meals do you have a day? ")
    assaaharshakti2 = models.CharField(max_length=500, choices=my_aaharshakti, default='0',   verbose_name="how many major meals do you have a day? ")
    scoreaaharshakti= models.CharField(max_length=500, default='0', verbose_name="Score :")
    # ================Assessment of vyayam shakti================
    my_vyayamshakti = (
        ("3", "3"),
        ("2", "2"),
        ("1", "1"),
    )
    vyayamtype = models.CharField(max_length=50, choices=my_aahartype, default='0', verbose_name="Type of aahar")
    assvyayamshakti1 = models.CharField(max_length=50, choices=my_vyayamshakti, default='0',
                                      verbose_name="can you climb up stairs to the next floor of the house?")
    assvyayamshakti2 = models.CharField(max_length=500, choices=my_vyayamshakti, default='0',
                                      verbose_name="daily routine activities:")
    scorevyayamshakti = models.CharField(max_length=500, default='0', verbose_name="Score :")

    my_vaya = (
        ("Bal", "Bal"),
        ("Yuva", "Yuva"),
        ("madhyam", "Madhyam"),
        ("vriddha", "Vriddha"),
    )
    vaya = models.CharField(max_length=200, choices=my_vaya, default='0',verbose_name="Vaya")

    class Meta:
        verbose_name = 'Dashvidha Pariksha'
        verbose_name_plural = '4. Dashvidha Pariksha'

# =========================PHYSICAL EXAMINATION==========================
class physicalexaminationleena(models.Model):
    my_respsystem = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
        ("NotExamined", "Not Examined"),
    )
    my_cs = (
        ("Yes", "Yes"),
        ("No", "No"),
    )

    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    respsystem = models.CharField(max_length=50,choices=my_respsystem, blank=True, verbose_name="Respiratory System")
    respsystemspecify= models.CharField(max_length=100, blank=True, verbose_name="Comment if abnormal:")
    respcs = models.CharField(max_length=100, blank=True,choices=my_cs, verbose_name="Clinically Significant:")

    cardiovascsystem = models.CharField(max_length=50,choices=my_respsystem, blank=True, verbose_name="Cardio-vascular System")
    cardiovascsystemspecify= models.CharField(max_length=100, blank=True, verbose_name="Comment if abnormal:")
    cardiovasc= models.CharField(max_length=100, blank=True,choices=my_cs, verbose_name="Clinically Significant:")

    nervoussystem = models.CharField(max_length=50,choices=my_respsystem, blank=True, verbose_name="Nervous System")
    nervoussystemspecify= models.CharField(max_length=100,choices=my_cs, blank=True, verbose_name="Comment if abnormal:")
    nervsc = models.CharField(max_length=100, blank=True, choices=my_cs, verbose_name="Clinically Significant:")

    musculoskeletal= models.CharField(max_length=50,choices=my_respsystem, blank=True, verbose_name="Musculo-Skeletal")
    musculoskeletalspecify= models.CharField(max_length=100, blank=True, verbose_name="Comment if abnormal:")
    musculocs= models.CharField(max_length=100, blank=True,choices=my_cs, verbose_name="Clinically Significant:")

    genitourinarysystem = models.CharField(max_length=50, choices=my_respsystem, blank=True,verbose_name="Genito-urinary system")
    genitourinarysystemspecify= models.CharField(max_length=100, blank=True, verbose_name="Comment if abnormal:")
    genitocs= models.CharField(max_length=100, blank=True,choices=my_cs, verbose_name="Clinically Significant:")

    # gastrointestsystem = models.CharField(max_length=50,choices=my_respsystem, blank=True, verbose_name="Gastro- Intestinal System")

    other = models.CharField(max_length=100, choices=my_respsystem, blank=True, verbose_name="Other Specify")
    otherspecify = models.CharField(max_length=100, blank=True, verbose_name="Comment if abnormal:")
    othercs = models.CharField(max_length=100, blank=True, choices=my_cs, verbose_name="Clinically Significant:")

    anyothernote = models.CharField(max_length=100, choices=my_respsystem, blank=True, verbose_name="Any other note:")

    hisofpresentillduration = models.CharField(max_length=50, choices=my_respsystem, blank=True, verbose_name="a) Duration of illness")
    hisofpresentillanyotherinfo = models.CharField(max_length=100, choices=my_respsystem, blank=True, verbose_name="b) Any other information")

    hisofprevtill=models.CharField(max_length=100, choices=my_respsystem, blank=True, verbose_name="History of previous illness")

#==============8) General physical examination=====================
    my_built = (
        ("Average", "Average"),
        ("Emaciated", "Emaciated"),
        ("Well built", "Well built"),
        ("Tall", "Tall"),
        ("Dwarf", "Dwarf"),
    )
    my_nutrition = (
        ("ModeratelyNourished", "Moderately nourished"),
        ("Malnourished", "Malnourished"),
        ("Wellnourished ", "Well nourished "),
    )
    my_clubbing = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosis = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_cyanosispresent = (
        ("Central", "Central"),
        ("Peripheral", "Peripheral"),
    )
    my_rhythm=(
        ("Regular","Regular"),
        ("Irregular", "Irregular"),

    )
    my_pallor = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_lymphadenopathy = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_edema = (
        ("Present", "Present"),
        ("Absent", "Absent"),
    )
    my_character = (
        ("Pitting", "Pitting"),
        ("Non- pitting", "Non- pitting"),
    )

    builtavg = models.CharField(max_length=50, choices=my_built, blank=True, verbose_name="Built")
    nutrition = models.CharField(max_length=50, choices=my_nutrition, blank=True, verbose_name="Nutrition")

    height = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="Height(cm)")
    weight = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="Weight(kg)")
    bmi = models.DecimalField(max_digits=5, decimal_places=2, default=0, verbose_name="B.M.I.(kg/m2) ")

    waistcirm = models.DecimalField(max_digits=5, decimal_places=1, default=0, verbose_name="Waist Circumference (cm)")
    resprate = models.IntegerField(default=0, verbose_name="Respiratory Rate(/minute)")
    pulserate = models.IntegerField(default=0, verbose_name="Pulse Rate(/minute)")
    rhythm = models.CharField(max_length=50,default=0,choices=my_rhythm, verbose_name="Rhythm")
    bp = models.CharField(max_length=100, null=True, blank=True, verbose_name="Blood Pressure(mmHg)")

    clubbing = models.CharField(max_length=100, choices=my_clubbing, blank=True, verbose_name="Clubbing")
    cyanosis = models.CharField(max_length=100, choices=my_cyanosis, blank=True, verbose_name="Cyanosis")
    cyanosispresent = models.CharField(max_length=100, choices=my_cyanosispresent, blank=True,verbose_name="If present")

    temp = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True, verbose_name="Forehead Temperature(oF)")
    pallor = models.CharField(max_length=50, choices=my_pallor, blank=True, verbose_name="Pallor")
    lymphadenopathy = models.CharField(max_length=50, choices=my_lymphadenopathy, blank=True,
                                       verbose_name="Lymphadenopathy")
    edema = models.CharField(max_length=50, choices=my_edema, blank=True, verbose_name="Edema")
    character = models.CharField(max_length=50, choices=my_character, blank=True, verbose_name="Character")
    siteaffected = models.CharField(max_length=200, blank=True, verbose_name="Site Affected")

    class Meta:
        verbose_name = 'Examination'
        verbose_name_plural = '5. Physical Examination'

class scaleexaminationleena(models.Model):
    my_sc = (
        ("4", "4"),
        ("3", "3"),
        ("2", "2"),
        ("1", "1"),
    )
    registrationdate = models.DateField(null=True,verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    #====================Perceived Stress scale====================
    psc1 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="1.In the last month, how often have you been upset because of something that happened unexpectedly?")
    psc2 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="2.In the last month, how often have you felt that you were unable to control the important things in your life?")
    psc3 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="3.In the last month, how often have you felt nervous and “stressed”?")
    psc4 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="4.In the last month, how often have you felt confident about your ability to handle your personal problems?")
    psc5 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="5.In the last month, how often have you felt that things were going your way?")
    psc6 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="6.In the last month, how often have you found that you could not cope with all the things that you had to do?")
    psc7 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="7.In the last month, how often have you been able to control irritations in your life?")
    psc8 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="8.In the last month, how often have you felt that you were on top of things?")
    psc9 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="9.In the last month, how often have you been angered because of things that were outside of your control?")
    psc10 = models.CharField(max_length=50, choices=my_sc, default='0',
                  verbose_name="10. In the last month, how often have you felt difficulties were piling up so high that you could not overcome them?")

    mytotalscore = models.CharField(max_length=50, blank=True, verbose_name="My Total Score")

# ====================QUALITY OF LIFE SCALE (QOL)====================
    my_qol = (
        ("7", "7"),
        ("6", "6"),
        ("5", "5"),
        ("4", "4"),
        ("3", "3"),
        ("2", "2"),
        ("1", "1"),
    )
    qol1 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="1.Material comforts borne, food, conveniences, financial security")
    qol2 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="2.Health - being physically fit and vigorous")
    qol3 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="3.Relationships with parents, siblings & otherrelatives- communicating. visiting, helping.")
    qol4 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="4.Having andrearingchildren")
    qol5 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="5.Close relationships with spouse or significantother")
    qol6 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="6.Closefriends")
    qol7 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="7.Helping and encouraging others.volunteering,givingadvice")
    qol8 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="8.Participating in organizations and public affairs.")
    qol9 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="9.Leeming- attending school. Improving understanding. getting additional knowledge.")
    qol10 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="I0.Understanding yourself - knowing your assetsand limitations - knowing what life is about ")
    qol11 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="11.Work-joborinhome")
    qol12 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="12.Expressing yourself actively")
    qol13 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="13.	Socializing - meeting other people,doing things,parties,etc")
    qol14 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="14.	Reading, listening to music, or observing entertainment")
    qol15 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="15.Participating inactiverecreation")
    qol16 = models.CharField(max_length=50, choices=my_qol, default='0',
                  verbose_name="16.Independence, doingforyourself")

#==============visit 1st Day=============

    medtaken = models.CharField(max_length=50, choices=my_qol, default='0',
                             verbose_name="Is the subject currently or previously taking any medication including OTC, vitamins and/or supplements?")
    #=========PREVIOUS MEDICAL HISTORY==========
    my_mh = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
        ("Notexamined", "Not examined"),
    )
    cardiovascular = models.CharField(max_length=50, choices=my_mh, default='0',verbose_name="1.Cardiovascular")
    respiratory = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="2.espiratory")
    hepatobiliary = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="3.Hepato-biliary")
    gastrointestinal = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="4.Gastro-intestinal")
    genitourinary = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="5.Genito-urinary")
    endocrine = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="6.Endocrine")
    haematological = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="7.Haematological")
    musculoskeletal = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="8.Musculo-skeletal")
    neoplasia = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="9.Neoplasia")
    neurological = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="10.Neurological")
    psychological = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="11.Psychological")
    immunological = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="12.Immunological")
    dermatological= models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="13.Dermatological")
    allergies = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="14.Allergies")
    eyesearnosethroat = models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="15.Eyes,ear,nose,throat")
    other= models.CharField(max_length=50, choices=my_mh, default='0', verbose_name="16.Other")

#===========PHYSICAL EXAMINATION (to be carried out by medical staff only)===========
    my_pe = (
        ("Normal", "Normal"),
        ("Abnormal", "Abnormal"),
    )

    ga = models.CharField(max_length=50, choices=my_pe, default='0', verbose_name="1.General Appearance")
    heart = models.CharField(max_length=50, choices=my_pe, default='0', verbose_name="2.Heart")
    lung = models.CharField(max_length=50, choices=my_pe, default='0', verbose_name="3.Lungs")
    abdomen = models.CharField(max_length=50, choices=my_pe, default='0', verbose_name="4.Abdomen")
    extremities = models.CharField(max_length=50, choices=my_pe, default='0', verbose_name="5.Extremities")

# ===========Vital Sign===========
    my_finalresult = (
        ("Normal", "Normal"),
        ("AbnormalNCS", "Abnormal NCS"),
        ("AbnormalCS", "**Abnormal CS"),
    )
    my_contradict = (
        ("Yes", "Yes"),
        ("No", "No"),
    )
    ps = models.CharField(max_length=50,  default='0', verbose_name="Pulse Rate(Bpm)")
    bp = models.CharField(max_length=50, default='0', verbose_name="Blood pressure (seated)")

    srcortisol = models.CharField(max_length=50,  default='0', verbose_name="Serum Cortisol(1st Day)")

    finalresult = models.CharField(max_length=50,choices=my_finalresult, default='0', verbose_name="Are all final results")
    description = models.CharField(max_length=100, default='0', verbose_name="**Description")

    contradict = models.CharField(max_length=50, choices=my_contradict, default='0',
                                 verbose_name="Does any result contradict study entry?")

    class Meta:
        verbose_name = 'Scale Examination'
        verbose_name_plural = '6. Scales for Examining and rule out the patients for study:'


class summaryofmedleena(models.Model):
    registrationdate = models.DateField(null=True, verbose_name="Registration Date")
    opdno = models.IntegerField(null=True,verbose_name="OPD No.")
    #caseno = models.IntegerField(null=True,verbose_name="Case No.")
    crno = models.IntegerField(null=True,verbose_name="CR No.")
    ipdno = models.IntegerField(null=True,verbose_name="IPD No.")

    medication= models.CharField(max_length=50,  default='0', verbose_name="Medication")
    doses= models.CharField(max_length=50,  default='0', verbose_name="Doses")
    units= models.CharField(max_length=50,  default='0', verbose_name="Units")
    reason= models.CharField(max_length=50,  default='0', verbose_name="Reason")
    startdate= models.DateField(null=True, verbose_name="Start Date")
    stopdate= models.DateField(null=True, verbose_name="Stop Date")

#================ Summary of Lab Test=============
    srcortisol01 = models.CharField(max_length=50, default='0', verbose_name="1st Day")
    srcortisol14 = models.CharField(max_length=50, default='0', verbose_name="14th Day")

# ================ Summary of subjective parameter=============
    scale01 = models.CharField(max_length=50, default='0', verbose_name="1st Day")
    scale07 = models.CharField(max_length=50, default='0', verbose_name="7th Day")
    scale14 = models.CharField(max_length=50, default='0', verbose_name="14th Day")

    pss01 = models.CharField(max_length=50, default='0', verbose_name="1st Day")
    pss07 = models.CharField(max_length=50, default='0', verbose_name="7th Day")
    pss14 = models.CharField(max_length=50, default='0', verbose_name="14th Day")

    qol01 = models.CharField(max_length=50, default='0', verbose_name="1st Day")
    qol07 = models.CharField(max_length=50, default='0', verbose_name="7th Day")
    qol14 = models.CharField(max_length=50, default='0', verbose_name="14th Day")


    class Meta:
        verbose_name = 'Summary of Medication'
        verbose_name_plural = '7. Summary of Medication'
