from django.core import validators
from django import forms
from .models import perdemoinfo

class DateInput(forms.DateInput):
    input_type = 'date'

class perdemoinfoform(forms.ModelForm):
    class Meta:
        model=perdemoinfo
        fields=['registrationdate','opdno','crno','caseno','ipdno','patientname','dob','ageyr','agemn','gender','address','contactno','email','marritalstatus','edustatus','education','qualification','socecostatus','habitat','religion','religion','religion','chiefcomplaint','durationofillness','otherinfo','prevhistory','prevhistoryspecify']
widgets={
    'registrationdate' : DateInput(),
    'opdno' : forms.TextInput(attrs={'class':'form-control'}),
    'caseno' : forms.TextInput(attrs={'class':'form-control'}),
    'crno' : forms.TextInput(attrs={'class':'form-control'}),
    'ipdno' : forms.TextInput(attrs={'class':'form-control'}),
    'patientname' : forms.TextInput(attrs={'class':'form-control'}),
    'dob' : forms.DateInput(),
    'ageyr' : forms.TextInput(attrs={'class':'form-control'}),
    'agemn' : forms.TextInput(attrs={'class':'form-control'}),
    'gender' : forms.TextInput(attrs={'class':'form-control'}),
    'address' : forms.TextInput(attrs={'class':'form-control'}),
    'contactno' : forms.TextInput(attrs={'class':'form-control'}),
    'email' : forms.EmailInput(attrs={'class':'form-control'}),
    'marritalstatus' : forms.TextInput(attrs={'class':'form-control'}),
    'edustatus' : forms.TextInput(attrs={'class':'form-control'}),
    'education' : forms.TextInput(attrs={'class':'form-control'}),
    'qualification' : forms.TextInput(attrs={'class':'form-control'}),
    'socecostatus' : forms.TextInput(attrs={'class':'form-control'}),
    'habitat' : forms.TextInput(attrs={'class':'form-control'}),
    'religion' : forms.TextInput(attrs={'class':'form-control'}),
    'chiefcomplaint' : forms.TextInput(attrs={'class':'form-control'}),
    'durationofillness' : forms.TextInput(attrs={'class':'form-control'}),
    'otherinfo' : forms.TextInput(attrs={'class':'form-control'}),
    'prevhistory' : forms.TextInput(attrs={'class':'form-control'}),
    'prevhistoryspecify' : forms.TextInput(attrs={'class':'form-control'}),
}