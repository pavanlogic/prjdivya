from django.apps import AppConfig
# from django.contrib.admin.apps import AdminConfig
#
# class DivyaAdminConfig(AdminConfig):
#     divya_site=divyaapp.admin()
#     default_site = "divyaapp.admin."
class DivyaappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'divyaapp'
