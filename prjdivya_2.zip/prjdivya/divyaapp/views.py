from django.shortcuts import render
from .forms import perdemoinfoform
from .models import perdemoinfo

def add_show(request):
    fm = perdemoinfoform(request.POST or None)
    if request.method == 'POST':
        if fm.is_valid():
            fm.save()
            fm = perdemoinfoform()

    else:
        fm = perdemoinfoform()
    return render(request,'divya/addandshow.html',{'form':fm})
    #return render(request,'www.autchpanchakarma.org',{'form':fm})